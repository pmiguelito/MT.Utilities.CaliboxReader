﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STDhelper;
using static STDhelper.clLogging;
using System.IO;
using static ReadCalibox.clHandler;

namespace ReadCalibox
{
    public class clLogging
    {
        private clLogWriter LogWriter = clLogWriter.Instance;
        public int FlushAtAge_sec
        {
            get { return LogWriter.FlushAtAge_sec; }
            set { LogWriter.FlushAtAge_sec = value; }
        }
        public int FlushAtQty
        {
            get { return LogWriter.FlushAtQty; }
            set { LogWriter.FlushAtQty = value; }
        }

        public int FileLenght_KB
        {
            get { return LogWriter.FileLenghtKB; }
            set { LogWriter.FileLenghtKB = value; }
        }

        public clLogging()
        {
            FlushAtAge_sec = 1;
            FlushAtQty = 100;
            FileLenght_KB = 2000;
        }

        public void ForceLog()
        {
            LogWriter.ForceFlush();
        }


        public void Save(UC_Channel ucCH, DeviceResponse response)
        {
            if (!response.Response_Empty)
            {
                if (clConfig.Config_Initvalues.LogMeas_Path_Active || clConfig.Config_Initvalues.LogMeas_DB_Active)
                {
                    Task t = Task.Factory.StartNew(() =>
                    {
                        DoWork(new LogValues() { Response = response, Channel = ucCH });
                    });
                }
            }
        }

        public void Save(UC_Channel ucCH, string response, opcode opcodeRequest)
        {
            DeviceResponse resp = new DeviceResponse(opcodeRequest, ucCH, response);
            Save(ucCH, resp);
        }
        public void Save(UC_Channel ucCH, gProcMain state, opcode opcodeRequest, string response = null)
        {
            string message = $"{state}";
            if (response != null) { message += $"\t{response}"; }
            Save(ucCH, message, opcodeRequest);
        }

        public void Save(UC_Channel ucCH, Exception ex)
        {
            LogWriter.WriteToLog(ex, ucCH.LogPathMeas);
        }
        
        /***************************************************************************************
        * BackGroundWorker Write Messages
        ****************************************************************************************/
        public BackgroundWorker BGW_MessageWriter = new BackgroundWorker();
        private void BGW_MessageWriter_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                if (e.Argument != null)
                {
                    DoWork((LogValues)e.Argument);
                }
            }
            catch (Exception a)
            {
                ErrorHandler("BGW_MessageWriter_DoWork Starter", exception: a);
            }
        }
        private void DoWork(LogValues log)
        {
            try
            {
                foreach (DeviceResponseValues drv in log.Response.ResponseList)
                {
                    if (ParseMessage(log, drv, out string message))
                    {
                        SaveLogMeas(log, message, drv);
                    }
                }
            }
            catch(Exception e)
            {
                ErrorHandler("BGW_MessageWriter_DoWork Executible", e);
            }
        }

        /***************************************************************************************
        * Log Message:
        ****************************************************************************************/
        private bool ParseMessage(LogValues log, DeviceResponseValues message, out string messageValues)
        {
            if (string.IsNullOrEmpty(message.ResponseParsed))
            {
                messageValues = message.Response;
            }
            else
            { messageValues = message.ResponseParsed; }
            if (!log.Response.Response_Empty)
            {
                switch (log.Channel.BeM_Selected)
                {
                    case "30259861": //Ozon NG sensor
                        if (messageValues == ".")
                        { return false; }
                        break;
                    case "30014462": //Ozon old sensor
                        if (messageValues == ".")
                        { return false; }
                        else if (messageValues.Length == 3)
                        {
                            if (messageValues.ToLower().Contains("?"))
                            { return false; }
                        }
                        break;
                    default:
                        break;
                }
                messageValues = $"{log.Channel.Channel_No}\t{log.Channel.BeM_Selected}\t{messageValues}";
                log.Response.ResponseParsedLog = messageValues;
                return true;
            }
            return false;
        }

        private void SaveLogMeas(LogValues log, string message, DeviceResponseValues drv)
        {
            SaveLogMeasFile(log, message);
            if (log.Channel.calibrationRunning)
            { 
                SaveLogMeasDB(log, drv); 
            }
        }

        private void SaveLogMeasFile(LogValues log, string message)
        {
            if (clConfig.Config_Initvalues.LogMeas_Path_Active)
            { LogWriter.WriteToLog(message, log.Channel.LogPathMeas); }
        }
        private void SaveLogMeasDB(LogValues log, DeviceResponseValues drv)
        {
            try
            {
                if (clConfig.Config_Initvalues.LogMeas_DB_Active)
                { clDataBase.Set_Log(log.Channel.Limits.ODBC_EK, drv, log.Channel.Limits); }
            }
            catch
            {
                ErrorHandler("SaveLogMeas", message: $"ERROR: Directory {log.Channel.LogPathMeas} don't found");
            }
        }

    }
    public class LogValues
    {
        public string message { get; set; }
        public DeviceResponse Response { get; set; }
        public UC_Channel Channel { get; set; }
    }
}
