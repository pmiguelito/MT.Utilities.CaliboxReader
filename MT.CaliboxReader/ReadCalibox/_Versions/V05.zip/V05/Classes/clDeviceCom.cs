﻿using OneWire_DataConverter;
using static OneWire_DataConverter.OneWire_TDLdatatype;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ReadCalibox.clDataBase;
using static ReadCalibox.clHandler;
using static STDhelper.clSTD;
using System.Data;

namespace ReadCalibox
{
    public class clDeviceCom
    {

        /****************************************************************************************************
        ** Command:  Read Page15 FW version And Parse
        ****************************************************************************************************/
        public static clTDLproperty Page15_FWversion;
        //private static clTDLproperty Page15_MaximSN;
        //private static clTDLproperty Page15_MaximCRC;
        //private static List<clTDLproperty> Page15_Properties;

        public static bool Get_Sample_FWversion(string odbc, string page15HEX, out string fwversion)
        {
            fwversion = "";
            bool error = false;
            if(Page15_FWversion == null) { error = !Get_TDL_FWversion(odbc, out Page15_FWversion); }
            if(Page15_FWversion.data_type == null && !error) { error = !Get_TDL_FWversion(odbc, out Page15_FWversion); }
            if (Page15_FWversion.data_type != null && !error)
            {
                try
                {
                    fwversion = page15HEX.GetValuesFromTEDS_HEX(Page15_FWversion.data_type, Page15_FWversion.start, Page15_FWversion.tol, Page15_FWversion.bit, Page15_FWversion.bit_start);
                }
                catch { }
                return !string.IsNullOrEmpty(fwversion);
            }
            return false;
        }

        public static string Get_PropertyValue(clTDLproperty property, string hex)
        {
            return hex.GetValuesFromTEDS_HEX(property.data_type, property.start, property.tol, property.bit, property.bit_start);
        }

        public static bool Get_Sampel_FWversionPropertie(string odbc, out clTDLproperty fwversion)
        {
            return Get_TDL_FWversion(odbc, out fwversion);
        }

        //public bool Get_Sample_FWversion(UC_Channel ucCH, out string fwversion)
        //{
        //    fwversion = "";
        //    if(SendCMD(ucCH, opcode.G015))
        //    {
        //        return Get_Sample_FWversion(ucCH.ODBC_EK, ucCH.SampleResponse.BoxMeasValue, out fwversion);
        //    }
        //    return false;
        //}


        /****************************************************************************************************
         * Command:  Read Page
        // ***************************************************************************************************/

        //public bool ReadPage(UC_Channel ucCH, int pageNo)
        //{
        //    string cmd = $"#RDPG {pageNo}";
        //    if (SendCMD(ucCH, opcode.RDPG))
        //    {
        //        return true;
        //    }
        //    return false;
        //}

        /****************************************************************************************************
         * Command:  Write Page
         ***************************************************************************************************/

        //public bool WritePage(UC_Channel ucCH, int pageNo, string hex)
        //{
        //    string cmd = $"#WDPG {pageNo}";
        //    if (SendCMD(ucCH, opcode.RDPG))
        //    {
        //        return true;
        //    }
        //    return false;
        //}

    }

    public class DeviceResponse
    {
        public DeviceResponse(string opcodeRequest, UC_Channel ucCH, string response = null, bool isDebug = false)
        {
            IsDebug = isDebug;
            OpCode_Request = opcodeRequest.ParseOpcode();
            Channel = ucCH;
            if (response != null)
            {
                Response = response;
            }
        }
        public DeviceResponse(opcode opcodeRequest, UC_Channel ucCH, string response = null, bool boxidentificationfound = false, bool isDebug = false)
        {
            IsDebug = isDebug;
            OpCode_Request = opcodeRequest;
            BoxIdentificationFound = boxidentificationfound;
            Channel = ucCH;
            if (response != null)
            {
                Response = response;
            }
        }

        public bool IsDebug { get; set; } = false;
        public UC_Channel Channel { get; set; }
        public bool BoxIdentificationFound { get; set; }
        public DateTime meas_time_start { get; private set; }
        public double TimeDiff { get { if (meas_time_start.Year > 1) { return (DateTime.Now - meas_time_start).TotalMilliseconds; } return 0; } }
        private opcode _OpCode_Request;
        public opcode OpCode_Request
        {
            get { return _OpCode_Request; }
            set { _OpCode_Request = value; }
        }
        public bool OpCode_Changed
        {
            get
            {
                if(OpCode_Request == opcode.cmdread) { return false; }
                return OpCode_Request.ToString().ToLower() != OpCode_Response.ToString().ToLower();
            }
        }
        public opcode OpCode_Response { get; set; }
        public bool g901_receved { get; set; }

        private string _Response;
        public string Response
        {
            get { return _Response; }
            set
            {
                _Response = value;
                if (!string.IsNullOrEmpty(value))
                { ResponseParser(IsDebug); }
            }
        }
        public string ResponseParsed { get; set; }
        public string ResponseParsedLog { get; set; }
        public bool Response_Empty { get { return string.IsNullOrEmpty(Response); } }
        
        private string _BoxMode_hex;
        public string BoxMode_hex
        {
            get
            {
                if (!string.IsNullOrEmpty(_BoxMode_hex)) 
                {
                    _ = ResponseListCount;
                }
                return _BoxMode_hex;
            }
            set { _BoxMode_hex = value; }
        }
        public bool BoxMode_Empty { get { return string.IsNullOrEmpty(BoxMode_hex); } }
        public string BoxMode_desc { get { return Get_BoxMode_Desc(BoxMode_hex); } }
        public string BoxErrorCode_hex { get; set; } = "0";
        public bool BoxErrorCode_Empty { get { return string.IsNullOrEmpty(BoxErrorCode_hex); } }
        public string BoxErrorCode_desc { get { return Get_BoxErrorCode_Desc(BoxErrorCode_hex); } }
        public string BoxCalStatus_hex { get; set; }
        public bool BoxCalStatus_Empty { get { return string.IsNullOrEmpty(BoxCalStatus_hex); } }
        public string BoxCalStatus_desc { get { return Get_BoxCalStatus_Desc(BoxCalStatus_hex); } }
        public string BoxMeasValue { get; set; }
        public bool TestError { get; set; }
        public bool TestFinalise { get; set; }


        public int ResponseListCount { get { return (ResponseList != null) ? ResponseList.Count : 0; } }
        public List<DeviceResponseValues> _ResponseList;
        public List<DeviceResponseValues> ResponseList
        {
            get
            {
                if(_ResponseList == null && Response != null)
                {
                    ResponseParser(IsDebug);
                }
                return _ResponseList;
            }
            set { _ResponseList = value; }
        }

        /****************************************************************************************************
         * Response:    
         ***************************************************************************************************/
        public string[] Lines { get; private set; }
        public int LinesCount { get { return (Lines != null) ? Lines.Length : 0; } }

        public void ResponseParser(bool isDebug = false)
        {
            if (!Response_Empty)
            {
                Split_Line(isDebug); 
            }
        }

        private string _lastprogress = "";
        private bool Split_Line(bool isDebug = false)
        {
            Lines = Response.Split(new[] { System.Environment.NewLine }, StringSplitOptions.None);
            if (LinesCount > 0)
            {
                _ResponseList = new List<DeviceResponseValues>();
                foreach (string line in Lines)
                {
                    string l = line.Trim();
                    if (!string.IsNullOrEmpty(l) && l != "\0")
                    {
                        DeviceResponseValues resp = new DeviceResponseValues(OpCode_Request, Channel, l);
                        _ResponseList.Add(resp);
                        if (!isDebug)
                        {
                            ToMain(resp);
                        }
                    }
                }
            }
            return true;
        }
        public void ToMain(DeviceResponseValues resp)
        {
            OpCode_Response = resp.OpCode;
            if (OpCode_Response == opcode.s999)
            {
                if (!BoxIdentificationFound)
                { Get_BoxIdentification(resp); }
                return;
            }
            if (!IsDebug)
            {
                try { Insert_DT_Measurement(resp); } catch { }
                //if (_lastprogress != resp.BoxMode_desc)
                {
                    if(Set_Progress(resp, out string boxmode_desc))
                    {
                        if(boxmode_desc != null)
                        {
                            _lastprogress = resp.BoxMode_desc;
                        }
                    }
                }
            }
            if (resp.BoxErrorCode_hex != "00" && !resp.BoxErrorCode_Empty)
            {
                BoxErrorCode_hex = resp.BoxErrorCode_hex;
            }
            if (!resp.BoxMode_Empty)
            {
                if (!TestError)
                {
                    BoxMode_hex = resp.BoxMode_hex;
                    TestError = resp.TestError;
                    TestFinalise = resp.TestFinalise;
                }
            }
            else
            {
                resp.BoxMode_hex = BoxMode_hex;
            }
            if (!resp.BoxCalStatus_Empty)
            { BoxCalStatus_hex = resp.BoxCalStatus_hex; }
            else
            { resp.BoxCalStatus_hex = BoxCalStatus_hex; }

            if (!string.IsNullOrEmpty(resp.BoxMeasValue))
            { BoxMeasValue = resp.BoxMeasValue; }
            else
            { resp.BoxMeasValue = BoxMeasValue; }
            
        }

        /****************************************************************************************************
         * Box Values:    
         ***************************************************************************************************/
        #region BoxIdentification
        private void Get_BoxIdentification(DeviceResponseValues resp)
        {
            if (resp.BoxMeasValue == "BoxReset") { return; }
            if (resp.BoxMeasValue.Contains("Messbereich\t")) { return; }
            if (Channel.DeviceLimits == null) { Channel.DeviceLimits = new clDeviceLimits();}
            if (resp.Response.Contains("DipSwitch"))
            {
                Channel.DeviceLimits.DipSwitch = resp.Response.Trim();
                Channel.DeviceLimits.BoxIdentification_State.DipSwitch = true;
                return;
            }
            string[] split = resp.Response.Split('\t');
            if (resp.Response.Contains("Betriebsmittel"))
            {
                if (split.Length > 3)
                {
                    string bem = split[0];
                    string hwid = split[2];
                    string hwversion = split[3];
                    Channel.DeviceLimits.BeM = bem.Substring(bem.IndexOf(':') + 1).Trim();
                    Channel.DeviceLimits.HW_ID = hwid.Substring(hwid.IndexOf(':') + 1).Trim();
                    Channel.DeviceLimits.HW_Version = hwversion.Substring(hwversion.IndexOf(':') + 1).Trim();
                    Channel.DeviceLimits.BoxIdentification_State.Betriebsmittel = true;
                }
                return;
            }
            if (resp.Response.Contains("CalibrationBox"))
            {
                Channel.DeviceLimits.BoxDesc = resp.Response.Trim();
                Channel.DeviceLimits.BoxIdentification_State.CalibrationBox = true;
                return;
            }
            if (resp.Response.Contains("FW:"))
            {
                if (split.Length > 2)
                {
                    string fw = split[0];
                    string cp = split[2];
                    Channel.DeviceLimits.FW_Version = fw.Substring(fw.IndexOf(':') + 1).Trim();
                    Channel.DeviceLimits.Compiled = cp.Substring(cp.IndexOf(':') + 1).Trim();
                    Channel.DeviceLimits.BoxIdentification_State.FW = true;
                }
                return;
            }
            if (resp.Response.Contains("RawVal"))
            {
                if (split.Length > 6)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    string temp = split[6];
                    string temp2 = "0";
                    string temp3 = "0";
                    if (split.Length > 7)
                    {
                        temp2 = split[7];
                        temp3 = split[8];
                    }
                    Channel.DeviceLimits.RawVal = new clDeviceLimitsModes();
                    double.TryParse(low1, out Channel.DeviceLimits.RawVal.Low1);
                    double.TryParse(low2, out Channel.DeviceLimits.RawVal.Low2);
                    double.TryParse(high1, out Channel.DeviceLimits.RawVal.High1);
                    double.TryParse(high2, out Channel.DeviceLimits.RawVal.High2);
                    Channel.DeviceLimits.RawVal.Unit = unit.Trim();
                    double.TryParse(temp, out Channel.DeviceLimits.TempRefVolt);
                    double.TryParse(temp2, out Channel.DeviceLimits.TempRefVolt2);
                    double.TryParse(temp3, out Channel.DeviceLimits.TempRefVolt3);
                    Channel.DeviceLimits.BoxIdentification_State.RawVal = true;
                }
                return;
            }
            if (resp.Response.Contains("Current"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    Channel.DeviceLimits.Current = new clDeviceLimitsModes();
                    double.TryParse(low1, out Channel.DeviceLimits.Current.Low1);
                    double.TryParse(low2, out Channel.DeviceLimits.Current.Low2);
                    double.TryParse(high1, out Channel.DeviceLimits.Current.High1);
                    double.TryParse(high2, out Channel.DeviceLimits.Current.High2);
                    Channel.DeviceLimits.Current.Unit = unit.Trim();
                    Channel.DeviceLimits.BoxIdentification_State.Current = true;
                }
                return;
            }
            if (resp.Response.Contains("ErrorRaw"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    Channel.DeviceLimits.RawError = new clDeviceLimitsModes();
                    double.TryParse(low1, out Channel.DeviceLimits.RawError.Low1);
                    double.TryParse(low2, out Channel.DeviceLimits.RawError.Low2);
                    double.TryParse(high1, out Channel.DeviceLimits.RawError.High1);
                    double.TryParse(high2, out Channel.DeviceLimits.RawError.High2);
                    Channel.DeviceLimits.RawError.Unit = unit.Trim();
                    Channel.DeviceLimits.BoxIdentification_State.ErrorRaw = true;
                }
                return;
            }
            if (resp.Response.Contains("CalError"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    Channel.DeviceLimits.CalError = new clDeviceLimitsModes();
                    double.TryParse(low1, out Channel.DeviceLimits.CalError.Low1);
                    double.TryParse(low2, out Channel.DeviceLimits.CalError.Low2);
                    double.TryParse(high1, out Channel.DeviceLimits.CalError.High1);
                    double.TryParse(high2, out Channel.DeviceLimits.CalError.High2);
                    Channel.DeviceLimits.CalError.Unit = unit.Trim();
                    Channel.DeviceLimits.BoxIdentification_State.CalError = true;
                }
                return;
            }
            if (resp.Response.Contains("WepError"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    Channel.DeviceLimits.WepError = new clDeviceLimitsModes();
                    double.TryParse(low1, out Channel.DeviceLimits.WepError.Low1);
                    double.TryParse(low2, out Channel.DeviceLimits.WepError.Low2);
                    double.TryParse(high1, out Channel.DeviceLimits.WepError.High1);
                    double.TryParse(high2, out Channel.DeviceLimits.WepError.High2);
                    Channel.DeviceLimits.WepError.Unit = unit.Trim();
                    Channel.DeviceLimits.BoxIdentification_State.WepError = true;
                }
                return;
            }
            BoxIdentificationFound = Channel.DeviceLimits.BoxIdentification_State.State();
        }
        #endregion BoxIdentification

        /****************************************************************************************************
         * Measurement:
         ***************************************************************************************************/
        private DataTable _DT_Measurements;
        public DataTable DT_Measurements
        {
            get
            {
                if(_DT_Measurements == null)
                {
                    _DT_Measurements = Init_DT_Measurement();
                }
                return _DT_Measurements;
            }
            private set { _DT_Measurements = value; }
        }

        private void Insert_DT_Measurement(DeviceResponseValues drv)
        {
            if (drv.OpCode == opcode.g901)
            {
                if (!g901_receved) { g901_receved = drv.OpCode == opcode.g901; }
                if (drv.BoxMode_desc.ToLower().Contains("mode"))
                {
                    try
                    {
                        DataRow row = DT_Measurements.NewRow();
                        row[MN_meas_time_start] = drv.meas_time_start.ToString(DateTimeFormat_Meas);
                        
                        row[MN_BoxMode_HEX] = drv.BoxMode_hex;
                        row[MN_BoxMode_Desc] = drv.BoxMode_desc;

                        row[MN_I_set] = drv.I_Set;
                        row[MN_I_AVG] = drv.I_AVG;
                        row[MN_I_StdDev] = drv.I_StdDev;
                        row[MN_I_Error] = drv.I_Error;
                        row[MN_Temp_set] = drv.Temp_Set;
                        row[MN_Temp_AVG] = drv.Temp_AVG;
                        row[MN_Temp_Error] = drv.Temp_Error;
                        row[MN_Temp_StdDev] = drv.Temp_StdDev;
                        if (Channel.DeviceLimits != null)
                        {
                            clDeviceLimitsResults values = Channel.DeviceLimits.CheckLimits(drv.BoxMode_hex, drv.BoxMeasValue, drv.I_AVG, drv.I_StdDev, drv.I_Error);
                            Channel.Limits.Add_MeasResult(values);
                            row[MN_Test_ok] = values.Rating.Test_ok;
                            //row["refvalue_set"] = values.LimitsMode.RawValue;
                            row[MN_I_ok] = values.Rating.Value_ok;

                            row[MN_I_StdDev_set] = values.LimitsMode.StdDev;
                            row[MN_I_StdDev_ok] = values.Rating.StdDev_ok;

                            row[MN_I_Error_set] = values.LimitsMode.RawError;
                            row[MN_I_Error_ok] = values.Rating.ErrorABS_ok;
                        }
                        else { BoxIdentificationFound = false; }
                        DT_Measurements.Rows.Add(row);
                    }
                    catch (Exception ex)
                    {
                        H_Log.Save(Channel, ex);
                    }
                }
            }
        }

        /****************************************************************************************************
         * Processes:
         ***************************************************************************************************/
        private DataTable _DT_Progress;
        public DataTable DT_Progress
        {
            get
            {
                if(_DT_Progress == null) {_DT_Progress = _DT_Progress.DT_ProgressColumnsAndClearRows(); }
                return _DT_Progress;
            }
            set { _DT_Progress = value; }
        }

        private string ProgHeaderSearcher { get { return MN_BoxMode_HEX; } }
        private DataRow Set_Values(DataRow row, DeviceResponseValues drv, bool newRow, out int rowIndex, out string value)
        {
            value = null;
            if (newRow)
            { 
                row[MN_meas_time_start] = DateTimeNow;
                row[MN_BoxMode_HEX] = drv.BoxMode_hex;
                row[MN_BoxMode_Desc] = Get_BoxMode_Desc(drv.BoxMode_hex);
            }
            if (!string.IsNullOrEmpty(drv.BoxMeasValue))
            {
                if (!drv.BoxMeasValue.StartsWith("g100;"))
                { 
                    row[MN_Values] = drv.ResponseParsed;
                    value = drv.BoxMeasValue;
                }
            }
            if (!string.IsNullOrEmpty(drv.BoxErrorCode_hex))
            {
                row[MN_BoxErrorCode_HEX] = drv.BoxErrorCode_hex;
                row[MN_BoxErrorCode_Desc] = Get_BoxErrorCode_Desc(drv.BoxErrorCode_hex);
            }
            if (newRow)
            {
                DT_Progress.Rows.Add(row);
            }
            rowIndex = DT_Progress.Rows.IndexOf(row);
            return row;
        }
        private bool Set_Progress(DeviceResponseValues drv, out string lastBoxMode)
        {
            lastBoxMode = null;
            try
            {
                if (!string.IsNullOrEmpty(drv.BoxMode_hex))
                {
                    //H_Log.Save(Channel, $"Set_Progress: {drv.BoxMode_hex}\tErrorCode: {drv.BoxErrorCode_hex}", opcode.state);
                    if (drv.BoxMode_hex == "32") { return false; }
                    if (drv.BoxMode_hex == "17") { return false; }
                    if (drv.BoxMode_hex == "1C") { return false; }
                    int rowIndex = -1;
                    DataRow row = DT_Progress.NewRow();
                    DataRow[] rows = DT_Progress.Select($"{ProgHeaderSearcher} = '{drv.BoxMode_hex}'");
                    int count = rows.Count();
                    string value;
                    if (count == 0)
                    {
                        row = Set_Values(row, drv, true, out rowIndex, out value);
                    }
                    else
                    {
                        row = Set_Values(rows[0], drv, false, out rowIndex, out value);
                    }
                    if(value != null)
                    {
                        lastBoxMode = drv.BoxMode_desc;
                    }
                    if (rowIndex > 0)
                    {
                        try
                        {
                            row = DT_Progress.Rows[rowIndex - 1];
                            if (string.IsNullOrEmpty(row[MN_meas_time_end].ToString()))
                            {
                                row[MN_meas_time_end] = DateTimeNow;
                                row[MN_Duration] = Calc_Duration(row);
                            }
                        }
                        catch(Exception ex) 
                        {
                            H_Log.Save(Channel, ex);
                        }
                    }
                    Channel.Update_DGVprogress();
                    return true;
                }
            }
            catch (Exception ex)
            {
                H_Log.Save(Channel, ex);
            }
            return false;
        }
        public void Set_Progress(string boxmode_hex, string boxmode_desc, string value = null, string errorcode = null)
        {
            string searchValue = boxmode_hex;
            if (!string.IsNullOrEmpty(searchValue))
            {
                H_Log.Save(Channel, $"Set_Progress: {boxmode_hex}\tErrorCode: {errorcode}", opcode.state);
                DataRow row = DT_Progress.NewRow();
                DataRow[] rows = DT_Progress.Select($"{ProgHeaderSearcher} = '{searchValue}'");
                bool newRow = (rows.Count() > 0) ? false : true;
                if (newRow)
                {
                    row[MN_BoxMode_HEX] = boxmode_hex;
                    if(boxmode_hex == boxmode_desc)
                    {
                        row[MN_BoxMode_Desc] = boxmode_desc;
                    }
                    else
                    {
                        row[MN_BoxMode_Desc] = BoxMode[boxmode_hex];
                    }
                    row[MN_meas_time_start] = DateTimeNow;
                    if (!string.IsNullOrEmpty(value))
                    { row[MN_Values] = value; }
                    if (!string.IsNullOrEmpty(errorcode))
                    {
                        row[MN_BoxErrorCode_HEX] = errorcode;
                        row[MN_BoxErrorCode_Desc] = BoxErrorCode[errorcode];
                    }
                    DT_Progress.Rows.Add(row);
                }
                else if(value != null || errorcode != null)
                {
                    int index = DT_Progress.Rows.IndexOf(rows[0]);
                    row = DT_Progress.Rows[index];
                    row[MN_meas_time_end] = DateTimeNow;
                    row[MN_Duration] = Calc_Duration(row);
                    if (!string.IsNullOrEmpty(value))
                    { row[MN_Values] = value; }
                    if (!string.IsNullOrEmpty(errorcode))
                    {
                        row[MN_BoxErrorCode_HEX] = errorcode;
                        row[MN_BoxErrorCode_Desc] = BoxErrorCode[errorcode];
                    }
                }
            }
            Channel.Update_DGVprogress();
        }
        private string Calc_Duration(DataRow row)
        {
            var time = row[MN_meas_time_start];
            DateTime t = DateTime.Now.AddSeconds(-2);
            if (time != null)
            {
                t = time.ToString().ConverDateTime(DateTimeFormatSQL);
            }
            if (t.Year == 1) { t = DateTime.Now.AddSeconds(-2); }
            double d = (DateTime.Now - t).TotalSeconds;
            string dur = d.ToString("00.00");
            return dur;
        }
    }
    
    public class DeviceResponseValues
    {
        public DeviceResponseValues(opcode opcodeRequest, UC_Channel ucCH, string line = null)
        {
            OpCode = opcodeRequest;
            Channel = ucCH;
            if (!string.IsNullOrEmpty(line))
            {
                if (line != "\0")
                { Response = line.Trim(); }
            }
            else { Response = null; }
        }

        public UC_Channel Channel { get; set; }
        public DateTime meas_time_start { get; private set; }
        public string StartDate { get { return $"{meas_time_start}.{meas_time_start.Millisecond}"; } }
        public bool Error { get; private set; } = false;
        private string _Response;
        public string Response
        {
            get { return _Response; }
            set
            {
                _Response = value;
                meas_time_start = DateTime.Now;
                if (!string.IsNullOrEmpty(value))
                { ResponseParser(); }
            }
        }
        public string ResponseParsed { get; set; }
        public string ResponseParsedLog { get; set; }
        public bool Response_Empty { get { return Response == null ? true : false; } }
        private string _strOpCode;
        private opcode _OpCode;
        public opcode OpCode
        {
            get
            {
                if(_strOpCode == null)
                {
                    _OpCode = Check_OpCode();
                    _strOpCode = _OpCode.ToString();
                }
                return _OpCode;
            }
            set
            {
                _OpCode = Check_OpCode_ToAnswer(value);
                _strOpCode = _OpCode.ToString();
            }
        }
        public string BoxMode_hex { get; set; }
        public bool BoxMode_Empty { get { return string.IsNullOrEmpty(BoxMode_hex); } }
        public string BoxMode_desc { get { return Get_BoxMode_Desc(BoxMode_hex); } }
        public string BoxErrorCode_hex { get; set; } = "00";
        public bool BoxErrorCode_Empty { get { return string.IsNullOrEmpty(BoxErrorCode_hex); } }
        public string BoxErrorCode_desc { get { return Get_BoxErrorCode_Desc(BoxErrorCode_hex); } }
        public string BoxCalStatus_hex { get; set; }
        public bool BoxCalStatus_Empty { get { return string.IsNullOrEmpty(BoxCalStatus_hex); } }
        public bool BoxCalStatus_Error
        {
            get
            {
                if (!BoxErrorCode_Empty)
                {
                    if (BoxErrorCode_hex == "00") { return false; }
                    if (BoxErrorCode_hex == "0") { return false; }
                    if (BoxErrorCode_hex == "2") { return false; }
                    return true;
                }
                return false;
            }
        }
        public string BoxCalStatus_desc { get { return Get_BoxCalStatus_Desc(BoxCalStatus_hex); } }
        public string BoxMeasValue { get; set; }
        public string I_Set { get; set; }
        public string I_AVG { get; set; }
        public string I_StdDev { get; set; }
        public string I_Error { get; set; }

        public string Temp_Set { get; set; }
        public string Temp_AVG { get; set; }
        public string Temp_StdDev { get; set; }
        public string Temp_Error { get; set; }


        private bool _TestError = false;
        public bool TestError
        {
            get
            {
                if (!string.IsNullOrEmpty(BoxMode_hex))
                {
                    _TestError = (BoxMode_hex == "17" || BoxMode_hex == "1B") ? true : false;
                    if(!_TestError && !BoxErrorCode_Empty)
                    {
                        _TestError = BoxCalStatus_Error;
                    }
                }
                return _TestError;
            }
            set { _TestError = value; }
        }
        private bool _TestFinalise = false;
        public bool TestFinalise
        {
            get
            {
                if (!string.IsNullOrEmpty(BoxMode_hex))
                { _TestFinalise = (BoxMode_hex == "1C" || BoxMode_hex == "37" || TestError) ? true : false; }
                return _TestFinalise;
            }
            private set { _TestFinalise = value; }
        }

        private string[] _ResponseArray;
        
        public string[] ResponseArray
        {
            get
            {
                if(_ResponseArray == null && !Response_Empty)
                {
                    try
                    { _ResponseArray = Response.Split(';'); }
                    catch
                    { }
                }
                return _ResponseArray;
            }
            private set { _ResponseArray = value; }
        }
        public int ResponseArrayCount { get { return ResponseArray != null ? ResponseArray.Length : 0; } }

        private void ResponseParser()
        {
            string[] Header = new string[0];
            int i = 0;
        again:
            i++;
            if (i > 2)
            { _OpCode = opcode.parser_error; }
            switch (OpCode)
            {
                case opcode.g904:
                case opcode.g905:
                case opcode.g906:
                    switch (ResponseArrayCount)
                    {
                        case 2:
                            Header = OpcodeHeader_G015;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g015:
                    switch (ResponseArrayCount)
                    {
                        case 2:
                            Header = OpcodeHeader_G015;
                            if (Channel == null)
                            {
                                if (clDeviceCom.Page15_FWversion == null)
                                {
                                    Get_TDL_FWversion(H_TT.ProdType_Selected.ODBC_EK, out clDeviceCom.Page15_FWversion);
                                }
                                BoxMeasValue = ResponseArray[1];
                                string fw = clDeviceCom.Get_PropertyValue(clDeviceCom.Page15_FWversion, BoxMeasValue);
                                ResponseArray[1] = $"{ResponseArray[1]}\t{fw}";
                                BoxMeasValue = ResponseArray[1];
                            }
                            if (Channel != null)
                            {
                                BoxMeasValue = ResponseArray[1];
                                Channel.Limits.sample_FW_Version_value = clDeviceCom.Get_PropertyValue(Channel.Page15_FWversion, BoxMeasValue);
                                var famCode = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMFamilyCode"], BoxMeasValue);
                                var sn = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMSerialNumber"], BoxMeasValue);
                                var crc = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMCRC"], BoxMeasValue);
                                //if (clDeviceCom.Get_Sample_FWversion(Channel.ODBC_EK, BoxMeasValue, out string fwversion))
                                //{
                                //    m_FWversion = fwversion;
                                //}
                            }
                            else
                            {

                            }
                            ResponseParsed = $"opcode:\t{OpCode}\t{BoxMeasValue}";
                            return;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    //return;
                case opcode.g100:
                    switch (ResponseArrayCount)
                    {
                        case 3:
                            Header = OpcodeHeader_G100;
                            
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g901:
                    switch (ResponseArrayCount)
                    {
                        case 7:
                            Header = OpcodeHeader_G901;
                            break;
                        case 11:
                            Header = OpcodeHeader_G901ext;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g200:
                    switch (ResponseArrayCount)
                    {
                        case 7:
                            Header = OpcodeHeader_G200;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.parser_error:
                    BoxMeasValue = Response;
                    if (Response.Contains("DelP")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    if (Response.Contains("WrtP")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    if (Response.Contains("PDwn")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    if (Response.StartsWith("BoxReset")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.Contains("DipSwitch")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("CalibrationBox")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("Betriebsmittel")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("FW:")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("Messbereich")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("RawVal")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("Current")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("ErrorRaw")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("CalError")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if (Response.StartsWith("WepError")) { OpCode = opcode.s999; goto case opcode.s999; }
                    if(Response.StartsWith("#rdpg")) { OpCode = opcode.rdpg; goto case opcode.rdpg; }
                    if (Response.StartsWith("#wrpg")) { OpCode = opcode.wrpg; goto case opcode.wrpg; }
                    if (i == 1)
                    {
                        goto default;
                    }
                    ResponseParsed = $"PARSER_ERROR:\t{Response}";
                    Error = true;
                    return;
                case opcode.s999:
                    BoxMeasValue = Response;
                    ResponseParsed = $"opcode:\t{OpCode}\t{Response}";
                    return;
                case opcode.rdpg:
                    string[] split = Response.Split(' ');
                    OpCode = opcode.rdpg;
                    try 
                    { 
                        BoxMeasValue = split[2];
                        long.TryParse(split[1], System.Globalization.NumberStyles.HexNumber, null, out long page);
                        ResponseParsed = $"opcode:\t{OpCode}\tPage:\t{page}\tvalue:\t{BoxMeasValue}";
                        return;
                    } catch { }
                    ResponseParsed = $"{OpCode}:\t{Response}";
                    return;
                case opcode.wrpg:
                    split = Response.Split(' ');
                    OpCode = opcode.wrpg;
                    try 
                    { 
                        BoxMeasValue = split[2];
                        long.TryParse(split[1], System.Globalization.NumberStyles.HexNumber, null, out long page);
                        ResponseParsed = $"opcode:\t{OpCode}\tPage:\t{page}\tvalue:\t{BoxMeasValue}";
                        return;
                    } catch { }
                    ResponseParsed = $"{OpCode}:\t{Response}";
                    return;
                case opcode.cmdsend:
                case opcode.state:
                    BoxMeasValue = Response;
                    ResponseParsed = $"{OpCode}:\t{Response}";
                    return;
                case opcode.error:
                    BoxMeasValue = Response;
                    ResponseParsed = Response;
                    return;
                default:
                    if (ResponseArrayCount > 0)
                    {
                        _OpCode = Check_OpCode();
                        goto again;
                    }
                    BoxMeasValue = Response;
                    ResponseParsed = $"opcode:\t{OpCode}\t{Response}";
                    return;
            }
            ResponseParsed = Parse(Header);
        }

        private string Parse(string[] header)
        {
            int i = 0;
            StringBuilder sb = new StringBuilder();
            foreach (string value in ResponseArray)
            {
                try { sb.Append(Parse_Values(header[i], i)); }
                catch { break; }
                i++;
            }
            return sb.ToString().Trim();
        }
        private string Parse_Values(string header, int answerIndex)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{header}:\t");
            switch (header)
            {
                case MN_Opcode:
                    sb.Append($"{OpCode}\t");
                    break;
                case MN_Values:
                case MN_I_set:
                    try
                    {
                        BoxMeasValue = ResponseArray[answerIndex];
                        I_Set = BoxMeasValue;
                        sb.Append($"{BoxMeasValue}\t");
                    } catch { }
                    break;
                case MN_I_AVG:
                    try
                    {
                        I_AVG = ResponseArray[answerIndex];
                        sb.Append($"{I_AVG}\t");
                    } catch { }
                    break;
                case MN_I_StdDev:
                    try 
                    { 
                        I_StdDev = ResponseArray[answerIndex]; 
                        sb.Append($"{I_StdDev}\t"); 
                    } catch { }
                    break;
                case MN_I_Error:
                    try { I_Error = ResponseArray[answerIndex]; sb.Append($"{I_Error}\t"); } catch { }
                    break;
                case MN_Temp_AVG:
                    try { Temp_AVG = ResponseArray[answerIndex]; sb.Append($"{Temp_AVG}\t"); } catch { }
                    break;
                case MN_BoxMode_HEX:
                    try
                    {
                        BoxMode_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxMode_hex}\t{header}_desc:\t{BoxMode_desc}\t");
                    } catch { }
                    break;
                case MN_BoxErrorCode_HEX:
                    try
                    {
                        BoxErrorCode_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxErrorCode_hex}\t{header}_desc:\t{BoxErrorCode_desc}\t");
                    } catch { }
                    break;
                case MN_CalStatus_HEX:
                    try
                    {
                        BoxCalStatus_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxCalStatus_hex}\t{header}_desc:\t{BoxCalStatus_desc}\t");
                    } catch { }
                    break;
                default:
                    try
                    {
                        sb.Append($"{ResponseArray[answerIndex]}\t");
                    }
                    catch { }
                    break;
            }
            string response = sb.ToString();
            if (string.IsNullOrEmpty(response)) { return ""; }
            else { return response; }
        }

        private opcode Check_OpCode()
        {
            if (ResponseArrayCount > 0)
            {
                string r = ResponseArray[0].Trim();
                return Check_OpCode_ToAnswer(r);
            }
            return opcode.parser_error;
        }
        private opcode Check_OpCode(string opcode)
        {
            return opcode.ParseOpcode(defaultOpcode: clHandler.opcode.parser_error);
        }
        private opcode Check_OpCode_ToAnswer(string opcode)
        {
            return opcode.ParseOpcode(toLower: true, defaultOpcode: clHandler.opcode.parser_error);
        }
        private opcode Check_OpCode_ToAnswer(opcode opcode)
        {
            return opcode.ToString().ParseOpcode(toLower: true, defaultOpcode: clHandler.opcode.parser_error);
        }

    }
}
