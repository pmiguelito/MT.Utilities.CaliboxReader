﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using static ReadCalibox.clConfig;
using static ReadCalibox.clLogging;
using static ReadCalibox.clDeviceCom;
using static ReadCalibox.clHandler;

namespace ReadCalibox
{
    public partial class UC_Debug_CMD : UserControl
    {
        /***************************************************************************************
        * Constructor:  Instance to load from other elements
        ****************************************************************************************/
        private static UC_Debug_CMD _Instance;
        public static UC_Debug_CMD Instance
        {
            get
            {
                if (_Instance == null)
                { _Instance = new UC_Debug_CMD(); }
                return _Instance;
            }
        }

        /***************************************************************************************
        * Constructor:
        ****************************************************************************************/
        public UC_Debug_CMD()
        {
            InitializeComponent();
        }

        private void UC_Debug_Load(object sender, EventArgs e)
        {
            Init();
            _Instance = this;
        }

        /***************************************************************************************
        * Initialization:
        ****************************************************************************************/
        private void Init()
        {
            CoB_BaudRate.SelectedIndexChanged -= CoB_BaudRate_SelectedIndexChanged;
            CoB_COM.SelectedIndexChanged -= CoB_COM_SelectedIndexChanged;
            Init_CoB_Port();
            Init_CoB_BaudRate();
            Init_CoB_CMD();
            Init_Port();
            CoB_BaudRate.SelectedIndexChanged += CoB_BaudRate_SelectedIndexChanged;
            CoB_COM.SelectedIndexChanged += CoB_COM_SelectedIndexChanged;
        }
        private void Init_CoB_Port()
        {
            var list = SerialPortList.ToList();
            list.Add("...Load");
            CoB_COM.DataSource = list;
            CoB_COM.SelectedIndex = 0;
        }

        int BaudDefault = 19200;
        private void Init_CoB_BaudRate()
        {
            CoB_BaudRate.DataSource = BaudRateList;
            CoB_BaudRate.Text = BaudDefault.ToString();
        }
        private void Init_CoB_CMD()
        {
            var ar = System.Enum.GetNames(typeof(opcode));
            List<string> list = new List<string>();
            list.Add("#RDPG");
            foreach (var item in ar)
            {
                if (item.StartsWith("S") || item.StartsWith("G"))
                {
                    list.Add(item);
                }
            }
            
            list = list.OrderBy(x => x).ToList();
            CoB_CMD.DataSource = list;
        }
        private void Init_Port()
        {
            Close_COMport();
            if (string.IsNullOrEmpty(CoB_BaudRate.Text))
            {
                CoB_BaudRate.Text = BaudDefault.ToString();
            }
            int baud = BaudDefault;
            try { baud = Convert.ToInt32(CoB_BaudRate.Text); } catch { CoB_BaudRate.Text = baud.ToString(); }
            port = SerialPort_Init(CoB_COM.Text, baud);
            //port.ReadTimeout = 200;
            //port.WriteTimeout = 200;
            Init_DatReader();
            //ThreadDR.Port = port;
        }

        /***************************************************************************************
        * SerialPort:
        ****************************************************************************************/
        public SerialPort port = new SerialPort();

        public void Close_COMport()
        {
            if (port.IsOpen) 
            { port.Close(); }
        }

        /***************************************************************************************
        * PortReader:    SerialPort Read
        ****************************************************************************************/
        SerialReaderThread _ThreadDR;
        SerialReaderThread ThreadDR
        {
            get
            {
                if(_ThreadDR == null)
                { _ThreadDR = Init_DatReader(); }
                return _ThreadDR;
            }
        }
        SerialReaderThread Init_DatReader()
        {
            SerialReaderThread SRT = new SerialReaderThread(port);
            SRT.DataReceived += ThreadDataReceived;
            return SRT;
        }

        char[] LineSpliter = new char[] { '\n', '\r' };
        void ThreadDataReceived(object s, EventArgs e)
        {
            var a = (DataEventArgs)e;
            string response = a.Data;
            if (response.Length < 1) { return; }
            if (CkB_Parse.Checked)
            {
                Message(response);
                return;
            }
            ParseMessage(response);
        }

        private void ParseMessage(string message)
        {
            message = message.Replace("*", "");
            if (message.Length < 1) { return; }
            StringBuilder sb = new StringBuilder();
            int splitter = -1;
            if (message.Contains("\n"))
            {
                splitter = 0;
            }
            else if (message.Contains("\r"))
            {
                splitter = 1;
            }

            if (splitter > -1 && message.Length > 0)
            {
                string[] resp = message.Split(LineSpliter[splitter]);
                foreach (var item in resp)
                {
                    if (item.Length > 0)
                    {
                        CMD = "";
                        DeviceResponse dr = new DeviceResponse(CMD, null, item, isDebug: true);
                        foreach (DeviceResponseValues drv in dr.ResponseList)
                        {
                            sb.Append(drv.ResponseParsed.Replace(":\t", ": ").Replace("\t", "; "));
                        }
                    }
                }
                Message(sb.ToString());
            }
        }

        private void Message(string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { Message(message); });
                return;
            }
            try
            {
                Tb_Info.Text += $"{Environment.NewLine}{watch.ElapsedMilliseconds}\t{message}";
                Tb_Info.SelectionStart = Tb_Info.Text.Length;
                Tb_Info.ScrollToCaret();
                Tb_Info.Refresh();
            }
            catch { }
        }
        System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();
        private void CMD_Send()
        {
            try
            {
                watch.Reset();
                watch.Start();
                CMD = CoB_CMD.Text;
                Message($"cmd send: {CMD}");
                _ThreadDR = Init_DatReader();
                ThreadDR.Send(CMD);
            }
            catch (Exception e)
            { 
                Tb_Info.Text += Environment.NewLine + e.Message + Environment.NewLine;
            }
        }


        /***************************************************************************************
        * Events:
        ****************************************************************************************/
        clDeviceCom DeviceCom = new clDeviceCom();
        string CMD;

        private void CoB_BaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            Init_Port();
        }

        private void CoB_COM_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CoB_COM.Text.Contains("Load"))
            {
                Init_CoB_Port();
            }
            else
            {
                Init_Port();
            }
        }

        private void Btn_Send_Click(object sender, EventArgs e)
        {
            CMD_Send();
            //string HEX = "D805020A327E722A050000009ED364B35573C15CB0962C0700000000000000E0";
            //clDeviceCom dc = new clDeviceCom();
            //dc.Get_Sample_FWversion(m_TT.ODBC_EK_Selected, HEX, out string fwversion);
        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            Tb_Info.Clear();
        }

        private void Btn_StopRead_Click(object sender, EventArgs e)
        {
            Close_COMport();
            ThreadDR.Stop();
        }
    }
}
