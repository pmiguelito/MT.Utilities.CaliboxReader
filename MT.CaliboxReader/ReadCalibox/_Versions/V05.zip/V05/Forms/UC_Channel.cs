﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using static STDhelper.clSTD;
using static STDhelper.clLogging;
using static ReadCalibox.clConfig;
using static ReadCalibox.clDeviceCom;
using static ReadCalibox.clHandler;
using MTcom;
using System.IO;

namespace ReadCalibox
{
    public partial class UC_Channel : UserControl
    {
        /**************************************************************************************
        ** Constructor: Can be used for Panel Controls Load
        ***************************************************************************************/
        #region UC Instance
        private UC_Channel _instance;
        public UC_Channel Instance
        {
            get
            {
                if (_instance == null)
                { _instance = new UC_Channel(ucCOM); }
                return _instance;
            }
        }
        #endregion UC Instance

        /**************************************************************************************
        ** Constructor: Main
        ***************************************************************************************/
        public UC_Channel(UC_COM uc_COM)
        {
            InitializeComponent();
            this.ucCOM = uc_COM;
            this.ucCOM.BeM_Changed += new EventHandler(BeM_Changed);
            _instance = this;
        }

        private void UC_Channel_Load(object sender, EventArgs e)
        {
            Init();
            Reset(true);
            _instance = this;
        }


        /**************************************************************************************
        ** Properties
        ***************************************************************************************/
        #region Properties
        public UC_COM ucCOM;
        private SerialPort port { get { return ucCOM.Serialport; } }



        /**************************************************************************************
        ** Values:     Device Measurement Values
        ***************************************************************************************/
        public clItemLimits Limits { get; set; } = new clItemLimits();

        private clDeviceLimits _DeviceLimits;
        public clDeviceLimits DeviceLimits
        {
            get { return _DeviceLimits; }
            set
            {
                _DeviceLimits = value;
                Limits.DeviceLimits = value;
            }
        }

        public DeviceResponse SampleResponse { get; set; } = new DeviceResponse(null, null);

        #endregion Properties

        
        /**************************************************************************************
        ** Constructor: Initialization
        ***************************************************************************************/
        #region Initialization
        void Init()
        {
            Init_Design();
            Init_timStateEngine();
            Init_timProcess();
            Init_timCalibration();
            RunningState_ADD(ucCOM.Ch_No, CH_State.notActive);
            Channel_No = ucCOM.Ch_No;
            try { Channel_Active_Change(ucCOM.ConnectionReady); } catch { _Active = false; }
            try { ucCOM.Readyness_Changed +=  new EventHandler(Channel_Activity_Changed); } catch { }
            try { Init_DGV(); } catch { }
            try { Init_Chart(); } catch { }
        }

        void Init_Design()
        {
            Init_Colors();
            Init_Design_Dimensions();
        }

        void Init_Colors()
        {
            Panel_Sep1.BackColor = MTcolors.MT_BackGround_HeaderFooter;
            Panel_Sep2.BackColor = MTcolors.MT_BackGround_HeaderFooter;
            Panel_Sep3.BackColor = MTcolors.MT_BackGround_HeaderFooter;
            Panel_Sep4.BackColor = MTcolors.MT_BackGround_HeaderFooter;

            Panel_Header.BackColor = MTcolors.MT_BackGround_Work;
            Panel_Button.BackColor = MTcolors.MT_BackGround_Work;
            Panel_ItemInfos.BackColor = MTcolors.MT_BackGround_Work;
            Panel_Info.BackColor = MTcolors.MT_BackGround_Work;
            Panel_Time.BackColor = MTcolors.MT_BackGround_Work;
        }

        void Init_Design_Dimensions()
        {
            AllocFont(_Lbl_Channel, 18, FontStyle.Bold);
            AllocFont(_Lbl_TAGno, 12, FontStyle.Bold);
            AllocFont(_Lbl_TAGno_TXT, 12, FontStyle.Bold);
            AllocFont(_Btn_Start, 10, FontStyle.Bold);
        }

        void Init_DGV()
        {
            if(SampleResponse == null) { SampleResponse = new DeviceResponse(null, this); }
            DGV_Progress.BackgroundColor = MTcolors.MT_BackGround_Work;
            DGV_Progress.DataSource = SampleResponse.DT_Progress;
            Font n = new Font("Tahoma", 6, FontStyle.Regular);
            DGV_Progress.ColumnHeadersDefaultCellStyle.Font = n;
            n = new Font("Tahoma", 7, FontStyle.Regular);
            DGV_Progress.RowsDefaultCellStyle.Font = n;
            DGV_Progress.MultiSelect = false;
            DGV_Progress.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGV_Progress.ReadOnly = true;
            DGV_Progress.Progress_AdminModus();
            DGV_Progress.Sort(DGV_Progress.Columns[MN_meas_time_start], ListSortDirection.Descending);
        }
        #endregion Initialization


        /**************************************************************************************
        ** Running
        ***************************************************************************************/
        #region ChannelState
        private int _Channel_No;
        public int Channel_No { get { return _Channel_No; } set { Set_ChannelNo(value); } }

        public void Set_ChannelNo(int chNo)
        {
            _Lbl_Channel.Text = chNo.ToString().PadLeft(2, '0');
            _Channel_No = chNo;
        }

        private bool _StarReady = false;
        public bool StartReady { get { return _StarReady; } set { StartReady_Change(value); } }
        private void StartReady_Change(bool enabled)
        {
            _StarReady = enabled;
            _Btn_Start.Enabled = enabled;
            _Btn_Start.BackColor = StartReady ? MTcolors.MT_rating_InWork_Active : MTcolors.MT_BackGround_White;
            _Btn_Start.ForeColor = StartReady ? MTcolors.MT_BackGround_White : Color.Black;
        }
        private bool _Running;
        public bool Running { get { return _Running; } private set { Channel_Running_Change(value); } }
        public void Channel_Running_Change(bool running)
        {
            _Running = running;
            CH_State wk = CH_State.idle;
            if (running)
            {
                wk = CH_State.inWork;
                _Btn_Start.BackColor = MTcolors.MT_rating_Alert_Active;
                _Btn_Start.ForeColor = Color.Black;
                H_UC_Betrieb.Channel_started(Channel_No);
            }
            else
            {
                if (StartReady)
                { StartReady = false; }
                wk = calQuality;
            }
            _Btn_Start.Text = !running ? "Start" : "Cancel";
            if (StartReady && !running)
            { 
                StartReady = false; 
            }
            RunningState_Change(Channel_No, wk);
            CH_WorkingStatusColors(wk);
        }

        private bool _Active;
        public bool Active { get { return _Active; } private set { Channel_Active_Change(value); } }
        private void Channel_Activity_Changed(object sender, EventArgs e)
        {
            Channel_Active_Change(ucCOM.ConnectionReady);
        }

        private void Channel_Active_Change(bool enabled)
        {
            _Active = enabled;
            StartReady = false;
            CH_State wk = enabled ? CH_State.active : CH_State.notActive;
            RunningState_Change(Channel_No, wk);
            CH_WorkingStatusColors(wk);
        }

        private void CH_WorkingStatusColors(CH_State status)
        {
            Color col = MTcolors.MT_BackGround_Work;
            Color colSep = MTcolors.MT_BackGround_HeaderFooter;
            Color colorInfoBox = MTcolors.MT_BackGround_White;
            if (Limits != null)
            {
                colorInfoBox = Limits.ErrorDetected ? MTcolors.MT_rating_Bad_Active : MTcolors.MT_BackGround_White;
                if (status == CH_State.idle && Limits.ErrorDetected) { status = CH_State.QualityBad; }
            }
            bool onlyCH = false;
            switch (status)
            {
                case CH_State.idle:
                    break;
                case CH_State.inWork:
                    colorInfoBox = MTcolors.MT_BackGround_White;
                    col = MTcolors.MT_rating_InWork_Active;
                    colSep = MTcolors.MT_BackGround_Work;
                    break;
                case CH_State.QualityBad:
                    col = MTcolors.MT_rating_Bad_Active;
                    break;
                case CH_State.QualityGood:
                    col = MTcolors.MT_rating_God_Active;
                    break;
                case CH_State.active:
                    this.Enabled = true;
                    _Btn_Start.Visible = true;
                    break;
                case CH_State.notActive:
                    this.Enabled = false;
                    _Btn_Start.Visible = false;
                    colSep = Color.SteelBlue;
                    break;
                case CH_State.error:
                    if (!onlyCH)
                    {
                        this.Enabled = true;
                        _Btn_Start.Visible = true;
                    }
                    col = MTcolors.MT_rating_Alert_Active;
                    //colSep = Color.SteelBlue;
                    break;
            }
            Tb_Info.BackColor = colorInfoBox;
            if (!onlyCH)
            {
                Panel_Header.BackColor = col;
                Panel_ItemInfos.BackColor = col;
                Panel_Time.BackColor = col;
                Panel_Info.BackColor = col;
                Panel_Button.BackColor = col;
                Panel_Sep1.BackColor = colSep;
                Panel_Sep2.BackColor = colSep;
                Panel_Sep3.BackColor = colSep;
                Panel_Sep4.BackColor = colSep;
                Chart_Measurement.BackColor = col;
                Chart_Measurement.ChartAreas[0].BackColor = col;
                Chart_Measurement.Update();
            }
        }

        private void BeM_Changed(object sender, EventArgs e)
        {
            foreach (var bem in Config_BeMsList)
            {
                if (bem.BeMname == ucCOM.BeM)
                {
                    ucCOM.Ref.m_ComPortDetails.Baudrate = bem.Baudrate;
                    ucCOM.Ref.m_ComPortDetails.ReadDelay = bem.BeMdelay;
                    ucCOM.Ref.m_ComPortDetails.ReadLine = bem.BeMreadLine;
                    break;
                }
            }
        }
        #endregion ChannelState

        /**************************************************************************************
        * Executions:    Start & Stop
        ***************************************************************************************/
        #region StartStop
        public string BeM_Selected;
        public int ReadDelay_Selected;

        public bool Start()
        {
            if (ucCOM.Start(false))
            {
                try { GUI_Infos(); } catch { } /* muss ausgeführt werden bevor T&T Gui reset wird*/
                Channel_Running_Change(true);
                timStateEngine.Start();
                m_state = gProcMain.getReadyForTest;
                return true;
            }
            else
            {
                Gui_Message(message: $"ERROR: ComPort {ucCOM.Ref.m_ComPortDetails.PortName} ist besetzt");
                Channel_Running_Change(false);
            }
            H_UC_Betrieb.Channel_started(); /*this cancel the other ready channels*/
            return false;
        }
        public void Stop()
        {
            if (Running)
            {
                try
                {
                    WaitingDetails = new WaitDetails() { Answer_Received = false, cmd_AnswerWaiting = opcode.s999 };
                    CMD_Send(opcode.S999);
                    if (DGV_Progress.Rows.Count > 0)
                    {
                        DGV_Progress.ClearSelection();
                    }

                    System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();
                    watch.Start();
                    while (!WaitingDetails.Answer_Received && watch.ElapsedMilliseconds < 5000)
                    {
                        Thread.Sleep(200);
                        Application.DoEvents();
                    }
                    //DeviceCom.SendCMD(Instance, opcode.S999, true);
                    Thread.Sleep(1000);
                    Application.DoEvents();
                    
                    H_Log.Save(Instance, "****** END PROCESS *** END PROCESS *** END PROCESS *** END PROCESS *** END PROCESS ******", opcode.state);
                    port.DiscardOutBuffer();
                    Application.DoEvents();
                    H_Log.ForceLog();
                }
                catch (Exception e)
                {
                    ErrorHandler("Stop", exception: e);
                    Gui_Message(message: e.Message);
                }
                Channel_Running_Change(false);
            }
            else
            {
                m_state = gProcMain.stop_stateEngine;
            }
            timProcess.Stop();
            timCalibration.Stop();
            timMeasurement.Stop();
            ucCOM.Stop();
            H_TT.SetFocus_Input();
        }
        private void Btn_Start_Click(object sender, EventArgs e)
        {
            bool running = _Btn_Start.Text == "Start";
            if (running)
            { 
                Start(); 
            }
            else
            {
                stateMessageError = "User Cancelation";
                m_state = gProcMain.error;
            }
            H_TT.SetFocus_Input();
        }
        #endregion StartStop



        /**************************************************************************************
        ** PortReader:    SerialPort Read
        ***************************************************************************************/
        #region PortReader
        private SerialReaderThread _ThreadDR;
        private SerialReaderThread ThreadDR
        {
            get
            {
                if (_ThreadDR == null)
                { _ThreadDR = Init_DatReader(); }
                return _ThreadDR;
            }
        }
        private SerialReaderThread Init_DatReader()
        {
            SerialReaderThread SRT = new SerialReaderThread(port);
            SRT.DataReceived += ThreadDataReceived;
            return SRT;
        }

        private char[] LineSpliter = new char[] { '\n', '\r' };
        private void ThreadDataReceived(object s, EventArgs e)
        {
            var a = (DataEventArgs)e;
            ParseMessage(a.CMD_send, a.Data);
        }

        private void ParseMessage(string cmd, string message)
        {
            message = message.Replace("*", "");
            if (message.Length < 1) { return; }
            SampleResponse.Response = message;
            H_Log.Save(this, SampleResponse);
            WaitingDetails.cmd_AnswerReceive = SampleResponse.OpCode_Response;
            if (WaitingDetails.cmd_AnswerWaiting == WaitingDetails.cmd_AnswerReceive)
            {
                WaitingDetails.Answer_Received = true;
            }
        }

        private void CMD_Send(opcode cmd)
        {
            try
            {
                string cmdtxt = cmd.ToString();
                Enum.TryParse<opcode>(cmdtxt.ToLower(), out opcode cmdresponse);
                WaitingDetails.cmd_Request = cmd;
                WaitingDetails.Answer_Received = false;
                WaitingDetails.cmd_AnswerWaiting = cmdresponse;
                H_Log.Save(this, cmdtxt, opcode.cmdsend);
                ThreadDR.Send(cmd);
            }
            catch (Exception e)
            {
                Tb_Info.Text += e.Message + Environment.NewLine;
            }
        }
        #endregion PortReader


        /**************************************************************************************
        ** GUI:     Reset Informations
        ***************************************************************************************/
        #region Reset
        public void Reset(bool forceReset = false)
        {
            GUI_Infos_Reset(forceReset);
            Reset_onStart();
        }
        private void GUI_Infos_Reset(bool forceReset = false)
        {
            if (Limits.tag_nr != 0 || forceReset)
            {
                Ttip.Active = false;
                _Lbl_TAGno.Text = "";
                _Lbl_Item.Text = "";
                _Lbl_Pdno.Text = "";
                _Lbl_User.Text = "";
                _Lbl_ProdType.Text = "";
                _Lbl_TimeStart.Text = "";
                _Lbl_TimeEnd.Text = "";
                _Lbl_PassNo.Text = "";
                _Lbl_CalMode.Text = "";
                Tb_Info.Text = "";
                Limits = new clItemLimits();
                ChB_Chart.Checked = false;
                ChB_Chart.Visible = false;
                Gui_Message();
            }
        }
        private void Reset_Processe()
        {
            m_BoxReseted = false;
            m_BewertungExecuted = false;
            m_state_ProcessRunning = gProcMain.idle;
            m_TestRunning = false;
            processeNr = 0;
            m_Calibration_Running = false;
            CountCalib = 0;
            calQuality = CH_State.idle;
            ProcesseRunning = gProcMain.idle;
            ProcesseLast = gProcMain.wait;
        }

        private void Reset_onStart()
        {
            m_state_Last = gProcMain.idle;
            SampleResponse = new DeviceResponse(null, this);
            Reset_Processe();
            m_DBinit = false;
            stateMessageError = null;
            LogPathMeas = Create_TMP_MeasPath(_Lbl_Channel.Text);
            BeM_Selected = ucCOM.BeM;
            ReadDelay_Selected = ucCOM.Ref.m_ComPortDetails.ReadDelay;
            Init_DGV();
        }
        #endregion Reset

        /**************************************************************************************
        ** GUI:     Update channel Informations
        ***************************************************************************************/
        #region Information
        private ToolTip _Ttip;
        private ToolTip Ttip
        {
            get
            {
                if (_Ttip == null)
                {
                    _Ttip = new ToolTip()
                    { Active = true, UseAnimation = true, UseFading = true, ShowAlways = true, IsBalloon = true, InitialDelay = 1000, AutoPopDelay = 3000, ReshowDelay = 500 };
                }
                return _Ttip;
            }
            set { _Ttip = value; }
        }

        public void GUI_Infos(bool reset = false)
        {
            Reset();
            if (!reset)
            {
                Reset_onStart();
                Limits = H_UC_Betrieb.Limits;
                /* values set in UC_Betrieb
                Limits.ODBC_EK = m_TT.ODBC_EK_Selected;
                Limits.ODBC_TT = m_TT.ODBC_TT_Selected;
                Limits.tag_nr = m_TT.tSensor.tag_nr;
                Limits.sensor_id = m_TT.tSensor.sensor_id;
                Limits.ProductionType_ID = m_TT.ProdType_ID;
                Limits.ProductionType_Desc = m_TT.ProdType_Desc;
                */
                Limits.UserName = H_TT.UserName;
                Limits.User_ID = H_TT.UserName_ID;

                Limits.DeviceLimits = DeviceLimits;
                Limits.channel_no = Channel_No;
                Limits.meas_time_start = DateTime.Now;

                _Lbl_TAGno.Text = Limits.tag_nr.ToString();
                _Lbl_Item.Text = Limits.item;
                _Lbl_Pdno.Text = Limits.pdno;
                _Lbl_User.Text = Limits.UserName;
                _Lbl_ProdType.Text = Limits.ProductionType_Desc;
                _Lbl_TimeStart.Text = Limits.meas_time_start.ToShortTimeString();
                _Lbl_TimeEnd.Text = Limits.meas_time_end_Theo.ToShortTimeString();
                _Lbl_PassNo.Text = Limits.pass_no.ToString();
                _Lbl_CalMode.Text = Limits.Cal_Desc;
                
                Tb_Info.Text = "";
                ChB_Chart.Checked = false;
            }
        }

        public void ShowToolTip()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { ShowToolTip(); });return;
            }
            string tpTxt = $"COMport:\t{ucCOM.Ref.m_ComPortDetails.PortName}\r\n" +
                            $"CalMode_ID:\t{Limits.CalMode_ID}\r\n" +
                            $"Technology_ID:\t{Limits.Technology_ID}\r\n";
            if (Limits.DeviceLimits != null)
            {
                tpTxt +=    $"Device FW:\t{Limits.DeviceLimits.FW_Version}\r\n" +
                            $"Device cop:\t{Limits.DeviceLimits.Compiled}";
            }
            Ttip.SetToolTip(_Lbl_Channel, tpTxt);
            Ttip.Active = true;
        }
        #endregion Information


        /**************************************************************************************
        * Log Message:
        ***************************************************************************************/
        #region Log
        private const string logEnding = ".log";
        private string LogFile(string filename)
        {
            string path = LogDirectory + @"\" + filename + "_000" + logEnding;
            var files = Directory.GetFiles(LogDirectory, $"{filename}*{logEnding}");
            int count = files.Count();
            if (count > 0)
            {
                FileInfo fi = new FileInfo(files[count - 1]);
                if (fi.Length > 900000)
                {
                    int c = fi.Name.LastIndexOf('_');
                    string sub = fi.Name.Substring(0, c);
                    
                    int fNo = 1;
                    if (sub == filename)
                    {
                        string fn = fi.Name.Replace(logEnding, "");
                        string no = fn.Substring(c+1);
                        int.TryParse(no, out fNo);
                        fNo++;
                    }
                    path = LogDirectory + @"\" + sub + "_" + fNo.ToString().PadLeft(3, '0') + logEnding;
                }
            }
            return path;
        }


        private string Create_TMP_MeasPath(string portName)
        {
            LogDirectory = Config_Initvalues.LogMeas_Path;
            string filename = "Calibox_CH" + portName;// + ".log";
            return LogFile(filename);
        }
        public string LogPathMeas { get; set; }
        public string LogDirectory { get; set; }
        //public bool LogPathActive { get { return Config_Initvalues.MeasLog_Active; } }
        #endregion Log

        /**************************************************************************************
       'FUNCTION:    State Engine
       ****************************************************************************************/
        private System.Windows.Forms.Timer timStateEngine;
        private void Init_timStateEngine()
        {
            timStateEngine = new System.Windows.Forms.Timer() { Interval = 500 };
            timStateEngine.Tick += new EventHandler(timStateEngine_Tick);
        }

        public bool m_DBinit = false;
        public bool m_timeOutActive = false;
        public bool m_Calibration_Running = false;
        public bool m_TestRunning = false;

        public bool m_BewertungExecuted = false;
        public bool m_BoxReseted { get; set; } = false;
        
        public DateTime m_timeOutDevice;
        public DateTime m_timeOutTest;
        public int m_processCounter = 0;
        public int m_processCounterTotal = 0;
        public DateTime m_procStart;
        public DateTime m_procEnd;
        public int m_stateIntervalSTD = 100;
        private gProcMain m_state_Last;
        private gProcMain _m_state;
        public gProcMain m_state
        {
            get { return _m_state; }
            set
            {
                if (!timStateEngine.Enabled)
                { timStateEngine.Interval = m_stateIntervalSTD; timStateEngine.Start(); }
                _m_state = value;
            }
        }
        public gProcMain m_state_AfterWait;
        public gProcMain m_state_WaitCaller;
        private gProcMain m_state_ProcessRunning = gProcMain.idle;
        
        /* MAIN PROCESSES *********************************************************************
        * FUNCTION:    timStateEngine_Tick
        '**************************************************************************************/
        clDeviceCom DeviceCom = new clDeviceCom();
        CH_State calQuality = CH_State.idle;
        
        string stateMessageError = "";
        string attents;

        public void timStateEngine_Tick(object sender, EventArgs e)
        {
            if ((m_state != m_state_Last) || (m_timeOutActive))
            {
                m_state_Last = m_state;
                string message = "";
                switch (m_state)
                {
                    case gProcMain.getReadyForTest:
                        GetReadyForTest();
                        break;
                    case gProcMain.StartProcess:
                        StartProcess();
                        break;
                    case gProcMain.BoxStatus:
                        BoxStatus();
                        break;
                    case gProcMain.BoxReset:
                        BoxReset();
                        break;
                    case gProcMain.TestFinished:
                        TestFinished();
                        break;
                    case gProcMain.FWcheck:
                        FWcheck();
                        break;
                    case gProcMain.SensorCheck:
                        SensorCheck();
                        break;
                    case gProcMain.Calibration:
                        Calibration();
                        break;
                    case gProcMain.wait:
                        if (!WaitingDetails.WaitRunning)
                        {
                            WaitingDetails.WaitRunning = true;
                            timStateEngine.Interval = 250;
                            m_timeOutDevice = DateTime.Now.AddMilliseconds(WaitingDetails.Wait_ms);
                            message = $"wait: {WaitingDetails.Wait_ms / 1000} sec\t{WaitingDetails.Message}";
                            m_timeOutActive = true;
                            timCalibration.Stop();
                            timProcess.Stop();
                            timMeasurement.Stop();
                            H_Log.Save(Instance, m_state, opcode.state, message);
                        }
                        TimeSpan timeDiffDevice = (m_timeOutDevice - DateTime.Now);
                        Waittime_Show(timeDiffDevice, WaitingDetails.Message);
                        if (timeDiffDevice.TotalSeconds > 0)
                        {
                            Application.DoEvents();
                            if (WaitingDetails.Answer_Wait)
                            {
                                if (!WaitingDetails.Answer_Received) { return; }
                            }
                            else
                            {
                                return;
                            }
                        }
                        WaitingDetails.WaitRunning = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        m_timeOutActive = WaitingDetails.TimeOutActive;
                        if (WaitingDetails.ProcNext != gProcMain.error)
                        {
                            if (WaitingDetails.ProcessRunning) { timProcess.Start(); }
                            if (WaitingDetails.CalibrationRunning) { timCalibration.Start(); }
                        }
                        m_state = WaitingDetails.ProcNext;
                        break;
                    case gProcMain.Bewertung:
                        Bewertung();
                        break;
                    case gProcMain.DBinit:
                        DBinit();
                        break;
                    case gProcMain.error:
                        Error();
                        break;
                    case gProcMain.idle:
                        m_timeOutActive = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        break;
                    case gProcMain.stop_stateEngine:
                        timStateEngine.Stop();
                        break;
                    default:
                        m_timeOutActive = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        break;
                }
            }
        }

        /***************************************************************************************
        ** StateMachine:  Functions
        ****************************************************************************************/
        #region StateMachineFunctions

        private void GetReadyForTest()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            H_Log.Save(Instance, m_state, opcode.state);
            timStateEngine.Interval = m_stateIntervalSTD;
            //TODO: if calibox identification not executed do that
            //DeviceCom.SendCMD(ucCH, opcode.S999, false); /*Identification CALIBOX*/
            //Wait(2000, gProcMain.StartProcess, "Test Start", true, false);
            m_state = gProcMain.StartProcess;
        }

        private void StartProcess()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            m_state_ProcessRunning = m_state;
            H_Log.Save(Instance, m_state, opcode.state);
            Gui_Message(m_state);
            clDataBase.Get_TDLpropertiesFromDB(Limits.ODBC_EK, ref TDLproperties);
            clDataBase.Get_TDL_Page15(Limits.ODBC_EK, out PageProperties_15);
            Get_Sampel_FWversionPropertie(Limits.ODBC_EK, out Page15_FWversion);
            Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: Limits.Cal_Desc, errorcode: "0");
            timProcess.Start();
        }

        private void BoxStatus()
        {
            if (!m_timeOutActive) m_timeOutActive = true;
            Gui_Message(m_state);
            bool BoxFound = false;
            if (m_state_ProcessRunning != m_state)
            {
                m_state_ProcessRunning = m_state;
                m_processCounter = 0;
                m_processCounterTotal = 3;
                WaitingDetails.Answer_Received = false;
                Set_Progress("BoxStatus", errorcode: "0");
            }
            m_processCounter++;
            WaitingDetails.Message = Attends(m_processCounter, m_processCounterTotal);
            Gui_Message(m_state, attents: WaitingDetails.Message);
            BoxFound = WaitingDetails.Answer_Received;
            if (BoxFound)
            {
                Set_Progress("BoxStatus", errorcode: "2");
                m_state = gProcMain.idle;
                return;
            }
            if (m_processCounter <= m_processCounterTotal)
            {
                if (!BoxFound)
                {
                    CMD_Send(opcode.G100);
                    Wait(2000);
                }
            }
            else
            {
                Set_Progress("BoxStatus", errorcode: "1");
                m_timeOutActive = false;
                m_state = gProcMain.error;
                stateMessageError = "Keine Sensor Kommunikation";
                H_Log.Save(Instance, m_state, opcode.state, stateMessageError);
            }
        }

        private void BoxReset()
        {
            if (m_timeOutActive) m_timeOutActive = true;
            if (m_state_ProcessRunning != m_state)
            {
                m_state_ProcessRunning = m_state;
                m_processCounter = 0;
                m_processCounterTotal = 3;
                WaitingDetails.Answer_Received = false;
                CMD_Send(opcode.S999);
            }
            m_processCounter++;
            WaitingDetails.Message = Attends(m_processCounter, m_processCounterTotal);
            Gui_Message(m_state, attents: WaitingDetails.Message);
            H_Log.Save(Instance, m_state, opcode.state, WaitingDetails.Message);
            m_BoxReseted = WaitingDetails.Answer_Received;
            if (m_BoxReseted)
            {
                m_state = gProcMain.idle;
                ShowToolTip();
                return;
            }
            if (m_processCounter < m_processCounterTotal + 1)
            {
                if (!m_BoxReseted)
                {
                    Wait(5000);
                }
            }
            else
            {
                stateMessageError = "Keine BOX Kommunikation";
                H_Log.Save(Instance, m_state, opcode.state, stateMessageError);
                m_state = gProcMain.error;
            }
        }

        private void TestFinished()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            timCalibration.Stop();
            m_state_ProcessRunning = m_state;
            H_Log.Save(Instance, m_state, opcode.state);
            //if (!m_TestRunning)
            { 
                Stop(); 
            }
            //else
            //{
            //    m_state = gProcMain.idle;
            //}
        }

        private void FWcheck()
        {
            if (!m_timeOutActive) m_timeOutActive = true;
            if (m_state_ProcessRunning != m_state)
            {
                m_TestRunning = true;
                m_state_ProcessRunning = m_state;
                m_processCounter = 0;
                m_processCounterTotal = 5;
                CMD_Send(opcode.G015); /* must be send bevor execute other functions*/
                Set_Progress("FWversion", errorcode: "0");
                Thread.Sleep(100);
                if (!Limits.sample_FW_Version_Cal_active)
                {
                    H_Log.Save(Instance, m_state_ProcessRunning, opcode.state, $"active = {Limits.sample_FW_Version_Cal_active}");
                    Set_Progress("FWversion", errorcode: "0");
                    m_state = gProcMain.SensorCheck;
                    return;
                }
                WaitingDetails.Answer_Received = false;
            }
            string fwmessage = $"Sensor: {Limits.sample_FW_Version_value} DB: {Limits.sample_FW_Version} ";
            if (Limits.sample_FW_Version_ok)
            {
                Set_Progress("FWversion", value: fwmessage, errorcode: Limits.sample_FW_Version_state.ToString());
                WaitingDetails.Message = $"{attents}\t{fwmessage}";
                H_Log.Save(Instance, m_state_ProcessRunning, opcode.state, WaitingDetails.Message);
                m_state = gProcMain.SensorCheck;
                return;
            }
            m_processCounter++;
            attents = Attends(m_processCounter, m_processCounterTotal);
            WaitingDetails.Message = $"{attents}\t{fwmessage}";
            Gui_Message(m_state, WaitingDetails.Message);
            bool counterProc = m_processCounter < m_processCounterTotal;
            if (m_processCounter < m_processCounterTotal)
            {
                if (!Limits.sample_FW_Version_ok)
                {
                    CMD_Send(opcode.G015);
                    Wait(2000, false);
                }
            }
            else
            {
                Set_Progress("FWversion", value: fwmessage, errorcode: Limits.sample_FW_Version_state.ToString());
                stateMessageError = $"{fwmessage}";
                Limits.ErrorDetected = true;
                m_state = gProcMain.error;
            }
        }

        private void SensorCheck()
        {
            if (!m_timeOutActive) m_timeOutActive = true;
            if (m_state_ProcessRunning != m_state)
            {
                m_TestRunning = true;
                m_state_ProcessRunning = m_state;
                m_processCounter = 0;
                m_processCounterTotal = 5;
                WaitingDetails.Answer_Received = false;
                Set_Progress("SensorStatus", errorcode: "0");
                //CMD_Send(opcode.G015); /* this is necessary to run G906*/
                Thread.Sleep(300);
            }
            m_processCounter++;
            WaitingDetails.Message = Attends(m_processCounter, m_processCounterTotal);
            Gui_Message(m_state, attents: WaitingDetails.Message);
            H_Log.Save(Instance, m_state, opcode.state, WaitingDetails.Message);
            if (!WaitingDetails.Answer_Received)
            {
                CMD_Send(opcode.G906);
                Wait(2000, false);
            }
            else
            {
                Set_Progress("SensorStatus", value: SampleResponse.BoxMeasValue, errorcode: "2");
                m_state = gProcMain.idle;
            }
            if (m_processCounter >= m_processCounterTotal || SampleResponse.OpCode_Response == opcode.s999)
            {
                stateMessageError = "NO SENSOR";
                Set_Progress("SensorStatus", errorcode: "1");
                H_Log.Save(Instance, stateMessageError, opcode.state);
                m_state = gProcMain.error;
                return;
            }
        }

        private void Calibration()
        {
            if (!m_timeOutActive)
            {
                m_timeOutActive = true;
                m_processCounter = 0;
                WaitingDetails.Answer_Received = false;
                if (timProcess.Enabled)
                { timProcess.Stop(); }
            }
            m_processCounter++;
            if (m_state_ProcessRunning != m_state)
            {
                m_state_ProcessRunning = m_state;
                WaitingDetails.Message = $"Calib Modus: {Limits.CalMode}/{Limits.Cal_Desc}";
                CMD_Send(Limits.CalMode);
                //Wait(2000);
                WaitingDetails.CalibrationRunning = true;
                m_Calibration_Running = true;
                timCalibration.Start();
                Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: Limits.Cal_Desc, errorcode: "00");
            }
        }

        private void Bewertung()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            timCalibration.Stop();
            m_state_ProcessRunning = m_state;
            m_BewertungExecuted = true;
            m_TestRunning = false;
            try
            {
                string state = Limits.test_ok ? "2" : "1";
                Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: Limits.Cal_Desc, errorcode: state);
            }
            catch { }
            Limits.meas_time_end = DateTime.Now;
            Limits.test_ok = calQuality == CH_State.QualityGood ? true : false;
            if (!Save_Values_To_DB())
            {
                stateMessageError = "ERROR: DataBank speichern Bewertung";
                H_Log.Save(Instance, gProcMain.Bewertung, opcode.state, stateMessageError);
                m_state = gProcMain.error;
                return;
            }
            string quality = Limits.test_ok ? "Gut" : "Schlecht";
            string message = $"Bewertung: {quality}\tduration: {Limits.meas_time_duration.ToStringMin()}";
            H_Log.Save(Instance, gProcMain.Bewertung, opcode.state, message);
            if (!Limits.ErrorDetected) { Gui_Message(message: message); }
            m_state = gProcMain.TestFinished;
        }

        private void DBinit()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            m_state_ProcessRunning = m_state;
            m_TestRunning = true;
            string message = $"sensorID: {Limits.sensor_id}\tTAG-Nr: {Limits.tag_nr}\tPassNo: {Limits.pass_no}";
            if (!Save_Values_To_DB_INIT())
            {
                stateMessageError = "ERROR: DataBank speichern INIT";
                message += $" {stateMessageError}";
                m_state = gProcMain.error;
            }
            else
            {
                m_DBinit = true;
                m_state = gProcMain.idle;
            }
            H_Log.Save(Instance, m_state_ProcessRunning, opcode.state, message);
        }

        private void Error()
        {
            if (m_timeOutActive) m_timeOutActive = false;
            timCalibration.Stop();
            m_timeOutActive = false;
            Limits.ErrorDetected = true;
            string message = null;
            if (!string.IsNullOrEmpty(stateMessageError))
            {
                message = $"ERROR: {stateMessageError}\t{m_state_ProcessRunning}";
                Gui_Message(message);
            }
            if (!string.IsNullOrEmpty(Limits.ErrorMessage))
            {
                message = $"ERROR: {Limits.ErrorMessage}\t{m_state_ProcessRunning}";
                Gui_Message(message);
            }
            if (!string.IsNullOrEmpty(SampleResponse.BoxErrorCode_hex))
            {
                if (SampleResponse.BoxErrorCode_hex != "0")
                {
                    message = $"ERROR: {SampleResponse.BoxErrorCode_hex} - {SampleResponse.BoxErrorCode_desc}\t{m_state_ProcessRunning}";
                    Gui_Message(message);
                }
            }
            if(message == null)
            {
                message = $"ERROR: ";
                Gui_Message(message);
            }

            H_Log.Save(Instance, m_state, opcode.Error, message);
            if (m_TestRunning)
            {
                m_state = gProcMain.Bewertung;
                return;
            }
            DGV_Progress.ClearSelection();
            m_timeOutActive = false;
            m_state = gProcMain.idle;
            Stop();
        }

        #endregion StateMachineFunctions

        /***************************************************************************************
        ** GUI Message:  Error
        ****************************************************************************************/
        #region GUI Message
        private void GUI_TXT(string message, bool addMessage = false)
        {
            bool error = false;
            if (string.IsNullOrEmpty(message)) { return; }
            else
            {
                error = message.ToLower().Contains("error:");
                message = message.Replace("\t", Environment.NewLine);
            }
            if (addMessage)
            {
                string show = (message + Environment.NewLine + Tb_Info.Text).Trim();
                int count = show.Split('\r').Length - 1;
                if (count < 20)
                { Tb_Info.Text = show.Trim(); }
                else
                {
                    int length = show.LastIndexOf(Environment.NewLine);
                    message = show.Substring(0, length).Trim();
                }
            }
            else { message = message.Trim(); }
            GUI_Message(message);
            if (error)
            {
                Limits.ErrorDetected = true;
                if (!Config_Initvalues.LogError_Active)
                { H_Log.Save(Instance, message, opcode.Error); }
            }
            //Tb_Info.Refresh();
        }
        private void GUI_Message(string message)
        {
            if (InvokeRequired)
            {
                try { this.Invoke((MethodInvoker)delegate { GUI_Message(message); }); }
                catch (Exception a)
                { ErrorHandler("GUI_Error_TXT", exception: a); }
                return;
            }
            Tb_Info.Text = message;
            //Tb_Info.Refresh();
        }
        
        /*******************************************************************************************************************
        ** FUNCTION:    Wait
        ********************************************************************************************************************/
        public bool calibrationRunning = false;
        
        private struct WaitDetails
        {
            public bool TimeOutActive { get; set; }
            public bool WaitRunning { get; set; }
            public bool ProcessRunning { get; set; }
            public bool CalibrationRunning { get; set; }
            public gProcMain ProcNext { get; set; }
            public string Message { get; set; }
            public int Wait_ms { get; set; }
            
            public opcode cmd_AnswerWaiting { get; set; }
            public opcode cmd_AnswerReceive { get; set; }
            public opcode cmd_Request { get; set; }
            public bool Answer_Received { get; set; }
            public bool Answer_Wait { get; set; }
        }

        private WaitDetails WaitingDetails = new WaitDetails();

        private void Wait(int wait, gProcMain procNext, bool waitAnswer = true)
        {
            WaitingDetails.TimeOutActive = m_timeOutActive;
            WaitingDetails.WaitRunning = false;
            WaitingDetails.ProcessRunning = timProcess.Enabled;
            WaitingDetails.CalibrationRunning = timCalibration.Enabled;
            WaitingDetails.ProcNext = procNext;
            WaitingDetails.Wait_ms = wait;
            WaitingDetails.Answer_Wait = waitAnswer;
            m_state = gProcMain.wait;
        }
        private void Wait(int wait, bool waitAnswer = true)
        {
            Wait(wait, m_state, waitAnswer);
        }

        public void Waittime_Show(TimeSpan timeDiff, string message)
        {
            string time = TimeDiff(timeDiff);
            Gui_Message(time, message: message);
        }
        public void Waittime_Show(double timeDiff, gProcMain callerState, string message = null)
        {
            string time = TimeDiff(timeDiff);
            Gui_Message(time, callerState, message);
        }

        public void Waittime_Show_Cal(string message)
        {
            Waittime_Show(Limits.meas_time_remain.TotalSeconds, m_state, message);
        }

        public void Gui_Message(string time, gProcMain callerState = gProcMain.idle, string message = null, string attents = null)
        {
            Task.Factory.StartNew(() =>
            {
                StringBuilder sb = new StringBuilder();
                if (callerState != gProcMain.idle) { sb.Append(callerState.ToString()); }
                sb.Append(Environment.NewLine);
                if (!string.IsNullOrEmpty(time))
                {
                    sb.Append(time);
                    sb.Append(Environment.NewLine);
                }
                if (!string.IsNullOrEmpty(attents))
                {
                    sb.Append(time);
                    sb.Append(Environment.NewLine);
                }
                if (!string.IsNullOrEmpty(message)) { sb.Append(message.Trim()); }
                GUI_TXT(sb.ToString(), false);
            });
        }
        public void Gui_Message(gProcMain callerState = gProcMain.idle, string message = null, string attents = null)
        {
            Gui_Message(null, callerState, message, attents);
        }

        #endregion GUI Message

        /* CALIBRATION *************************************************************************
        'FUNCTION:    Process Calibration
                      process steps
        ****************************************************************************************/
        #region Calibration
        private System.Windows.Forms.Timer timProcess;
        private void Init_timProcess()
        {
            timProcess = new System.Windows.Forms.Timer() { Interval = 1000 };
            timProcess.Tick += new EventHandler(timProcesse_Tick);
        }

        gProcMain ProcesseLast = gProcMain.wait;
        gProcMain ProcesseRunning = gProcMain.idle;
        int processeNr = 0;
        int _processCount = 0;
        int processeCount
        {
            get
            {
                if (_processCount == 0)
                { _processCount = gProgress.Count; }
                return _processCount;
            }
        }
        bool ProcesseLastArrived { get { return processeNr == processeCount; } }
        public void timProcesse_Tick(object sender, EventArgs e)
        {
            if (m_state == gProcMain.error || Limits.ErrorDetected)
            {
                timCalibration.Stop();
                timMeasurement.Stop();
                timProcess.Stop();
                return;
            }
            else
            if (ProcesseRunning != ProcesseLast && (m_state == gProcMain.idle || m_state == gProcMain.StartProcess))
            {
                bool nextProcess = false;
                switch (m_state)
                {
                    case gProcMain.StartProcess:
                        processeNr = 0;
                        ProcesseRunning = gProgress[0];
                        nextProcess = true;
                        break;
                    default:
                        nextProcess = true;
                        break;
                }
                if (nextProcess && !Limits.ErrorDetected)
                {
                    if (!ProcesseLastArrived) { processeNr++; }
                    ProcesseLast = ProcesseRunning;
                    ProcesseRunning = gProgress[processeNr];
                    m_state = ProcesseRunning;
                }
                if (ProcesseLastArrived)
                {
                    timCalibration.Stop();
                    timMeasurement.Stop();
                    timProcess.Stop();
                }
            }
        }
        #endregion Calibration

        /***************************************************************************************
        'FUNCTION:    Save Result to DataBase
        ****************************************************************************************/
        private bool Save_Values_To_DB()
        {
            bool result = clDataBase.MeasVal_Update(Limits);
            clDataBase.MeasValTemp_Insert(Limits, SampleResponse.DT_Progress);
            return result;
        }

        private bool Save_Values_To_DB_INIT()
        {
            return clDataBase.MeasVal_Insert_Init(Limits);
        }

        /***************************************************************************************
        'Values:     TDL Properties
        ****************************************************************************************/
        public List<clTDLproperty> PageProperties_15;
        public clTDLproperty Page15_FWversion;
        /// <summary>
        /// propertie, class
        /// </summary>
        public Dictionary<int, Dictionary<string, clTDLproperty>> TDLproperties;


        /*******************************************************************************************************************
        * FUNCTION:    Process Calibration GUI
        ********************************************************************************************************************/
        private void Set_Progress(string boxmode_hex, string boxmode_desc=null, string value = null, string errorcode=null)
        {
            if (string.IsNullOrEmpty(boxmode_desc)) { boxmode_desc = boxmode_hex; }
            SampleResponse.Set_Progress(boxmode_hex, boxmode_desc, value, errorcode);
        }

        public void Update_DGVprogress()
        {
            try
            {
                if (DGV_Progress.InvokeRequired)
                {
                    DGV_Progress.Invoke((MethodInvoker)delegate { Update_DGVprogress(); });
                    return;
                }
                if (DGV_Progress.Rows.Count > 0)
                {
                    foreach(DataGridViewRow item in DGV_Progress.Rows)
                    {
                        item.Selected = false;
                        var value = item.Cells[MN_BoxErrorCode_HEX].Value;
                        if(value != null)
                        {
                            switch (value.ToString())
                            {
                                case "":
                                case "0":
                                    break;
                                case "00":
                                case "2":
                                    try { item.DefaultCellStyle.BackColor = MT_Colors[MTfonts.clMTcolors.selection.rating_GOOD_active]; }
                                    catch { }
                                    break;
                                default:
                                    try { item.DefaultCellStyle.BackColor = MT_Colors[MTfonts.clMTcolors.selection.rating_BAD_active]; }
                                    catch { }
                                    break;
                            }
                        }
                    }
                    DGV_Progress.Sort(DGV_Progress.Columns[MN_meas_time_start], ListSortDirection.Descending);
                    DGV_Progress.Rows[0].Selected = true;
                    DGV_Progress.FirstDisplayedScrollingRowIndex = 0;
                    //DGV_Progress.Refresh();
                }
            }
            catch { }
        }

        /*******************************************************************************************************************
        * FUNCTION:    Process Calibration Variables
        ********************************************************************************************************************/
        private System.Windows.Forms.Timer timCalibration;
        private void Init_timCalibration(bool start = false, int interval = 250)
        {
            timCalibration = new System.Windows.Forms.Timer() { Interval = interval };
            timCalibration.Tick += new EventHandler(timCalibration_Tick);
            if (start)
            { timCalibration.Start(); }
        }

        /*******************************************************************************************************************
        *FUNCTION:    State Engine Calibration
        ********************************************************************************************************************/
        int CountCalib = 0;
        int CalibNoAnswerCounter = 0;
        string noAnswer = "";
        bool g901Receved = false;
        string CalibLastMode = "";

        public void timCalibration_Tick(object sender, EventArgs e)
        {
            if (m_state == gProcMain.error || Limits.ErrorDetected) 
            { timProcess.Stop(); return; }
            if (Answer())
            {
                CalibNoAnswerCounter = 0;
                WaitingDetails.cmd_AnswerReceive = opcode.state;
            }
            else
            {
                CalibNoAnswerCounter++;
            }
            if (m_state == gProcMain.Calibration)
            {
                if (CountCalib == 0)
                {
                    timCalibration.Interval = 1000;
                    CalibNoAnswerCounter = 0;
                    calibrationRunning = true;
                    g901Receved = false;
                    CMD_Send(opcode.G901);
                    CountCalib++;
                    return;
                }
                CountCalib++;
                if(!g901Receved)
                {
                    if (CalibNoAnswerCounter > 30)
                    {
                        CMD_Send(opcode.G901);
                        CalibNoAnswerCounter = 0;
                    }
                }
                if (SampleResponse.BoxMode_desc != CalibLastMode)
                {
                    Limits.Cal_BoxMode_desc = SampleResponse.BoxMode_desc;
                    Limits.Cal_Stopwatch = new System.Diagnostics.Stopwatch();
                    Limits.Cal_Stopwatch.Start();
                    CalibLastMode = SampleResponse.BoxMode_desc;
                    CountCalib = 1;
                }
                
                Set_ChartVisible();
            }
            if (SampleResponse.TestFinalise || SampleResponse.OpCode_Response == opcode.s999 || CalibNoAnswerCounter > 30)
            {
                timMeasurement.Stop();
                timCalibration.Stop();
                ChB_Chart.Checked = false;
                m_Calibration_Running = false;
                if (SampleResponse.OpCode_Response == opcode.s999)
                {
                    
                    stateMessageError = "Sensor Kommunikation abgebrochen";
                    Limits.ErrorDetected = true;
                    Limits.ErrorMessage = stateMessageError;
                    SampleResponse.TestError = true;
                    SampleResponse.TestFinalise = true;
                }
                if (!SampleResponse.TestError)
                {
                    Limits.test_ok = true;
                    calQuality = CH_State.QualityGood;
                    H_Log.Save(Instance, m_state, opcode.state, $"SUBPROCESS QUALITY GOOD {stateMessageError}" );
                    m_state = gProcMain.idle;
                }
                else
                {
                    Limits.ErrorDetected = true;
                    Limits.ErrorMessage = stateMessageError;
                    calQuality = CH_State.QualityBad;
                    Limits.test_ok = false;
                    H_Log.Save(Instance, m_state, opcode.state, $"SUBPROCESS ERROR {stateMessageError}");
                    CMD_Send(opcode.G200);
                    Wait(4000, gProcMain.error);
                }
                if (!timProcess.Enabled) { timProcess.Start(); }
                return;
            }
            else
            {
                if (CalibNoAnswerCounter > 2)
                {
                    noAnswer = AnswerReplaces(SampleResponse.BoxMode_desc, CountCalib, CalibNoAnswerCounter);
                }
                else
                {
                    noAnswer = null;
                }
                Waittime_Show_Cal(noAnswer);
            }
        }

        private string AnswerReplaces(string txt, int count, int countNoAnswer)
        {
            StringBuilder sb = new StringBuilder(txt)
                .Replace("_", " ").Replace("Mode", "").Replace("Box", "")
                .Append($"\tCount: {count}");
            if (CalibNoAnswerCounter > 2)
            {
                sb.Append($"; NoAnswer: {CalibNoAnswerCounter}");
            }
            return sb.ToString();
        }
        private bool Answer()
        {
            if (Answer(opcode.g901))
            {
                g901Receved = true;
                return true;
            }
            if (Answer(opcode.g100)) { return true; }
            if (Answer(opcode.s999)) { return true; }
            return false;
        }
        private bool Answer(opcode cmd)
        {
            if (cmd == WaitingDetails.cmd_AnswerReceive) { return true; }
            return false;
        }


        /*******************************************************************************************************************
        ** Chart:    Measurement Timer
        ********************************************************************************************************************/
        #region Chart
        private System.Windows.Forms.Timer _timMeasurement;
        private System.Windows.Forms.Timer timMeasurement { get { if(_timMeasurement == null) { Init_timMeasurement(); }return _timMeasurement; } }
        private void Init_timMeasurement(bool start = false, int interval = 1000)
        {
            _timMeasurement = new System.Windows.Forms.Timer() { Interval = interval };
            _timMeasurement.Tick += new EventHandler(timMeasurement_Tick);
            if (start)
            { timMeasurement.Start(); }
        }
        public void timMeasurement_Tick(object sender, EventArgs e)
        {
            Chart_Update();
        }

        private void Set_ChartVisible()
        {
            if (!ChB_Chart.Visible)
            {
                if (SampleResponse.DT_Measurements.Rows.Count > 0)
                {
                    ChB_Chart.Visible = true;
                    ChB_Chart.Checked = true;
                }
            }
        }

        private void Chart_Update()
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate { Chart_Update(); }); return;
            }
            Chart_UpdateFromMeasResults();
        }

        private void Chart_UpdateFromMeasResults()
        {
            int lCount = 0;
            double lastSTDdev = 999;
            if (Limits.MeasResults.Count > 0)
            {
                try
                {
                    var li = Limits.MeasResults.Where(x => x.Values.BoxMode == SampleResponse.BoxMode_hex);
                    lCount = li.Count();
                    
                    if (lCount > 0)
                    {
                        try
                        {
                            var selection = li.Reverse().Take(Chart_ShowVaulesQuantiy+1).Reverse();
                            Chart_Measurement.Series[MN_I_StdDev].Points.Clear();
                            Chart_Measurement.Series[MN_I_Error].Points.Clear();
                            Chart_Measurement.Series[MN_I_AVG].Points.Clear();
                            Chart_Measurement.Series[MN_I_set].Points.Clear();
                            
                            foreach (var item in selection)
                            {
                                lastSTDdev = item.Values.StdDev;
                                Chart_Measurement.Series[MN_I_StdDev].Points.AddXY(item.Values.Count, item.Values.StdDev);
                                Chart_Measurement.Series[MN_I_Error].Points.AddXY(item.Values.Count, item.Values.ErrorABS);
                                Chart_Measurement.Series[MN_I_AVG].Points.AddXY(item.Values.Count, item.Values.MeanValue);
                                Chart_Measurement.Series[MN_I_set].Points.AddXY(item.Values.Count, item.Values.RefValue);
                            }
                        }
                        catch(Exception ex)
                        { }
                        try
                        {
                            switch (ChartMode_Selection)
                            {
                                case ChartMode.STDdeviation:
                                    var devLimits = Limits.DeviceLimits.Get_LimitsMode(SampleResponse.BoxMode_hex);
                                    if (lastSTDdev < devLimits.StdDev)
                                    {
                                        Chart_Measurement.Series[MN_I_StdDev].Color = MTcolors.MT_rating_God_Active;
                                    }
                                    else if(lastSTDdev < devLimits.StdDev + 1)
                                    {
                                        Chart_Measurement.Series[MN_I_StdDev].Color = MTcolors.MT_rating_Alert_Active;
                                    }
                                    else
                                    {
                                        Chart_Measurement.Series[MN_I_StdDev].Color =  MTcolors.MT_rating_Bad_Active;
                                    }
                                    
                                    break;
                                default:
                                    break;
                            }
                        }
                        catch
                        {
                        }
                    }
                }
                catch { }
            }
        }

        private double Get_STDdev(List<double> input, out double avg)
        {
            avg = input.Average();
            double sumOfDerivation = 0;
            foreach (double value in input)
            {
                sumOfDerivation += (value) * (value);
            }
            double sumOfDerivationAverage = sumOfDerivation / (input.Count - 1);
            return Math.Sqrt(sumOfDerivationAverage - (avg * avg));

        }

        /****************************************************************************************************
         * Chart:       Measurement
         ***************************************************************************************************/
        public enum ChartMode { STDdeviation, MeanValue, ErrorValue, RefMean, All, RefValue, STD_Error}
        public ChartMode ChartMode_Selection; //= ChartMode.STDdeviation;
        private int Chart_ShowVaulesQuantiy = 15;

        private void Init_Chart()
        {
            string XvalueMember = "Count";
            Chart_Measurement.Visible = false;
            Chart_Measurement.Series.Clear();
            Chart_Measurement.Series.Add(New_ChartSerie(MN_I_set, XvalueMember, System.Drawing.Color.Gray));
            Chart_Measurement.Series.Add(New_ChartSerie(MN_I_AVG, XvalueMember, System.Drawing.Color.Yellow));
            Chart_Measurement.Series.Add(New_ChartSerie(MN_I_StdDev, XvalueMember, System.Drawing.Color.Red));
            Chart_Measurement.Series.Add(New_ChartSerie(MN_I_Error, XvalueMember, System.Drawing.Color.Orange));
            Chart_Measurement.ChartAreas[0].AxisY.IsStartedFromZero = false;
            Chart_Measurement.ChartAreas[0].AxisX.Interval = 3;
            Chart_Measurement.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Microsoft Sans Serif", 5);
            Chart_Measurement.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Microsoft Sans Serif", 6);
            Chart_Measurement.ChartAreas[0].AxisX.IsMarginVisible = false;
            Chart_Measurement.ChartAreas[0].AxisY.IsMarginVisible = false;
            Chart_Measurement.ChartAreas[0].AxisY.LabelStyle.Format = "0.##";
            ChB_Chart.Checked = false;
        }
        private System.Windows.Forms.DataVisualization.Charting.Series New_ChartSerie(string name, string xvaluemember, Color color)
        {
            return new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = name,
                Color = color,
                IsVisibleInLegend = false,
                IsValueShownAsLabel = false,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line,
                BorderWidth = 4,
                XValueMember = xvaluemember,
                YValueMembers = name
            };
        }
        private void Change_ChartModeSelection(ChartMode selection)
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate { Change_ChartModeSelection(selection); }); return;
            }
            bool refValues = false;
            bool meanValues = false;
            bool stdValues = false;
            bool errorValues = false;
            switch (selection)
            {
                case ChartMode.STDdeviation:
                    Chart_ShowVaulesQuantiy = 10;
                    stdValues = true;
                    break;
                case ChartMode.MeanValue:
                    Chart_ShowVaulesQuantiy = 15;
                    meanValues = true;
                    break;
                case ChartMode.ErrorValue:
                    Chart_ShowVaulesQuantiy = 15;
                    errorValues = true;
                    break;
                case ChartMode.RefMean:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    meanValues = true;
                    break;
                case ChartMode.All:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    meanValues = true;
                    stdValues = true;
                    errorValues = true;
                    break;
                case ChartMode.RefValue:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    break;
                case ChartMode.STD_Error:
                    Chart_ShowVaulesQuantiy = 10;
                    errorValues = true;
                    stdValues = true;
                    break;
                default:
                    Chart_ShowVaulesQuantiy = 15;
                    break;
            }

            Chart_Measurement.Series[MN_I_set].Enabled = refValues;
            Chart_Measurement.Series[MN_I_AVG].Enabled = meanValues;
            Chart_Measurement.Series[MN_I_StdDev].Enabled = stdValues;
            Chart_Measurement.Series[MN_I_Error].Enabled = errorValues;

            ChartMode_Selection = selection;
        }
        private void Chart_Visible(bool visible)
        {
            Chart_Measurement.Visible = visible;
            if (visible)
            {
                Change_ChartModeSelection(ChartMode_Selection);
                if (calibrationRunning)
                { timMeasurement.Start(); }
                Chart_Measurement.BringToFront();
            }
            else
            {
                timMeasurement.Stop();
            }
        }
        private void ChB_Chart_CheckedChanged(object sender, EventArgs e)
        {
            Chart_Visible(ChB_Chart.Checked);
        }

        /****************************************************************************************************
        ** Chart:       Measurement Menu
        ****************************************************************************************************/

        private void sTDDeviationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.STDdeviation);
        }

        private void refValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.RefValue);
        }

        private void meanVauesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.MeanValue);
        }

        private void errorValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.ErrorValue);
        }

        private void allValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.All);
        }

        private void refMeanValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.RefMean);
        }

        private void sTDDeviationErrorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.STD_Error);
        }

        private void DGV_Progress_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //Update_DGV();
        }

        private void DGV_Progress_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            //Update_DGV();
        }

        private void DGV_Progress_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
        #endregion Chart
    }

}
