﻿using System;
using System.Collections.Generic;
using static ReadCalibox.clHandler;

namespace ReadCalibox
{
    /**********************************************************************************************
     * The Property name must be written identically as the Database
     **********************************************************************************************/
    public class clItemLimits
    {
        public int channel_no { get; set; }
        public string ODBC_EK { get; set; }
        public string ODBC_TT { get; set; }
        public clDeviceLimits DeviceLimits;
        public List<clDeviceLimitsResults> MeasResults { get; set; } = new List<clDeviceLimitsResults>();

        public void Add_MeasResult(clDeviceLimitsResults results)
        {
            int count = MeasResults.Count;
            if (count > 0)
            {
                var last = MeasResults[count - 1].Values;
                if (last.BoxMode == results.Values.BoxMode)
                {
                    results.Values.Count = last.Count + 1;
                }
                else { results.Values.Count = 0; }
            }
            MeasResults.Add(results);
        }
        public bool ErrorDetected { get; set; } = false;
        public string ErrorMessage { get; set; }
        public int tag_nr { get; set; }
        public int sensor_id { get; set; }
        public int pass_no { get; set; } = 0;
        public int Technology_ID { get; set; }
        public string technology_desc { get; set; }
        public int ProductionType_ID { get; set; }
        public string ProductionType_Desc { get; set; }
        public string item { get; set; }
        public bool item_active { get; set; }
        public string pdno { get; set; }
        public bool test_ok { get; set; } = false;

        public DateTime meas_time_start { get; set; }
        public DateTime meas_time_end { get; set; }
        private DateTime _meas_time_end_Theo;
        public DateTime meas_time_end_Theo
        {
            get
            {
                if (meas_time_start.Year > 1)
                {
                    return meas_time_start.AddSeconds(Cal_Duration);
                }
                return _meas_time_end_Theo;
            }
        }
        public TimeSpan meas_time_duration
        {
            get
            {
                if (meas_time_start.Year > 1)
                {
                    if (meas_time_end.Year > 1)
                    {
                        return meas_time_end - meas_time_start;
                    }
                    else { meas_time_end = DateTime.Now; }
                    return meas_time_end - meas_time_start;
                }
                return TimeSpan.Zero;
            }
        }
        public TimeSpan meas_time_remain
        {
            get
            {
                if (meas_time_start.Year > 1)
                {
                    return (meas_time_end_Theo - DateTime.Now);
                }
                return TimeSpan.Zero;
            }
        }
        public int User_ID { get; set; }
        public string UserName { get; set; }
        public string EK_SW_Version { get; } = clHandler.EK_SW_Version;
        public int error_no { get; set; }

        private int sample_FW_Version_Cal_active_Set = -1;
        private bool _sample_FW_Version_Cal_active;
        public bool sample_FW_Version_Cal_active
        {
            get { return _sample_FW_Version_Cal_active; }
            set
            {
                _sample_FW_Version_Cal_active = value;
                sample_FW_Version_Cal_active_Set = 1;
            }
        }
        public string sample_FW_Version_value { get; set; }
        public string sample_FW_Version {get;set;}
        public int sample_FW_Version_state
        {
            get
            {
                if (sample_FW_Version_Cal_active)
                {
                    return sample_FW_Version_ok ? 2 : 1;
                }
                return 0;
            }
        }
        public bool sample_FW_Version_ok
        {
            get
            {
                if (sample_FW_Version_Cal_active)
                {
                    if (!string.IsNullOrEmpty(sample_FW_Version_value))
                    { return sample_FW_Version == sample_FW_Version_value; }
                    return false;
                }
                return true;
            }
        }

        public int procCounterLast = 0;
        public int procCounter { get { return procCounterLast++; } }

        public int CalMode_ID { get; set; }
        public string cal_opcode { set { CalMode = value.ParseOpcode(defaultOpcode: opcode.S100); } }

        public opcode CalMode { get; set; }
        public string Cal_Desc { get; set; }
        public double Cal_Duration { get; set; }

        public string Cal_BoxMode_desc { get; set; }
        public System.Diagnostics.Stopwatch Cal_Stopwatch { get; set; } = new System.Diagnostics.Stopwatch();
        
    }
}
