﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadCalibox
{
    public partial class frmSplash : Form
    {
        public frmSplash(string swname, string swversion)
        {
            InitializeComponent();
            Set_SWversion(swversion);
            SWname = swname;
            Start();
            this.Show();
        }

        private void FrmSplash_Load(object sender, EventArgs e)
        {
            lbl_Version.Text = SWversion;
            lbl_Titel.Text = SWname;
            
        }

        /***************************************************************************************
        * Properties:
        ****************************************************************************************/
        public string SWname { get; set; }
        public string SWversion { get; set; }

        public double TimeOut_ms { get; set; } = 60000;


        public DateTime RunningTimeStart { get; private set; }
        public DateTime AbortTime { get; private set; }

        private void Set_SWversion(string swv)
        {
            string v = swv.ToLower();
            if (!v.Contains("version"))
            {
                SWversion = $"Version: {swv}";
            }
            else
            {
                SWversion = swv;
            }
        }

        public void Start()
        {
            RunningTimeStart = DateTime.Now;
            AbortTime = RunningTimeStart.AddMilliseconds(TimeOut_ms);
            BGWorker.RunWorkerAsync();
            this.BringToFront();
            this.Show();
            this.BringToFront();
            //timProgBar.Start();
            Application.DoEvents();
        }


        public void Stop()
        {
            try
            {
                this.Close();
            }
            catch
            {

            }
        }

        /***************************************************************************************
        * Splash:
        ****************************************************************************************/
        private void TimProgBar_Tick(object sender, EventArgs e)
        {
            progBar.Increment(1);
            if(progBar.Value == 100)
            {
                progBar.Value = 0;
            }
            if(DateTime.Now > AbortTime)
            {
                Stop();
            }
        }

        private void BGWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bg = (BackgroundWorker)sender;
            while (DateTime.Now<AbortTime &&  !bg.CancellationPending)
            {
                bg.ReportProgress(1);
                Thread.Sleep(300);
            }
        }

        private void BGWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progBar.Increment(1);
            if (progBar.Value == 100)
            {
                progBar.Value = 0;
            }
        }

        private void BGWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Stop();
        }

        /***************************************************************************************
        * Splash:
        ****************************************************************************************/


    }
}
