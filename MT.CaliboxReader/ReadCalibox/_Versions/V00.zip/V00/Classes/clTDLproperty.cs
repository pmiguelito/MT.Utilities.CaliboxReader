﻿namespace ReadCalibox
{
    public class clTDLproperty
    {
        public int page_no { get; set; }
        public int order_no { get; set; }
        public string property_tag { get; set; }
        public string description { get; set; }
        public int bit { get; set; }
        public string data_type { get; set; }

        public string start { get; set; }
        public string tol { get; set; }
        public string format { get; set; }
        public string unit { get; set; }
        public int bit_start { get; set; }
    }
}
