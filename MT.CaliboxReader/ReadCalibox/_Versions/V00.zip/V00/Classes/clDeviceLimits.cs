﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadCalibox
{
    public class clDeviceLimits
    {
        public string BeM { get; set; }
        public string HW_ID { get; set; }
        public string HW_Version { get; set; }
        public string FW_Version { get; set; }
        public string Compiled { get; set; }

        public string DipSwitch { get; set; }
        public string BoxDesc { get; set; }

        public double TempRefVolt;
        public clDeviceLimitsModes RawVal { get; set; }
        public clDeviceLimitsModes Current { get; set; }
        public clDeviceLimitsModes RawError { get; set; }
        public clDeviceLimitsModes CalError { get; set; }
        public clDeviceLimitsModes WepError { get; set; }

        private clDeviceLimtsModesStates _LOW1;
        public clDeviceLimtsModesStates LOW1
        {
            get
            {
                if (_LOW1 == null)
                {
                    _LOW1 = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low1,
                        Current = Current.Low1,
                        CalError = CalError.Low1,
                        WepError = WepError.Low1
                    };
                }
                return _LOW1;
            }
        }
        private clDeviceLimtsModesStates _LOW2;
        public clDeviceLimtsModesStates LOW2
        {
            get
            {
                if (_LOW2 == null)
                {
                    _LOW2 = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low2,
                        Current = Current.Low2,
                        CalError = CalError.Low2,
                        WepError = WepError.Low2
                    };
                }
                return _LOW2;
            }
        }
        private clDeviceLimtsModesStates _HIGH1;
        public clDeviceLimtsModesStates HIGH1
        {
            get
            {
                if (_HIGH1 == null)
                {
                    _HIGH1 = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High1,
                        Current = Current.High1,
                        CalError = CalError.High1,
                        WepError = WepError.High1
                    };
                }
                return _HIGH1;
            }
        }
        private clDeviceLimtsModesStates _HIGH2;
        public clDeviceLimtsModesStates HIGH2
        {
            get
            {
                if (_HIGH2 == null)
                {
                    _HIGH2 = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High2,
                        Current = Current.High2,
                        CalError = CalError.High2,
                        WepError = WepError.High2
                    };
                }
                return _HIGH2;
            }
        }
        public clDeviceLimitsValues CheckLimits(string boxmode, string value, string mean, string stdDev, string errorABS)
        {
            clDeviceLimitsValues result = new clDeviceLimitsValues()
            {
                BoxMode = boxmode,
                Value = value.ToDouble(),
                Mean = mean.ToDouble(),
                StdDev = stdDev.ToDouble(),
                ErrorABS = errorABS.ToDouble()
            };
            switch (boxmode)
            {
                case "00":
                case "04":
                case "08":
                case "0C":
                    result.LimitsMode = LOW1;
                    break;
                case "01":
                case "05":
                case "09":
                case "0D":
                    result.LimitsMode = LOW2;
                    break;
                case "02":
                case "06":
                case "0A":
                case "0E":
                    result.LimitsMode = HIGH1;
                    break;
                case "03":
                case "07":
                case "0B":
                case "0F":
                    result.LimitsMode = HIGH2;
                    break;
                default:
                    break;
            }
            return result;
        }
    }
    public class clDeviceLimitsModes
    {
        public double Low1;
        public double Low2;
        public double High1;
        public double High2;
        public string Unit;
    }
    public class clDeviceLimtsModesStates
    {
        public double RawValue;
        public double Current;
        public double CalError;
        public double WepError;
    }

    public class clDeviceLimitsValues
    {
        public clDeviceLimtsModesStates LimitsMode;

        public string BoxMode;
        public double Value;
        public double Mean;
        public double StdDev;
        public double ErrorABS;
        public bool Test_ok
        {
            get
            {
                return Value_ok && StdDev_ok && ErrorABS_ok;
            }
        }
        public bool Value_ok
        {
            get
            {
                if(LimitsMode != null)
                {
                    return Value <= LimitsMode.RawValue;
                }
                return false;
            }
        }
        //public bool Mean_ok
        //{
        //    get
        //    {
        //        if (Limits != null)
        //        {
        //            return Mean <= Limits.Current;
        //        }
        //        return false;
        //    }
        //}
        public bool StdDev_ok
        {
            get
            {
                if (LimitsMode != null)
                {
                    return StdDev <= LimitsMode.CalError;
                }
                return false;
            }
        }
        public bool ErrorABS_ok
        {
            get
            {
                if (LimitsMode != null)
                {
                    return ErrorABS <= LimitsMode.Current;
                }
                return false;
            }
        }

    }
}
