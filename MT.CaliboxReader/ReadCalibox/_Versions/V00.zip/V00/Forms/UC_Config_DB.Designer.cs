﻿namespace ReadCalibox
{
    partial class UC_Config_DB
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrB_ODBC = new System.Windows.Forms.GroupBox();
            this.TB_DoCheckPass = new System.Windows.Forms.TextBox();
            this.TB_ProcNr = new System.Windows.Forms.TextBox();
            this.TB_ProdType_Table = new System.Windows.Forms.TextBox();
            this.TB_ODBC_Initial = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CkB_DB_ProdType_Active = new System.Windows.Forms.CheckBox();
            this.CoB_Tables = new System.Windows.Forms.ComboBox();
            this.GrB_ODBC.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrB_ODBC
            // 
            this.GrB_ODBC.Controls.Add(this.CoB_Tables);
            this.GrB_ODBC.Controls.Add(this.TB_DoCheckPass);
            this.GrB_ODBC.Controls.Add(this.TB_ProcNr);
            this.GrB_ODBC.Controls.Add(this.TB_ProdType_Table);
            this.GrB_ODBC.Controls.Add(this.TB_ODBC_Initial);
            this.GrB_ODBC.Controls.Add(this.label4);
            this.GrB_ODBC.Controls.Add(this.label3);
            this.GrB_ODBC.Controls.Add(this.label5);
            this.GrB_ODBC.Controls.Add(this.label2);
            this.GrB_ODBC.Controls.Add(this.CkB_DB_ProdType_Active);
            this.GrB_ODBC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GrB_ODBC.Location = new System.Drawing.Point(0, 0);
            this.GrB_ODBC.Name = "GrB_ODBC";
            this.GrB_ODBC.Size = new System.Drawing.Size(210, 100);
            this.GrB_ODBC.TabIndex = 26;
            this.GrB_ODBC.TabStop = false;
            this.GrB_ODBC.Text = "Init values";
            // 
            // TB_DoCheckPass
            // 
            this.TB_DoCheckPass.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TB_DoCheckPass.Location = new System.Drawing.Point(89, 80);
            this.TB_DoCheckPass.Name = "TB_DoCheckPass";
            this.TB_DoCheckPass.Size = new System.Drawing.Size(120, 20);
            this.TB_DoCheckPass.TabIndex = 20;
            // 
            // TB_ProcNr
            // 
            this.TB_ProcNr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TB_ProcNr.Location = new System.Drawing.Point(89, 57);
            this.TB_ProcNr.Name = "TB_ProcNr";
            this.TB_ProcNr.Size = new System.Drawing.Size(57, 20);
            this.TB_ProcNr.TabIndex = 20;
            this.TB_ProcNr.Leave += new System.EventHandler(this.TB_ProcNr_Leave);
            // 
            // TB_ProdType_Table
            // 
            this.TB_ProdType_Table.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TB_ProdType_Table.Location = new System.Drawing.Point(89, 34);
            this.TB_ProdType_Table.Name = "TB_ProdType_Table";
            this.TB_ProdType_Table.Size = new System.Drawing.Size(119, 20);
            this.TB_ProdType_Table.TabIndex = 20;
            // 
            // TB_ODBC_Initial
            // 
            this.TB_ODBC_Initial.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TB_ODBC_Initial.Location = new System.Drawing.Point(89, 12);
            this.TB_ODBC_Initial.Name = "TB_ODBC_Initial";
            this.TB_ODBC_Initial.Size = new System.Drawing.Size(119, 20);
            this.TB_ODBC_Initial.TabIndex = 20;
            this.TB_ODBC_Initial.Leave += new System.EventHandler(this.TB_ODBC_Initial_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 84);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "DoCheckPass";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 61);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "ProcNr";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 38);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "ProdType Table";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "ODBC EK Init";
            // 
            // CkB_DB_ProdType_Active
            // 
            this.CkB_DB_ProdType_Active.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CkB_DB_ProdType_Active.AutoSize = true;
            this.CkB_DB_ProdType_Active.Location = new System.Drawing.Point(166, 59);
            this.CkB_DB_ProdType_Active.Margin = new System.Windows.Forms.Padding(0);
            this.CkB_DB_ProdType_Active.Name = "CkB_DB_ProdType_Active";
            this.CkB_DB_ProdType_Active.Size = new System.Drawing.Size(41, 17);
            this.CkB_DB_ProdType_Active.TabIndex = 21;
            this.CkB_DB_ProdType_Active.Text = "DB";
            this.CkB_DB_ProdType_Active.UseVisualStyleBackColor = true;
            this.CkB_DB_ProdType_Active.CheckedChanged += new System.EventHandler(this.CkB_DB_ProdType_Active_CheckedChanged);
            // 
            // CoB_Tables
            // 
            this.CoB_Tables.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CoB_Tables.FormattingEnabled = true;
            this.CoB_Tables.Location = new System.Drawing.Point(89, 35);
            this.CoB_Tables.Name = "CoB_Tables";
            this.CoB_Tables.Size = new System.Drawing.Size(121, 21);
            this.CoB_Tables.TabIndex = 23;
            this.CoB_Tables.SelectedIndexChanged += new System.EventHandler(this.CoB_Tables_SelectedIndexChanged);
            // 
            // UC_Config_DB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.GrB_ODBC);
            this.Name = "UC_Config_DB";
            this.Size = new System.Drawing.Size(210, 100);
            this.GrB_ODBC.ResumeLayout(false);
            this.GrB_ODBC.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrB_ODBC;
        private System.Windows.Forms.TextBox TB_DoCheckPass;
        private System.Windows.Forms.TextBox TB_ProcNr;
        private System.Windows.Forms.TextBox TB_ProdType_Table;
        private System.Windows.Forms.TextBox TB_ODBC_Initial;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CkB_DB_ProdType_Active;
        private System.Windows.Forms.ComboBox CoB_Tables;
    }
}
