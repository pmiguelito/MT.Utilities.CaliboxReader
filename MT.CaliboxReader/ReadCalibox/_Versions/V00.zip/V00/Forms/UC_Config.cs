﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Configuration;
using System.Collections.Specialized;
using static ReadCalibox.clConfig;
using static ReadCalibox.clHandler;
using STDhelper;
using static STDhelper.clFTDI;
using static STDhelper.clMTcolors;
using static STDhelper.clLogging;
using TT_Item_Infos;

namespace ReadCalibox
{
    public partial class UC_Config : UserControl
    {
        /***************************************************************************************
        * Constructor
        ****************************************************************************************/
        public static DataGridView DGV_FTDI;
        public static TextBox TB_Path_MeasLog, TB_Path_Log;
        public static CheckBox CkB_Path_MeasLog_Active, CkB_Path_Log_Active;
        void ObjRef()
        {
            DGV_FTDI = _DGV_FTDI;
            DGV_FTDI.DataSource = DTFTDI;
            TB_Path_MeasLog = _TB_Path_MeasLog;
            TB_Path_Log = _TB_Path_Log;
            CkB_Path_MeasLog_Active = _CkB_Path_MeasLog_Active;
            CkB_Path_Log_Active = _CkB_Path_Log_Active;
        }
        public UC_Config()
        {
            InitializeComponent();
            ObjRef();
        }
        private void UC_Config_Load(object sender, EventArgs e)
        {
            Init_UC_Config();
            Init_ODBC();
        }
        /***************************************************************************************
        * Initialization:   
        ****************************************************************************************/
        private void Init_Panel()
        {
           
            //Form_Main.AllocFont_STD(this);
        }

        private void Error()
        {
            ErrorLineSeparator = true;
            ErrorPathLog = Path_Log;
            ErrorPathLog_Active = Path_Log_Active;
        }

        private void Init_ODBC()
        {
            GrB_Init.Controls.Add(uc_ConfigDB_Init);
            uc_ConfigDB_Init.Dock = DockStyle.Fill;
        }

        /***************************************************************************************
        * Configuration:  Load & Save
        ****************************************************************************************/

        public bool Load_Config(int chQuantity)
        {
            Load_Config_InitParameters();
            //Load_Config_ChangeParameters();
            Load_Config_BeM();
            Load_Config_Ports();
            return true;
        }

        public bool Save_Config()
        {
            Save_Config_Ports();
            Save_Config_InitParameters();
            Save_Config_BeM();
            return true;
        }

        /***************************************************************************************
        * Configuration:  SerialPorts
        ****************************************************************************************/
        void Load_Config_Ports()
        {
            try { _FlowPanCOM.Controls.Clear(); } catch { }
            foreach (UC_COM uc in Config_PortList)
            {
                _FlowPanCOM.Controls.Add(uc);
            }
        }

        void Save_Config_Ports()
        {
            foreach(UC_COM uc in Config_PortList)
            {
                var item = Config_ComPorts.ComPorts[uc.Ch_no];
                item.Ch_Name = uc.Ch_name;
                item.COMreadDelay = Convert.ToInt32(uc.ReadDelay);
                item.ModusFTDI = uc.ModusFTDI;
                item.Active = uc.Active;
                item.FTDIname = uc.FTDIname;
                item.BaudRate = uc.Baudrate;
                item.SerialPortName = uc.PortName;
                item.BeM = uc.BeM;

                item.HandShake = uc.HandShake_Selected;
                item.DataBits = uc.DataBits_Selected;
                item.StopBits = uc.StopBits_Selected;
                item.Parity = uc.Parity_Selected;
            }
            Register_ComPorts.Save();
        }

        /***************************************************************************************
        * Configuration:  BeM
        ****************************************************************************************/
        #region BeM
        //Register_BeM Config_BeM { get { return Register_BeM.GetConfig(); } }
        //List<UC_BeM> uC_BeMs;
        void Load_Config_BeM()
        {
            try { FlowPan_BeM.Controls.Clear(); } catch { }
            foreach (UC_BeM uc in Config_BeMsList)
            {
                FlowPan_BeM.Controls.Add(uc);
            }
            //uC_BeMs = new List<UC_BeM>();
            //foreach (Element_BeM uc in Config_BeMList)
            //{
            //    UC_BeM be = new UC_BeM(uc);
            //    FlowPan_BeM.Controls.Add(be);
            //    uC_BeMs.Add(be);
            //}
        }

        void Save_Config_BeM()
        {
            //Config_BeMList = new List<Element_BeM>();
            foreach (UC_BeM uc in Config_BeMsList)
            {
                uc.Save();
                //Config_BeMsList.Add(uc.Selectedvalues);
            }
            Register_BeM.Save();
        }
        #endregion BeM
        /***************************************************************************************
        * Configuration:    InitParameters
        ****************************************************************************************/
        #region InitParameters
        private UC_Config_DB uc_ConfigDB_Init = new UC_Config_DB("Init Values");
        public string Path_MeasLog
        {
            get { return TB_Path_MeasLog.Text; }
            set { TB_Path_MeasLog.Text = value; }
        }
        public bool Path_MeasLog_Active
        {
            get { return CkB_Path_MeasLog_Active.Checked; }
            set { CkB_Path_MeasLog_Active.Checked = value; }
        }

        public string Path_Log
        {
            get { return TB_Path_Log.Text; }
            set { TB_Path_Log.Text = value; ErrorPathLog = value; }
        }
        public bool Path_Log_Active
        {
            get { return CkB_Path_Log_Active.Checked; }
            set { CkB_Path_Log_Active.Checked = value; ErrorPathLog_Active = value; }
        }

        public string ODBC_Initial
        {
            get { return uc_ConfigDB_Init.ODBC_Init; }
            set { uc_ConfigDB_Init.ODBC_Init = value; }
        }
        
        public bool ODBC_Initial_Found
        {
            get { return uc_ConfigDB_Init.ODBC_Initial_Exists; }
        }

        public int ProcNr
        {
            get { return uc_ConfigDB_Init.ProcNr; }
            set { uc_ConfigDB_Init.ProcNr = value; }
        }

        public string ProdType_Table
        {
            get { return uc_ConfigDB_Init.ProdType_Table; }
            set { uc_ConfigDB_Init.ProdType_Table = value; }
        }
        public int Ch_Quantity
        {
            get { return (int)NUD_Ch_Quantity.Value; }
            set
            {
                if (value > 4 && value < 21)
                { NUD_Ch_Quantity.Value = value; }
            }
        }

        private string DoCheckPassTXT
        {
            get { return uc_ConfigDB_Init.DoCheckPassTXT; }
            set { uc_ConfigDB_Init.DoCheckPassTXT = value; }
        }

        public bool DB_ProdType_Active
        {
            get { return uc_ConfigDB_Init.DB_ProdType_Active; }
            set { uc_ConfigDB_Init.DB_ProdType_Active = value; }
        }

        private void Load_Config_InitParameters()
        {
            Element_InitParameters element = Config_Initvalues;
            Path_Log = element.Log_Path;
            Path_Log_Active = element.Log_Active;
            Path_MeasLog_Active = element.MeasLog_Active;
            Path_MeasLog = element.MeasLog_Path;
            ODBC_Initial = element.ODBC_Init;
            ProdType_Table = element.DB_ProdType_Table;
            ProcNr = element.ProcNr;
            Ch_Quantity = element.CHquantity;
            DoCheckPassTXT = element.DoCheckPass;
            DB_ProdType_Active = element.DB_ProdType_Active;
        }
        private void Save_Config_InitParameters()
        {
            Element_InitParameters element = Config_Initvalues;
            element.Log_Path = Path_Log;
            element.Log_Active = Path_Log_Active;
            element.MeasLog_Active = Path_MeasLog_Active;
            element.MeasLog_Path = Path_MeasLog;
            element.ODBC_Init = ODBC_Initial;
            element.DB_ProdType_Active = DB_ProdType_Active;
            element.DB_ProdType_Table = ProdType_Table;
            element.ProcNr = ProcNr;
            element.CHquantity = Ch_Quantity;
            element.DoCheckPass = DoCheckPassTXT;
            //Form_Main.ProdType_Initvalues();
            Register_InitParameters.Save();
        }

        #endregion InitParameters

        /***************************************************************************************
        * Comports:   Initialization
        ****************************************************************************************/
        public void Init_UC_Config()
        {
            Load_Config(Config_Initvalues.CHquantity);
            Load_FTDI();
        }
        
        public static int Log_LinesBuffer
        {
            get { return UC_DataRead.Log_LinesBuffer; }
            set { UC_DataRead.Log_LinesBuffer = value; }
        }

        /***************************************************************************************
        * Comports:   FTDI
        ****************************************************************************************/
        public static void Load_FTDI()
        {
            DGV_FTDI.DataSource = DTFTDI;
        }

        private void Btn_Load_FTDI_Click(object sender, EventArgs e)
        {
            Load_FTDI();
        }

        /***************************************************************************************
        * General:
        ****************************************************************************************/
        private void Btn_SaveConfig_Click(object sender, EventArgs e)
        {
            Save_Config();
        }

    }
}

