﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TT_Item_Infos;
using System.IO.Ports;
using System.Threading;
using System.IO;
using STDhelper;
using static STDhelper.clBGWorker;
using static STDhelper.clMTcolors;
using static STDhelper.clLogging;
using static ReadCalibox.clConfig;
using static ReadCalibox.clDeviceCom;
using static ReadCalibox.clHandler;
using ODBC_TT;

namespace ReadCalibox
{
    public partial class UC_Channel : UserControl
    {
        /****************************************************************************************************
         * Constructor: Can be used for Panel Controls Load
         ***************************************************************************************************/
        #region UC Instance
        private UC_Channel _instance;
        public UC_Channel Instance
        {
            get
            {
                if (_instance == null)
                { _instance = new UC_Channel(ucCOM); }
                return _instance;
            }
        }
        #endregion UC Instance

        public UC_Channel ucCH { get { return this; } }
        
        public UC_COM ucCOM;
        private SerialPort port { get { return ucCOM.Serialport; } }

        public string ODBC_EK { get; set; }
        public clItemLimits Limits { get; set; }
        //private static DBInfos ItemInfos { get; set; }
        public string Channel_No { get { return _Lbl_Channel.Text; } set { _Lbl_Channel.Text = value; } }
        public string TAGno { get { return _Lbl_TAGno.Text; } set { _Lbl_TAGno.Text = value; } }
        public string Item { get { return _Lbl_Item.Text; } set { _Lbl_Item.Text = value; } }
        public string Pdno { get { return _Lbl_Pdno.Text; } set { _Lbl_Pdno.Text = value; } }
        public string UserName { get { return _Lbl_User.Text; } set { _Lbl_User.Text = value; } }
        public string ProdType { get { return _Lbl_ProdType.Text; } set { _Lbl_ProdType.Text = value; } }
        public string TimeStart { get { return _Lbl_TimeStart.Text; } set { _Lbl_TimeStart.Text = value; } }
        public string TimeEnd { get { return _Lbl_TimeEnd.Text; } set { _Lbl_TimeEnd.Text = value; } }

        public string PassNo { get { return _Lbl_PassNo.Text; } set { _Lbl_PassNo.Text = value; } }
        public string CalModeDesc { get { return _Lbl_CalMode.Text; } set { _Lbl_CalMode.Text = value; } }

        private bool _StarReady = false;
        public bool StartReady
        {
            get { return _StarReady; }
            set
            {
                _StarReady = value;
                StartReady_Change(value);
            }
        }
        private bool _Running;
        public bool Running
        {
            get { return _Running; }
            set
            {
                if (_Running != value)
                {
                    _Running = value;
                    Channel_Running_Change(value);
                }
                else
                { _Running = value; }
            }
        }
        private bool _Active;
        public bool Active { get { return _Active; } set { _Active = value; Channel_Active_Change(value); } }

        
        /****************************************************************************************************
         * Constructor: Main
         ***************************************************************************************************/
        public UC_Channel(UC_COM uc_COM)
        {
            InitializeComponent();
            uc_COM.UCChannel = this;
            this.ucCOM = uc_COM;
            StartReady = uc_COM.MeasReady;
        }
        private void UC_Channel_Load(object sender, EventArgs e)
        {
            Init();
            Reset();
            _instance = this;
        }
        void Init()
        {
            Init_Design();
            StartReady = false;
            Init_timStateEngine();
            Init_timProcess();
            Init_timCalibration();
            Init_Chart();
            Channel_No = ucCOM.Ch_name.Remove(0, 2);
            try
            {
                Active = ucCOM.SerialPort_Found;
                //if (!Active) { Channel_Active_Change(false); }
            }
            catch { Active = false; }
            try
            {
                Running = false;
                Channel_Running_Change(false);
            }
            catch { }
            try
            {
                ucCOM.SerialPort_Found_Changed += Channel_Activity_Changed;
            }
            catch { }
            try
            {
                Init_DGV();
            }
            catch { }
        }

        void Init_Design()
        {
            Init_Colors();
            Init_Design_Dimensions();
        }

        void Init_Colors()
        {
            Panel_Sep1.BackColor = MT_BackGround_HeaderFooter;
            Panel_Sep2.BackColor = MT_BackGround_HeaderFooter;
            Panel_Sep3.BackColor = MT_BackGround_HeaderFooter;
            Panel_Sep4.BackColor = MT_BackGround_HeaderFooter;

            Panel_Header.BackColor = MT_BackGround_Work;
            Panel_Button.BackColor = MT_BackGround_Work;
            Panel_ItemInfos.BackColor = MT_BackGround_Work;
            Panel_Info.BackColor = MT_BackGround_Work;
            Panel_Time.BackColor = MT_BackGround_Work;
        }

        void Init_Design_Dimensions()
        {
            AllocFont(_Lbl_Channel, 18, FontStyle.Bold);
            AllocFont(_Lbl_TAGno, 12, FontStyle.Bold);
            AllocFont(_Lbl_TAGno_TXT, 12, FontStyle.Bold);
            AllocFont(_Btn_Start, 10, FontStyle.Bold);
        }

        void Init_DGV()
        {
            DGV_Progress.BackgroundColor = MT_BackGround_Work;
            DGV_Progress.DataSource = SampleResponse.DT_Progress;
            Font n = new Font("Tahoma", 6, FontStyle.Regular);
            DGV_Progress.ColumnHeadersDefaultCellStyle.Font = n;
            n = new Font("Tahoma", 7, FontStyle.Regular);
            DGV_Progress.RowsDefaultCellStyle.Font = n;
            DGV_Progress.MultiSelect = false;
            DGV_Progress.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGV_Progress.ReadOnly = true;
            DGV_Progress.Progress_AdminModus();
            DGV_Progress.Sort(DGV_Progress.Columns[ProgHeader.meas_time_start.ToString()], ListSortDirection.Descending);
        }

        #region TEST
        /****************************************************************************************************
         * Debug:   Test
         *          send message to SerialPort
         ***************************************************************************************************/
        System.Windows.Forms.Timer TESTtimer;
        public void Init_TESTtimer()
        {
            TESTtimer = new System.Windows.Forms.Timer() { Interval = 1000 };
            TESTtimer.Tick += TESTtimer_Tick;
            Init_Test_Echo();
        }
        SerialPort Sp_Echo;
        private void Init_Test_Echo()
        {
            Sp_Echo = new SerialPort();
            int no = Convert.ToInt32(ucCOM.Serialport.PortName.Substring(3));
            Sp_Echo.PortName = $"COM{no + 1}";
            Sp_Echo.Parity = ucCOM.Serialport.Parity;
            Sp_Echo.BaudRate = ucCOM.Serialport.BaudRate;
            Sp_Echo.Handshake = ucCOM.Serialport.Handshake;
            Sp_Echo.DataBits = ucCOM.Serialport.DataBits;
            Sp_Echo.StopBits = ucCOM.Serialport.StopBits;
        }

        int testNr = 0;
        private void TESTtimer_Tick(object sender, EventArgs e)
        {
            if (ucCOM.Serialport.IsOpen)
            {
                //BoardCheck.clDeviceCom.getDevice_AllInfos(_UC_COM.Serialport, this);
                if (!Sp_Echo.IsOpen) { Sp_Echo.Open(); }
                string message = $"TEST_{testNr}: {DateTime.Now}.{DateTime.Now.Millisecond}{Environment.NewLine}";
                Sp_Echo.Write(message);
                //ErrorMessageChannel = message;
                //byte[] data = Encoding.ASCII.GetBytes("R00");
                //_UC_COM.Serialport.Write(message);
                testNr++;
                //_UC_COM.Serialport.Close();
                //TESTtimer.Stop();
            }
            else
            { TESTtimer.Stop(); }
        }

        public void Start_TESTtimer(int interval = 1000)
        {
            testNr = 0;
            if (TESTtimer == null)
            { Init_TESTtimer(); }
            TESTtimer.Interval = interval;
            TESTtimer.Start();
        }
        #endregion TEST

        /****************************************************************************************************
         * Running
         ***************************************************************************************************/
        private void Channel_Running_Change(bool running)
        {
            CH_State wk = CH_State.nothing;
            if (running)
            {
                wk = CH_State.inWork;
                _Btn_Start.BackColor = MT_rating_Alert_Active;
                _Btn_Start.ForeColor = Color.Black;
            }
            else
            {
                wk = calQuality;
            }
            _Btn_Start.Text = !running ? "Start" : "Cancel";
            CH_WorkingStatusColors(wk);
        }
        
        private void CH_WorkingStatusColors(CH_State status)
        {
            Color col = MT_BackGround_Work;
            Color colSep = MT_BackGround_HeaderFooter;
            Color colorInfoBox = MT_BackGround_White;
            if(Limits != null)
            {
                colorInfoBox = Limits.ErrorDetected ? MT_rating_Bad_Active : MT_BackGround_White;
            }
            bool onlyCH = false;
            switch (status)
            {
                case CH_State.nothing:
                    break;
                case CH_State.inWork:
                    colorInfoBox = MT_BackGround_White;
                    col = MT_rating_InWork_Active;
                    colSep = MT_BackGround_Work;
                    break;
                case CH_State.QualityBad:
                    col = MT_rating_Bad_Active;
                    break;
                case CH_State.QualityGood:
                    col = MT_rating_God_Active;
                    break;
                case CH_State.active:
                    this.Enabled = true;
                    _Btn_Start.Visible = true;
                    break;
                case CH_State.notActive:
                    this.Enabled = false;
                    _Btn_Start.Visible = false;
                    colSep = Color.SteelBlue;
                    break;
                case CH_State.error:
                    if (!onlyCH)
                    {
                        this.Enabled = true;
                        _Btn_Start.Visible = true;
                    }
                    col = MT_rating_Alert_Active;
                    //colSep = Color.SteelBlue;
                    break;
            }
            Tb_Info.BackColor = colorInfoBox;
            if (!onlyCH)
            {
                Panel_Header.BackColor = col;
                Panel_ItemInfos.BackColor = col;
                Panel_Time.BackColor = col;
                Panel_Info.BackColor = col;
                Panel_Button.BackColor = col;
                Panel_Sep1.BackColor = colSep;
                Panel_Sep2.BackColor = colSep;
                Panel_Sep3.BackColor = colSep;
                Panel_Sep4.BackColor = colSep;
                Chart_Measurement.BackColor = col;
                Chart_Measurement.ChartAreas[0].BackColor = col;
                Chart_Measurement.Update();
            }
        }

        private void StartReady_Change(bool enabled)
        {
            _Btn_Start.Enabled = enabled;
            _Btn_Start.BackColor = StartReady ? MT_rating_InWork_Active : MT_BackGround_White;
            _Btn_Start.ForeColor = StartReady ? MT_BackGround_White : Color.Black;
        }

        private void Channel_Active_Change(bool enabled)
        {
            CH_State wk = enabled ? CH_State.active : CH_State.notActive;
            CH_WorkingStatusColors(wk);
        }

        private void Channel_Activity_Changed(object sender, EventArgs e)
        {
            Active = ucCOM.SerialPort_Found;
        }

        /****************************************************************************************************
         * GUI:     Reset Informations
         ***************************************************************************************************/
        public void Reset()
        {
            GUI_Infos_Reset();
            Reset_Processe();
        }
        private void GUI_Infos_Reset()
        {
            if (TAGno != "")
            {
                Ttip.Active = false;
                ODBC_EK = "";
                TAGno = "";
                Item = "";
                Pdno = "";
                UserName = "";
                ProdType = "";
                TimeStart = "";
                TimeEnd = "";
                PassNo = "";
                CalModeDesc = "";
                Tb_Info.Text = "";
                CH_WorkingStatusColors(CH_State.nothing);
                Limits = null;
                ChB_Chart.Checked = false;
                ChB_Chart.Visible = false;
                Gui_Message();
            }
        }
        private void Reset_Processe()
        {
            //BoxMode_Last = "";
            lLast = "";
            m_BoxReseted = false;
            m_BewertungExecuted = false;
            m_state_ProcessRunning = gProcMain.idle;
            m_TestRunning = false;
            processeNr = 0;
            m_Calibration_Running = false;
            CountCalib = 0;
            calQuality = CH_State.nothing;
            ProcesseRunning = gProcMain.idle;
            ProcesseLast = gProcMain.wait;
        }

        private void Reset_onStart()
        {
            bool identBox = DeviceLimits == null;
            SampleResponse = new DeviceResponse(null) { DeviceLimits = DeviceLimits, BoxIdentification = identBox };
            Reset_Processe();
            m_DBinit = false;
            LogPathMeas = Create_TMP_MeasPath(ucCOM.PortName);
            BeM_Selected = ucCOM.BeM;
            ReadDelay_Selected = Convert.ToInt32(ucCOM.ReadDelay);
            Running = true;
            m_UC_Betrieb.Channel_started(Channel_No);
            m_state_Last = gProcMain.idle;
            Init_DGV();
            //DGV_Progress.DataSource = SampleResponse.DT_Progress;
        }
        /****************************************************************************************************
         * GUI:     Update channel Informations
         ***************************************************************************************************/
        private ToolTip _Ttip;
        private ToolTip Ttip
        {
            get
            {
                if (_Ttip == null)
                {
                    _Ttip = new ToolTip()
                    { Active = true, UseAnimation = true, UseFading = true, ShowAlways = true, IsBalloon = true, InitialDelay = 1000, AutoPopDelay = 3000, ReshowDelay = 500 };
                }
                return _Ttip;
            }
            set { _Ttip = value; }
        }

        public void GUI_Infos(bool reset = false)
        {
            Reset();
            if (!reset)
            {
                Reset_onStart();
                ODBC_EK = m_TT.ODBC_EK_Selected;
                Limits = m_UC_Betrieb.Limits;
                Limits.DeviceLimits = DeviceLimits;
                Limits.channel_no = Channel_No.ToInt();
                Limits.meas_time_start = DateTime.Now;

                TAGno = Limits.tag_nr.ToString();
                Item = Limits.item;
                Pdno = Limits.pdno;
                UserName = Limits.UserName;
                ProdType = Limits.ProductionType_Desc;
                TimeStart = Limits.meas_time_start.ToShortTimeString();
                TimeEnd = Limits.meas_time_end_Theo.ToShortTimeString();
                PassNo = Limits.pass_no.ToString();
                CalModeDesc = Limits.Cal_Desc;
                Tb_Info.Text = "";
                ChB_Chart.Checked = false;
                
            }
        }

        public void ShowToolTip()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { ShowToolTip(); });return;
            }
            string tpTxt = $"COMport:\t{ucCOM.PortName}\r\n" +
                            $"CalMode_ID:\t{Limits.CalMode_ID}\r\n" +
                            $"Technology_ID:\t{Limits.Technology_ID}\r\n";
            if(DeviceLimits == null) { DeviceLimits = SampleResponse.DeviceLimits; }
            if(Limits.DeviceLimits == null) { Limits.DeviceLimits = DeviceLimits; }
            if (Limits.DeviceLimits != null)
            {
                tpTxt +=    $"Device FW:\t{Limits.DeviceLimits.FW_Version}\r\n" +
                            $"Device cop:\t{Limits.DeviceLimits.Compiled}";
            }
            Ttip.SetToolTip(_Lbl_Channel, tpTxt);
            Ttip.Active = true;
        }
        #region NotActive
        
        /***************************************************************************************
        PortReader: 
        ****************************************************************************************/
        public void WriteMessage(SerialPort port, byte[] data)
        {
            string dataTXT = System.Text.Encoding.ASCII.GetString(data);
            m_Log.Save(Instance, dataTXT, opcode.state);
            //BGW_MessageWriter = BGW_MessageWriter.Initilise(BGW_MessageWriter_DoWork, true, new string[] { port.PortName, dataTXT });
        }
        #endregion NotActive

        /***************************************************************************************
        * Executions:    Start & Stop
        ****************************************************************************************/
        public string BeM_Selected;
        public int ReadDelay_Selected;

        public bool Start()
        {
            CH_WorkingStatusColors(CH_State.inWork);
            if (!Running)
            {
                if (ucCOM.Start(false))
                {
                    UC_Betrieb.Running_Count++;
                    try { GUI_Infos(); } catch { } /* muss ausgeführt werden bevor T&T Gui reset wird*/
                    timStateEngine.Start();
                    m_state = gProcMain.getReadyForTest;
                    return true;
                }
                else
                {
                    Gui_Message(message: $"ERROR: ComPort {ucCH.ucCOM.PortName} ist besetzt");
                }
            }
            else
            {
                Gui_Message(message: $"ERROR: ComPort {ucCH.ucCOM.PortName} ist besetzt");
            }
            m_UC_Betrieb.Channel_started("");
            return false;
        }
        public void Stop()
        {
            timProcess.Stop();
            timCalibration.Stop();
            timStateEngine.Stop();
            if (Running)
            {
                try
                {
                    DeviceCom.SendCMD(Instance, opcode.S999);
                    UC_Betrieb.Running_Count--;
                    StartReady = false;
                    Running = false;
                }
                catch (Exception e)
                {
                    ErrorHandler("Stop", exception: e);
                    Gui_Message(message: e.Message);
                }
            }
            ucCOM.Stop();
            m_TT.SetFocus_Input();
        }
        private void Btn_Start_Click(object sender, EventArgs e)
        {
            bool running = _Btn_Start.Text == "Start";
            if (running)
            { Start(); }
            else
            {
                timProcess.Stop();
                timCalibration.Stop();
                m_BoxReseted = false;
                stateMessageError = "User Cancelation";
                m_state = gProcMain.error;
            }
            m_TT.SetFocus_Input();
        }

        /***************************************************************************************
        * Log Message:
        ****************************************************************************************/
        private string Create_TMP_MeasPath(string portName)
        {
            LogDirectory = Config_Initvalues.MeasLog_Path;
            string filename = "Calibox_" + portName + ".log";
            return (LogDirectory + @"\" + filename);
        }
        public string LogPathMeas { get; set; }
        public string LogDirectory { get; set; }
        public bool LogPathActive { get { return Config_Initvalues.MeasLog_Active; } }

        /*******************************************************************************************************************
       'FUNCTION:    State Engine
       ********************************************************************************************************************/
        private System.Windows.Forms.Timer timStateEngine;
        private void Init_timStateEngine()
        {
            timStateEngine = new System.Windows.Forms.Timer() { Interval = 500 };
            timStateEngine.Tick += new EventHandler(timStateEngine_Tick);
        }

        public bool m_DBinit = false;
        public bool m_timeOutActive = false;
        public bool m_Calibration_Running = false;
        public bool m_TestRunning = false;

        public bool m_BewertungExecuted = false;
        public bool m_BoxReseted { get; set; } = false;
        
        public DateTime m_timeOutDevice;
        public DateTime m_timeOutTest;
        public int m_processCounter = 0;
        public int m_processCounterTotal = 0;
        public DateTime m_procStart;
        public DateTime m_procEnd;
        public int m_stateIntervalSTD = 100;
        private gProcMain m_state_Last;
        private gProcMain _m_state;
        public gProcMain m_state
        {
            get { return _m_state; }
            set
            {
                if (!timStateEngine.Enabled)
                { timStateEngine.Interval = m_stateIntervalSTD; timStateEngine.Start(); }
                _m_state = value;
            }
        }
        public gProcMain m_state_AfterWait;
        public gProcMain m_state_WaitCaller;
        private gProcMain m_state_ProcessRunning = gProcMain.idle;
        
        /*******************************************************************************************************************
        * FUNCTION:    timStateEngine_Tick
        '*******************************************************************************************************************/
        clDeviceCom DeviceCom = new clDeviceCom();
        CH_State calQuality = CH_State.nothing;
        
        string stateMessageError = "";
        string attents;
        public void timStateEngine_Tick(object sender, EventArgs e)
        {
            if ((m_state != m_state_Last) || (m_timeOutActive))
            {
                m_state_Last = _m_state;
                string message = "";
                bool executed = false;
                switch (m_state)
                {
                    case gProcMain.getReadyForTest: /* Channel initialization */
                        if (m_timeOutActive) m_timeOutActive = false;
                        //clDatenBase.Truncate_DB(m_TT.ODBC_EK_Selected); /* only for TESTS, this delete completely all database values */
                        timStateEngine.Interval = m_stateIntervalSTD;
                        DeviceCom.SendCMD(ucCH, opcode.S999, false); /*Identifikatio BOX*/
                        m_Log.Save(Instance, m_state, opcode.state);
                        m_state = gProcMain.StartProcess;
                        break;
                    case gProcMain.StartProcess:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_state_ProcessRunning = m_state;
                        m_Log.Save(Instance, m_state, opcode.state);
                        Gui_Message(m_state);
                        //m_state = gProcMain.idle;
                        timProcess.Start();
                        break;
                    case gProcMain.BoxStatus:
                        if (!m_timeOutActive) m_timeOutActive = true;
                        bool BoxFound = false;
                        if(m_state_ProcessRunning != m_state)
                        {
                            m_state_ProcessRunning = m_state;
                            m_processCounter = 0;
                            m_processCounterTotal = 3;
                        }
                        m_processCounter++;
                        if (m_processCounter <= m_processCounterTotal)
                        {
                            BoxFound = DeviceCom.SendCMD(ucCH, opcode.G100, true);
                        }
                        else
                        {
                            m_timeOutActive = false;
                            m_state = gProcMain.error;
                            stateMessageError = BoxFound ? "" : "Keine Antwort erhalten";
                            m_Log.Save(Instance, m_state, opcode.state, stateMessageError);
                            break;
                        }
                        stateMessageError = BoxFound ? "" : "Keine Antwort erhalten";
                        attents = Attents(m_processCounter,m_processCounterTotal);
                        message = $"{m_state}\t{attents}\tBoxFound: {BoxFound} {stateMessageError}";
                        Gui_Message(m_state, attents: attents);
                        m_Log.Save(Instance, m_state, opcode.state, message);
                        if (BoxFound)
                        {
                            m_timeOutActive = false;
                            m_state = gProcMain.idle;
                        }
                        else
                        {
                            Wait(1000, m_state_ProcessRunning, message, true, true);
                        }
                        break;
                    case gProcMain.BoxReset:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_state_ProcessRunning = m_state;
                        if (!m_BoxReseted)
                        {
                            message = "BoxReset";
                            Gui_Message(m_state);
                            if (!DeviceCom.SendCMD(ucCH, opcode.S999, false))
                            {
                                stateMessageError = "keine Kommunikation";
                                m_Log.Save(Instance, m_state, opcode.state, stateMessageError);
                                m_state = gProcMain.error;
                                break;
                            }
                            else
                            {
                                m_BoxReseted = true;
                                m_Log.Save(Instance, m_state, opcode.state, message);
                                Wait(2000, gProcMain.idle, m_state.ToString(), true, true);
                            }
                        }
                        else { m_state = gProcMain.idle; }
                        ShowToolTip();
                        break;
                    case gProcMain.TestFinished:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_state_ProcessRunning = m_state;
                        m_Log.Save(Instance, m_state, opcode.state);
                        if (!m_TestRunning)
                        { Stop(); }
                        else
                        {
                            m_state = gProcMain.idle;
                            //m_state = gProcMain.Bewertung;
                        }
                        break;
                    case gProcMain.FWcheck:
                        if (Limits.sample_FW_Version_Cal_active)
                        {
                            if (!m_timeOutActive) m_timeOutActive = true;
                            if (m_state_ProcessRunning != m_state)
                            {
                                m_TestRunning = true;
                                //message = $"state: {m_state}\tstarted";
                                m_state_ProcessRunning = m_state;
                                m_processCounter = 0;
                                m_processCounterTotal = 5;
                                message = $"active = {Limits.sample_FW_Version_Cal_active}";
                                Gui_Message(m_state, message);
                                m_Log.Save(Instance, m_state, opcode.state, message);
                                Set_Progress("FWversion");
                            }
                            m_processCounter++;
                            attents = Attents(m_processCounter, m_processCounterTotal);
                            string fwVersion="";
                            bool counterProc = m_processCounter >= m_processCounterTotal;
                            executed = DeviceCom.Get_Sample_FWversion(Instance, out fwVersion);
                            Limits.sample_FW_Version_value = fwVersion;
                            string fwmessage = $"DB: {Limits.sample_FW_Version} Sensor: {fwVersion}";
                            message = $"{attents}\t{fwmessage}";
                            if (Limits.sample_FW_Version_ok)
                            {
                                m_state = gProcMain.idle;
                                m_timeOutActive = false;
                            }
                            else
                            {
                                if (!counterProc)
                                {
                                    Wait(3000, m_state_ProcessRunning, message, true, true);
                                }
                                else
                                {
                                    stateMessageError = $"{fwmessage}";
                                    Limits.ErrorDetected = true;
                                    m_state = gProcMain.error;
                                }
                            }
                            Set_Progress("FWversion", value: fwVersion, errorcode: Limits.sample_FW_Version_state.ToString());
                            //Calibration_Proc_Track("", "FWversion", fwmessage, Limits.sample_FW_Version_state.ToString(), true);
                            m_Log.Save(Instance, m_state, opcode.state, message);
                        }
                        else
                        {
                            m_state = gProcMain.SensorCheck;
                        }
                        SampleResponse.BoxMeasValue = null;
                        break;
                    case gProcMain.SensorCheck:
                        if (!m_timeOutActive) m_timeOutActive = true;
                        if (m_state_ProcessRunning != m_state)
                        {
                            m_TestRunning = true;
                            message = $"state: {m_state}\tstarted";
                            m_state_ProcessRunning = m_state;
                            m_processCounter = 0;
                            m_processCounterTotal = 5;
                            Gui_Message(m_state, "started");
                            DeviceCom.SendCMD(ucCH, opcode.G015, false);
                        }
                        m_processCounter++;
                        attents = Attents(m_processCounter, m_processCounterTotal);
                        if (!DeviceCom.SendCMD(ucCH, opcode.G906, false))
                        {
                            if (m_processCounter > 5 || SampleResponse.OpCode_Response == opcode.s999)
                            {
                                stateMessageError = "NO SENSOR";
                                m_Log.Save(Instance, stateMessageError, opcode.state);
                                m_state = gProcMain.error;
                                break;
                            }
                            m_Log.Save(Instance, m_state, opcode.state, attents);
                            Wait(1000, gProcMain.idle, attents, true, false);
                            break;
                        }
                        m_state = gProcMain.idle;
                        break;
                    case gProcMain.Calibration:
                        if (!m_timeOutActive)
                        {
                            m_timeOutActive = true;
                            m_processCounter = 0;
                            if (timProcess.Enabled) { timProcess.Stop(); }
                            Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc);
                            //Limits.Cal_Time_Start = DateTime.Now;
                        }
                        m_processCounter++;
                        //if (!m_Calibration_Running)
                        if (m_state_ProcessRunning != m_state)
                        {
                            message = $"Calib Modus: {Limits.CalMode}/{Limits.Cal_Desc}"; 
                            if (!DeviceCom.SendCMD(Instance, Limits.CalMode))
                            {
                                stateMessageError = message;
                                Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: CalModeDesc, errorcode: "1");
                                //Calibration_Proc_Track("", Limits.CalMode.ToString(), stateMessageError , "1", true);
                                m_state = gProcMain.error;
                                m_timeOutActive = false;
                                m_Log.Save(Instance, m_state, opcode.state, message + "\t"+"Error");
                                break;
                            }
                            else
                            {
                                //if (!Limits.sample_FW_Version_active && m_processCounter == 0) { m_processCounter++; break; }
                                m_state_ProcessRunning = m_state;
                                m_Calibration_Running = true;
                                Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: CalModeDesc, errorcode: "00");
                                //Calibration_Proc_Track("", Limits.CalMode.ToString(), CalModeDesc, "00", true);
                                m_Log.Save(Instance, m_state, opcode.state, message);
                                if (!timCalibration.Enabled) { timCalibration.Start(); }
                                Wait(2000, gProcMain.Calibration, message, true, true);
                                break;
                            }
                        }
                        if (!timCalibration.Enabled) { timCalibration.Start(); }
                        break;
                    case gProcMain.wait:
                        if (!WaitRunning)
                        {
                            timStateEngine.Interval = 250;
                            WaitRunning = true;
                            m_timeOutDevice = DateTime.Now.AddMilliseconds(m_timStateEngine_Waitms);
                            message = $"wait: {m_timStateEngine_Waitms/1000} sec";
                            m_timeOutActive = true;
                            timCalibration.Stop();
                            timProcess.Stop();
                            timMeasurement.Stop();
                            m_Log.Save(Instance, m_state, opcode.state, message);
                        }
                        TimeSpan timeDiffDevice = (m_timeOutDevice - DateTime.Now);
                        Waittime_Show(timeDiffDevice, WaitMessage);
                        if (timeDiffDevice.TotalSeconds > 0)
                        {
                            if (m_ReadAnswer)
                            {
                                DeviceCom.SendCMD(ucCH, opcode.cmdread, false);
                            }
                            return;
                        }
                        
                        WaitRunning = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        m_timeOutActive = WaitTimeOutActive;
                        if (processRunning) { timProcess.Start(); }
                        if (calibrationRunning) { timCalibration.Start(); }
                        m_state = m_state_AfterWait;
                        break;
                    case gProcMain.Bewertung:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_state_ProcessRunning = m_state;
                        m_BewertungExecuted = true;
                        m_TestRunning = false;
                        try
                        {
                            string state = Limits.test_ok ? "1" : "2";
                            Set_Progress(Limits.CalMode.ToString(), Limits.Cal_Desc, value: CalModeDesc, errorcode: state);
                            //rowState = Search_Progress(out newRowState, out int indexBewertung, searchValue: "CalMode");
                            //rowState["meas_time_end"] = DateNow;
                        }
                        catch { }
                        Limits.meas_time_end = DateTime.Now;
                        Limits.test_ok = calQuality == CH_State.QualityGood ? true : false;
                        if (!Save_Values_To_DB())
                        {
                            stateMessageError = "ERROR: DataBank speichern Bewertung";
                            m_Log.Save(Instance, gProcMain.Bewertung, opcode.state, stateMessageError);
                            m_state = gProcMain.error;
                            break;
                        }
                        //else
                        //{
                            //if(processeNr == processeCount-1 || Error_Detected)
                            //{ m_state = gProcMain.TestFinished; }
                            //else { m_state = gProcMain.idle; }
                        //}
                        message = $"duration: {Limits.meas_time_duration.ToStringMin()}";
                        m_Log.Save(Instance, gProcMain.Bewertung, opcode.state, message);
                        if (!Limits.ErrorDetected ) { Gui_Message(message: message); }
                        m_state = gProcMain.TestFinished;
                        break;
                    case gProcMain.DBinit:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_state_ProcessRunning = m_state;
                        m_TestRunning = true;
                        message = $"sensorID: {Limits.sensor_id}\tTAG-Nr: {Limits.tag_nr}\tPassNo: {Limits.pass_no}";
                        if (!Save_Values_To_DB_INIT())
                        {
                            stateMessageError = "ERROR: DataBank speichern INIT";
                            message += $" {stateMessageError}";
                            m_state = gProcMain.error;
                        }
                        else
                        {
                            m_DBinit = true;
                            m_state = gProcMain.idle;
                        }
                        m_Log.Save(Instance, m_state_ProcessRunning, opcode.state, message);
                        break;
                    case gProcMain.error:
                        if (m_timeOutActive) m_timeOutActive = false;
                        m_timeOutActive = false;
                        Limits.ErrorDetected = true;
                        DGV_Progress.ClearSelection();
                        if (!string.IsNullOrEmpty(stateMessageError))
                        {
                            message = $"ERROR: {stateMessageError}\t{m_state_ProcessRunning}";
                            Gui_Message(message);
                        }
                        m_Log.Save(Instance, m_state, opcode.Error, message);
                        timProcess.Stop();
                        timCalibration.Stop();
                        timMeasurement.Stop();
                        if (m_TestRunning)
                        {
                            m_state = gProcMain.Bewertung;
                            break;
                        }
                        m_timeOutActive = false;
                        m_state = gProcMain.idle;
                        Stop();
                        break;
                    case gProcMain.idle:
                        m_timeOutActive = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        break;
                    default:
                        m_timeOutActive = false;
                        timStateEngine.Interval = m_stateIntervalSTD;
                        break;
                }
            }
        }

        #region GUI Message
        /***************************************************************************************
        * GUI Message:  Error
        ****************************************************************************************/
        [Obsolete("use Gui_Message", false)]
        private void GUI_TXT(string message, bool addMessage = false)
        {
            //if (InvokeRequired)
            //{
            //    try { this.Invoke((MethodInvoker)delegate { GUI_TXT(message, addMessage); }); }
            //    catch (Exception a)
            //    { ErrorHandler("GUI_Error_TXT", exception: a); }
            //    return;
            //}
            bool error = false;
            if (string.IsNullOrEmpty(message)) { return; }
            else
            {
                error = message.ToLower().Contains("error:");
                message = message.Replace("\t", Environment.NewLine);
            }
            if (addMessage)
            {
                string show = (message + Environment.NewLine + Tb_Info.Text).Trim();
                int count = show.Split('\r').Length - 1;
                if (count < 20)
                { Tb_Info.Text = show.Trim(); }
                else
                {
                    int length = show.LastIndexOf(Environment.NewLine);
                    message = show.Substring(0, length).Trim();
                }
            }
            else { message = message.Trim(); }
            GUI_Message(message);
            if (error)
            {
                Limits.ErrorDetected = true;
                if (!Config_Initvalues.Log_Active)
                { m_Log.Save(Instance, message, opcode.Error); }
            }
            //Tb_Info.Refresh();
        }
        private void GUI_Message(string message)
        {
            if (InvokeRequired)
            {
                try { this.Invoke((MethodInvoker)delegate { GUI_Message(message); }); }
                catch (Exception a)
                { ErrorHandler("GUI_Error_TXT", exception: a); }
                return;
            }
            Tb_Info.Text = message;
            //Tb_Info.Refresh();
        }
        [Obsolete("use Gui_Message", true)]
        private void GUI_Error_TXT(string message, bool addMessage = false)
        {
            Task.Factory.StartNew(() =>
            {
                if (InvokeRequired)
                {
                    try { this.Invoke((MethodInvoker)delegate { GUI_TXT(message, addMessage); }); }
                    catch (Exception a)
                    { ErrorHandler("GUI_Error_TXT", exception: a); }
                }
                else
                { GUI_TXT(message, addMessage); }
            });
        }

        #endregion GUI Message

        /*******************************************************************************************************************
        'FUNCTION:    Wait
        ********************************************************************************************************************/
        bool processRunning = false;
        public bool calibrationRunning = false;
        bool WaitTimeOutActive = false;
        public int m_timStateEngine_Waitms = 1000;
        private bool m_ReadAnswer = false;
        bool WaitRunning = false;
        string WaitMessage = "";
        private void Wait(int wait, gProcMain nextStep, gProcMain message, bool start = false)
        {
            Wait(wait, nextStep, message.ToString(), start);
        }
        private void Wait(int wait, gProcMain nextStep, string message, bool start = false, bool readAnswer = true) 
        {
            WaitTimeOutActive = m_timeOutActive;
            WaitRunning = false;
            processRunning = timProcess.Enabled;
            calibrationRunning = timCalibration.Enabled;
            m_state_AfterWait = nextStep;
            m_timStateEngine_Waitms = wait;
            WaitMessage = message;
            m_ReadAnswer = readAnswer;
            if (start)
            {
                timStateEngine.Interval = 10;
                m_state = gProcMain.wait;
            }
        }

        public void Waittime_Show(double timeDiff, string message)
        {
            string time = TimeDiff(timeDiff);
            Gui_Message(time, message: message);
        }
        public void Waittime_Show(TimeSpan timeDiff, string message)
        {
            string time = TimeDiff(timeDiff);
            Gui_Message(time, message: message);
        }
        public void Waittime_Show(double timeDiff, gProcMain callerState, string message = null)
        {
            string time = TimeDiff(timeDiff);
            Gui_Message(time, callerState, message);
        }

        public void Waittime_Show_Cal(string message)
        {
            Waittime_Show(Limits.meas_time_remain.TotalSeconds, m_state, message);
        }

        public void Gui_Message(string time, gProcMain callerState = gProcMain.idle, string message = null, string attents = null)
        {
            Task.Factory.StartNew(() =>
            {
                StringBuilder sb = new StringBuilder();
                if (callerState != gProcMain.idle) { sb.Append(callerState.ToString()); }
                sb.Append(Environment.NewLine);
                if (!string.IsNullOrEmpty(time))
                {
                    sb.Append(time);
                    sb.Append(Environment.NewLine);
                }
                if (!string.IsNullOrEmpty(attents))
                {
                    sb.Append(time);
                    sb.Append(Environment.NewLine);
                }
                if (!string.IsNullOrEmpty(message)) { sb.Append(message.Trim()); }
                GUI_TXT(sb.ToString(), false);
            });
        }
        public void Gui_Message(gProcMain callerState = gProcMain.idle, string message = null, string attents = null)
        {
            Gui_Message(null, callerState, message, attents);
        }

        /*******************************************************************************************************************
        'FUNCTION:    Process
        ********************************************************************************************************************/
        private System.Windows.Forms.Timer timProcess;
        private void Init_timProcess()
        {
            timProcess = new System.Windows.Forms.Timer() { Interval = 1000 };
            timProcess.Tick += new EventHandler(timProcesse_Tick);
        }

        gProcMain ProcesseLast = gProcMain.wait;
        gProcMain ProcesseRunning = gProcMain.idle;
        int processeNr = 0;
        int _processCount = 0;
        int processeCount
        {
            get
            {
                if (_processCount == 0)
                { _processCount = gProgress.Count; }
                return _processCount;
            }
        }
        bool ProcesseLastArrived { get { return processeNr == processeCount; } }
        public void timProcesse_Tick(object sender, EventArgs e)
        {
            if (m_state == gProcMain.error)
            {
                timCalibration.Stop();
                timMeasurement.Stop();
                timProcess.Stop();
                return;
            }
            else
            if (ProcesseRunning != ProcesseLast && (m_state == gProcMain.idle || m_state == gProcMain.StartProcess))
            {
                bool nextProcess = false;
                switch (m_state)
                {
                    case gProcMain.StartProcess:
                        processeNr = 0;
                        ProcesseRunning = gProgress[0];
                        nextProcess = true;
                        break;
                    default:
                        nextProcess = true;
                        break;
                }
                if (nextProcess)
                {
                    if (!ProcesseLastArrived) { processeNr++; }
                    ProcesseLast = ProcesseRunning;
                    ProcesseRunning = gProgress[processeNr];
                    m_state = ProcesseRunning;
                }
                if (ProcesseLastArrived)
                {
                    timCalibration.Stop();
                    timMeasurement.Stop();
                    timProcess.Stop();
                }
            }
        }


        /*******************************************************************************************************************
        'FUNCTION:    Save Result to DataBase
        ********************************************************************************************************************/
        private bool Save_Values_To_DB()
        {
            bool result = clDatenBase.MeasVal_Update(ODBC_EK, Limits);
            clDatenBase.MeasValTemp_Insert(ODBC_EK, Limits.sensor_id, Limits.pass_no.ToString(), SampleResponse.DT_Progress);
            return result;
        }

        private bool Save_Values_To_DB_INIT()
        {
            return clDatenBase.MeasVal_Insert_Init(ODBC_EK, Limits);
        }

        /*******************************************************************************************************************
        'Values:     Device Measurement Values
        ********************************************************************************************************************/
        private clDeviceLimits _DeviceLimits;
        public clDeviceLimits DeviceLimits
        {
            get { return _DeviceLimits; }
            set
            {
                _DeviceLimits = value;
                Limits.DeviceLimits = value;
            }
        }

        private string lLast = "";
        public DeviceResponse SampleResponse { get; set; } = new DeviceResponse(null);

        /*******************************************************************************************************************
        * FUNCTION:    Process Calibration GUI
        ********************************************************************************************************************/
        private void Set_Progress(string boxmode_hex, string boxmode_desc=null, string value = null, string errorcode=null)
        {
            if (string.IsNullOrEmpty(boxmode_desc)) { boxmode_desc = boxmode_hex; }
            SampleResponse.Set_Progress(boxmode_hex, boxmode_desc, value, errorcode);
        }

        private void Update_DGV()
        {
            int i = 0;
            
            foreach (var a in DGV_Progress.Rows)
            {
                Update_DGV(i);
                i++;
            }
        }

        private void Update_DGV(int selectedIndex)
        {
            if (DGV_Progress.InvokeRequired)
            {
                DGV_Progress.Invoke((MethodInvoker)delegate { Update_DGV(selectedIndex); });
                return;
            }
            if (DGV_Progress.Rows.Count > 0)
            {
                DGV_Progress.Rows[0].Selected = true;
                DGV_Progress.FirstDisplayedScrollingRowIndex = 0;
                var v = DGV_Progress.Rows[0].Cells[clHandler.ProgHeader.boxerror_hex.ToString()].Value;
                if (v != null)
                {
                    switch (v.ToString())
                    {
                        case "":
                        case "0":
                            break;
                        case "2":
                        case "00":
                            try
                            {
                                DGV_Progress.Rows[0].DefaultCellStyle.BackColor = MT_Colors[selection.rating_GOOD_active];
                             
                            } catch { }
                            break;
                        default:
                            try
                            {
                                DGV_Progress.Rows[0].DefaultCellStyle.BackColor = MT_Colors[selection.rating_BAD_active];
                                
                            } catch { }
                            break;
                    }
                }
                DGV_Progress.Refresh();
                DGV_Progress.Sort(DGV_Progress.Columns[ProgHeader.meas_time_start.ToString()], ListSortDirection.Descending);
            }
        }

        /*******************************************************************************************************************
        * FUNCTION:    Process Calibration Variables
        ********************************************************************************************************************/
        private System.Windows.Forms.Timer timCalibration;
        private void Init_timCalibration(bool start = false, int interval = 250)
        {
            timCalibration = new System.Windows.Forms.Timer() { Interval = interval };
            timCalibration.Tick += new EventHandler(timCalibration_Tick);
            if (start)
            { timCalibration.Start(); }
        }

        /*******************************************************************************************************************
        *FUNCTION:    State Engine Calibration
        ********************************************************************************************************************/
        int CountCalib = 0;
        int CountCommandChange = 0;
        int CalibNoAnswerCounter = 0;
        string noAnswer = "";
        bool g901Receved = false;
        DeviceResponseValues DRV_Calib = new DeviceResponseValues(opcode.state);

        public void timCalibration_Tick(object sender, EventArgs e)
        {
            if (m_state == gProcMain.error) { timProcess.Stop(); return; }
            bool AnswerReceved = DeviceCom.SendCMD(Instance, opcode.cmdread, false);
            if (AnswerReceved)
            {
                int index = SampleResponse.ResponseListCount == 0 ? 0 : SampleResponse.ResponseListCount - 1;
                DRV_Calib = SampleResponse.ResponseList[index];
            }
            if (m_state == gProcMain.Calibration)
            {
                if (CountCalib == 0)
                {
                    timCalibration.Interval = 1000;
                    CountCommandChange = 0;
                    CalibNoAnswerCounter = 0;
                    calibrationRunning = true;
                    g901Receved = false;
                    CountCalib++;
                    DeviceCom.SendCMD(Instance, opcode.S901, false);
                    return;
                }
                CountCalib++;
                if (!AnswerReceved)
                {
                    CalibNoAnswerCounter++;
                    if (CalibNoAnswerCounter > 10)
                    {
                        if (!DeviceCom.SendCMD(Instance, opcode.G100, true))
                        {
                            timMeasurement.Stop();
                            stateMessageError = "timCalibration keine Antwort";
                            m_state = gProcMain.error;
                        }
                        CalibNoAnswerCounter = 0;
                        CountCommandChange++;
                        if(CountCommandChange > 3)
                        {
                            m_state = gProcMain.error;
                        }
                    }
                }
                else
                {
                    CountCommandChange = 0;
                    CalibNoAnswerCounter = 0;
                }
                Set_ChartVisible();
            }
            if (SampleResponse.TestFinalise || DRV_Calib.OpCode == opcode.s999)
            {
                //Limits.Cal_Time_End = DateTime.Now;
                
                timMeasurement.Stop();
                if (DRV_Calib.OpCode == opcode.s999)
                {
                    stateMessageError = "Sensor Kommunikation abgebrochen";
                    SampleResponse.TestError = true;
                    SampleResponse.TestFinalise = true;
                }
                else
                {
                    if (SampleResponse.BoxMode_hex != "37")
                    {
                        int trys = 3;
                        int i = 0;
                        bool found = false;
                        while (i < trys && !found)
                        {
                            DeviceCom.SendCMD(ucCH, opcode.G200, true);
                            if (Get_Responsevalues(opcode.g200, out DeviceResponseValues drv))
                            {
                                found = true;
                                DRV_Calib = drv;
                            }
                            i++;
                        }
                    }
                    stateMessageError = $"{DRV_Calib.BoxMode_desc} {DRV_Calib.BoxErrorCode_desc}";
                }
                gProcMain state;
                if (!SampleResponse.TestError)
                {
                    Limits.test_ok = true;
                    calQuality = CH_State.QualityGood;
                    m_Log.Save(Instance, m_state, opcode.state, $"SUBPROCESS QUALITY GOOD {stateMessageError}" );
                    state = gProcMain.idle;
                }
                else
                {
                    Limits.test_ok = false;
                    m_Log.Save(Instance, m_state, opcode.state, $"SUBPROCESS ERROR {stateMessageError}");
                    state = gProcMain.error;
                }
                if (!timProcess.Enabled) { timProcess.Start(); }
                ChB_Chart.Checked = false;
                m_Calibration_Running = false;
                timCalibration.Stop();
                Wait(500, state, m_state, true);
            }
            else
            {
                //if(SampleResponse.BoxMode_desc.ToLower().Contains("idle")) { boxModeDesc = SampleResponse.BoxMode_desc; }
                noAnswer = $"{SampleResponse.BoxMode_desc.Replace("_", " ").Replace("Mode","").Replace("Box","")}\tCount: {CountCalib}; NoAnswer: {CalibNoAnswerCounter}";
                Waittime_Show_Cal(noAnswer);
            }
        }

        private bool SetBox_Send_Continous(opcode OpCodeReceved, string boxModeDesc, bool waitAnswer = true)
        {
            if (boxModeDesc.ToLower().Contains("calib") && !g901Receved)
            {
                if (waitAnswer)
                {
                    DeviceCom.SendCMD(Instance, opcode.S901, true);
                    g901Receved = SampleResponse.g901_receved;
                }
                else
                {
                    DeviceCom.SendCMD(Instance, opcode.S901, waitAnswer);
                    return true;
                }
                
            }
            return false;
        }
        private bool GetBox_Values(out opcode OpCodeReceved, out DeviceResponse response)
        {
            bool AnswerReceved = DeviceCom.SendCMD(Instance, opcode.cmdread, false);
            OpCodeReceved = SampleResponse.OpCode_Response;
            response = SampleResponse;
            return AnswerReceved;
        }
        private void Set_ChartVisible()
        {
            if (!ChB_Chart.Visible)
            {
                if (SampleResponse.DT_Measurements.Rows.Count > 0)
                {
                    ChB_Chart.Visible = true;
                    ChB_Chart.Checked = true;
                }
            }
        }
        private bool Get_Responsevalues(opcode cmd, out DeviceResponseValues response)
        {
            foreach (DeviceResponseValues drv in SampleResponse.ResponseList)
            {
                if (drv.OpCode == cmd)
                {
                    response = drv;
                    return true;
                }
            }
            response = null;
            return false;
        }

        /*******************************************************************************************************************
       * FUNCTION:    Chart Measurement Timer
       ********************************************************************************************************************/
        private System.Windows.Forms.Timer _timMeasurement;
        private System.Windows.Forms.Timer timMeasurement { get { if(_timMeasurement == null) { Init_timMeasurement(); }return _timMeasurement; } }
        private void Init_timMeasurement(bool start = false, int interval = 1000)
        {
            _timMeasurement = new System.Windows.Forms.Timer() { Interval = interval };
            _timMeasurement.Tick += new EventHandler(timMeasurement_Tick);
            if (start)
            { timMeasurement.Start(); }
        }
        public void timMeasurement_Tick(object sender, EventArgs e)
        {
            Chart_Update();
        }
        private void Chart_Update()
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate { Chart_Update(); }); return;
            }

            if (SampleResponse.DT_Measurements.Rows.Count > 0)
            {
                DataRow[] rows = SampleResponse.DT_Measurements.Select($"boxmode_hex = '{SampleResponse.BoxMode_hex}'");
                int rCount = rows.Length - 1;
                if (rCount > 0)
                {
                    DataTable dtAVG = SampleResponse.DT_Measurements.Clone();
                    if (rCount > Chart_ShowVaulesQuantiy - 1)
                    {
                        
                        try
                        {
                            for (int i = Chart_ShowVaulesQuantiy; i > 0; i--)
                            { dtAVG.ImportRow(rows[rCount - i]); }
                        }
                        catch
                        { }
                    }
                    else { dtAVG = rows.CopyToDataTable(); }
                    try
                    {
                        Chart_Measurement.DataSource = dtAVG;
                        Chart_Measurement.DataBind();
                    }
                    catch { }
                    try
                    {
                        switch (ChartMode_Selection)
                        {
                            case ChartMode.STDdeviation:
                                //if (rCount > 15)
                                {
                                    double stdDev = 0;
                                    try { stdDev = Convert.ToDouble(rows[rCount]["stddeviation"]); } catch { }
                                    Chart_Measurement.Series["stddeviation"].Color = stdDev > 1.5 ? MT_rating_Bad_Active : MT_rating_God_Active;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        /****************************************************************************************************
         * Chart:       Measurement
         ***************************************************************************************************/
        public enum ChartMode { STDdeviation, MeanValue, ErrorValue, RefMean, All, RefValue, STD_Error}
        public ChartMode ChartMode_Selection; //= ChartMode.STDdeviation;
        private void Init_Chart()
        {
            Chart_Measurement.Visible = false;
            Chart_Measurement.DataSource = SampleResponse.DT_Measurements;
            Chart_Measurement.DataBind();
            Chart_Measurement.Series.Clear();
            /*Mode MeanValue*/
            var serie_refvalue = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "refvalue",
                Color = System.Drawing.Color.Gray,
                IsVisibleInLegend = false,
                IsValueShownAsLabel = false,
                //IsXValueIndexed = true,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line,
                BorderWidth = 4,
                XValueMember = "ID",
                YValueMembers = "refvalue"
            };
            /*Mode MeanValue*/
            var serie_meanvalue = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "meanvalue",
                Color = System.Drawing.Color.Yellow,
                IsVisibleInLegend = false,
                IsValueShownAsLabel = false,
                //IsXValueIndexed = true,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line,
                BorderWidth = 4,
                XValueMember = "ID",
                YValueMembers = "meanvalue"
            };
            /*Mode STDdeviation*/
            var serie_stddev = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "stddeviation",
                Color = System.Drawing.Color.Red,
                IsVisibleInLegend = false,
                IsValueShownAsLabel = false,
                //IsXValueIndexed = true,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line,
                BorderWidth = 4,
                XValueMember = "ID",
                YValueMembers = "stddeviation"
            };
            /*Mode ErrorValue*/
            var serie_errorvalue = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "errorvalue",
                Color = System.Drawing.Color.Orange,
                IsVisibleInLegend = false,
                IsValueShownAsLabel = false,
                //IsXValueIndexed = true,
                ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line,
                BorderWidth = 4,
                XValueMember = "ID",
                YValueMembers = "errorvalue"
            };
            Chart_Measurement.Series.Add(serie_refvalue);
            Chart_Measurement.Series.Add(serie_meanvalue);
            Chart_Measurement.Series.Add(serie_stddev);
            Chart_Measurement.Series.Add(serie_errorvalue);
            Chart_Measurement.ChartAreas[0].AxisY.IsStartedFromZero = false;
            Chart_Measurement.ChartAreas[0].AxisX.Interval = 3;
            Chart_Measurement.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Microsoft Sans Serif", 5);
            Chart_Measurement.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Microsoft Sans Serif", 6);
            Chart_Measurement.ChartAreas[0].AxisX.IsMarginVisible = false;
            Chart_Measurement.ChartAreas[0].AxisY.IsMarginVisible = false;
            Chart_Measurement.ChartAreas[0].AxisY.LabelStyle.Format = "0.##";
            ChB_Chart.Checked = false;
        }

        private int Chart_ShowVaulesQuantiy = 15;

        private void Change_ChartModeSelection(ChartMode selection)
        {
            if (InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate { Change_ChartModeSelection(selection); }); return;
            }
            bool refValues = false;
            bool meanValues = false;
            bool stdValues = false;
            bool errorValues = false;
            switch (selection)
            {
                case ChartMode.STDdeviation:
                    Chart_ShowVaulesQuantiy = 10;
                    stdValues = true;
                    break;
                case ChartMode.MeanValue:
                    Chart_ShowVaulesQuantiy = 15;
                    meanValues = true;
                    break;
                case ChartMode.ErrorValue:
                    Chart_ShowVaulesQuantiy = 15;
                    errorValues = true;
                    break;
                case ChartMode.RefMean:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    meanValues = true;
                    break;
                case ChartMode.All:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    meanValues = true;
                    stdValues = true;
                    errorValues = true;
                    break;
                case ChartMode.RefValue:
                    Chart_ShowVaulesQuantiy = 15;
                    refValues = true;
                    break;
                case ChartMode.STD_Error:
                    Chart_ShowVaulesQuantiy = 10;
                    errorValues = true;
                    stdValues = true;
                    break;
                default:
                    Chart_ShowVaulesQuantiy = 15;
                    break;
            }
            Chart_Measurement.Series["refvalue"].Enabled = refValues;
            Chart_Measurement.Series["meanvalue"].Enabled = meanValues;
            Chart_Measurement.Series["stddeviation"].Enabled = stdValues;
            Chart_Measurement.Series["errorvalue"].Enabled = errorValues;
            ChartMode_Selection = selection;
        }
        private void Chart_Visible(bool visible)
        {
            Chart_Measurement.Visible = visible;
            if (visible)
            {
                Change_ChartModeSelection(ChartMode_Selection);
                if (calibrationRunning)
                { timMeasurement.Start(); }
                Chart_Measurement.BringToFront();
            }
            else
            {
                timMeasurement.Stop();
            }
        }

        private void ChB_Chart_CheckedChanged(object sender, EventArgs e)
        {
            Chart_Visible(ChB_Chart.Checked);
        }




        /****************************************************************************************************
         * Chart:       Measurement Menu
         ***************************************************************************************************/

        private void sTDDeviationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.STDdeviation);
        }

        private void refValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.RefValue);
        }

        private void meanVauesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.MeanValue);
        }

        private void errorValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.ErrorValue);
        }

        private void allValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.All);
        }

        private void refMeanValuesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.RefMean);
        }

        private void sTDDeviationErrorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Change_ChartModeSelection(ChartMode.STD_Error);
        }

        private void DGV_Progress_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //Update_DGV();
        }

        private void DGV_Progress_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Update_DGV();
        }

        private void DGV_Progress_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
    }


}
