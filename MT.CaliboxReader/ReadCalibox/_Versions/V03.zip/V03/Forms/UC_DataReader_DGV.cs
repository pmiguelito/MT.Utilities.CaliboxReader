﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ReadCalibox.clConfig;

namespace ReadCalibox
{
    public partial class UC_DataReader_DGV : UserControl
    {
        public static int ChannelNr = 0;
        public static UC_Channel channel_Selected { get { return Config_ChannelsList[ChannelNr]; } }
        DataTable DT_Meas { get { return channel_Selected.SampleResponse.DT_Measurements; } }

        DataTable DT_Cal { get { return channel_Selected.SampleResponse.DT_Progress; } }

        DataTable _DT_Selected;
        DataTable DT_Selected
        {
            get
            {
                switch (CoB_DTselected.SelectedItem)
                {
                    case "DT_Meas":
                        _DT_Selected = DT_Meas;
                        break;
                    case "DT_Cal":
                        _DT_Selected = DT_Cal;
                        break;
                    default:
                        break;
                }
                return _DT_Selected; 
            }
        }

        #region Constructor
        /****************************************************************************************************
         * Constructor
        '***************************************************************************************************/
        public UC_DataReader_DGV()
        {
            InitializeComponent();
        }
        private void UC_DataReader_DGV_Load(object sender, EventArgs e)
        {
            Init_CoB_Selection();
            Init_DGV();
            Init_Timer();
        }

        #endregion Constructor
        void Init_DGV()
        {
            _DGV_Message.DataSourceChanged -= _DGV_Message_DataSourceChanged;
            _DGV_Message.DataSource = DT_Selected;
            try { _DGV_Message.Sort(_DGV_Message.Columns["meas_time_start"], ListSortDirection.Descending); } catch { }
            try { _DGV_Message.Sort(_DGV_Message.Columns["ID"], ListSortDirection.Descending); } catch { }
            //_DGV_Message.Columns["BoxMode_Desc"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _DGV_Message.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            //_DGV_Message.AutoSize = true;
            if (_DGV_Message.Rows.Count > 0)
            {
                _DGV_Message.ClearSelection();
                _DGV_Message.FirstDisplayedScrollingRowIndex = 0;
                _DGV_Message.AutoResizeColumns();
                _DGV_Message.Refresh();
            }
            _DGV_Message.DataSourceChanged += _DGV_Message_DataSourceChanged;
        }
        void Init_CoB_Selection()
        {
            CoB_DTselected.Items.Add("DT_Meas");
            CoB_DTselected.Items.Add("DT_Cal");
            CoB_DTselected.SelectedItem = "DT_Meas";
        }

        /****************************************************************************************************
         * Timer
        '***************************************************************************************************/
        #region Timer
        static Timer UpdateTimer = new Timer();
        void Init_Timer()
        {
            UpdateTimer = new Timer() { Interval = 3000 };
            UpdateTimer.Tick += new EventHandler(timer_Tick);
        }

        static void TimerRunning(bool run)
        {
            if (UpdateTimer.Enabled)
            {
                if (!run)
                { UpdateTimer.Stop(); }
            }
            else if (run) { UpdateTimer.Start(); }
        }
        void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (_DGV_Message.Rows.Count > 0)
                {
                    foreach (DataGridViewRow row in _DGV_Message.SelectedRows)
                    {
                        row.Selected = false;
                    }
                    
                    //_DGV_Message.Rows[0].Selected = true;
                    _DGV_Message.Rows[0].Cells[0].Selected = true;
                    _DGV_Message.FirstDisplayedScrollingRowIndex = 0;
                    _DGV_Message.ClearSelection();
                }
                //_DGV_Message.Refresh();
            }
            catch { }
        }


        #endregion Timer

        private void _Btn_Refresh_Click(object sender, EventArgs e)
        {
            try
            {
                if (_CkB_Autorefresh.Checked)
                {
                    _CkB_Autorefresh.Checked = false;
                    
                }
                else
                { Refresh_DGV(); }
            }
            catch { }
        }

        private void Refresh_DGV()
        {
            _DGV_Message.DataSourceChanged -= _DGV_Message_DataSourceChanged;
            UpdateTimer.Stop();
            _DGV_Message.Enabled = true;
            _DGV_Message.DataSource = DT_Selected.Copy();
            try { _DGV_Message.Sort(_DGV_Message.Columns["meas_time_start"], ListSortDirection.Descending); } catch { }
            try { _DGV_Message.Sort(_DGV_Message.Columns["ID"], ListSortDirection.Descending); } catch { }
            _DGV_Message.ClearSelection();
            _DGV_Message.DataSourceChanged += _DGV_Message_DataSourceChanged;
        }

        private void _CkB_Autorefresh_CheckedChanged(object sender, EventArgs e)
        {
            if (_CkB_Autorefresh.Checked)
            {
                //_DGV_Message.Enabled = false;
                _DGV_Message.DataSource = DT_Selected;
                try { _DGV_Message.Sort(_DGV_Message.Columns["meas_time_start"], ListSortDirection.Descending); } catch { }
                try { _DGV_Message.Sort(_DGV_Message.Columns["ID"], ListSortDirection.Descending); } catch { }
                _DGV_Message.ClearSelection();
                UpdateTimer.Start();
            }
            else
            {
                Refresh_DGV();
            }
        }
        
        private void _DGV_Message_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            ChannelNr = (int)NumUD_Ch.Value;
            _DGV_Message.DataSource = DT_Selected;
        }

        private void _DGV_Message_DataSourceChanged(object sender, EventArgs e)
        {
            Init_DGV();
        }

        private void CoB_DTselected_SelectedIndexChanged(object sender, EventArgs e)
        {
            Init_DGV();
        }
    }
}
