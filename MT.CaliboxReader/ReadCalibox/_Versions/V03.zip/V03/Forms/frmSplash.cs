﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadCalibox
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
        }

        public string SWtitel { get; set; }
        public string SWversion { get; set; }
        private void FrmSplash_Load(object sender, EventArgs e)
        {
            timProgBar.Start();
            lbl_Version.Text = SWversion;
            lbl_Titel.Text = SWtitel;
        }
        private void TimProgBar_Tick(object sender, EventArgs e)
        {
            progBar.Increment(1);
            if(progBar.Value == 100)
            {
                progBar.Value = 0;
            }
        }

    }
}
