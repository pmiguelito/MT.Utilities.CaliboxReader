﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ReadCalibox.clHandler;
using static ReadCalibox.clConfig;
using STDhelper;
using static STDhelper.clMTcolors;

namespace ReadCalibox
{
    public partial class UC_Config_DB : UserControl
    {

        /*******************************************************************************************************
        * Constructor:
        '*******************************************************************************************************/
        public string Title
        {
            get { return GrB_ODBC.Text; }
            set { GrB_ODBC.Text = value; }
        }
        public bool ReadOnly
        {
            get { return GrB_ODBC.Enabled; }
            set { GrB_ODBC.Enabled = value; }
        }

        public UC_Config_DB(string title)
        {
            InitializeComponent();
            Title = title;
        }

        /*******************************************************************************************************
        * ODBC:
        '*******************************************************************************************************/
        public bool ODBC_Initial_Exists { get { return ODBC_Exists(ODBC_Init); } }

        public string ODBC_Init { get { return TB_ODBC_Initial.Text; } set { TB_ODBC_Initial.Text = value; ODBC_ProdTypes_GUI = value; } }
        private bool ODBC_Exists(string odbc)
        {
            return ODBC_TT.ODBC.GetODBC_status(odbc);
        }
        private void TB_ODBC_Initial_Leave(object sender, EventArgs e)
        {
            dt_ODBC_Tables_Count = -1;
            TB_ODBC_Initial.ForeColor = ODBC_Initial_Exists ? MT_rating_God_Active : MT_rating_Bad_Active;
            Init_CoB_Tables();
        }

        /*******************************************************************************************************
        * ProdType Table:
        '*******************************************************************************************************/
        public string ProdType_Table
        {
            get { return TB_ProdType_Table.Text; }
            set { TB_ProdType_Table.Text = value; }
        }
        public bool DB_ProdType_Active
        {
            get { return CkB_DB_ProdType_Active.Checked; }
            set { CkB_DB_ProdType_Active.Checked = value; Init_CoB_Tables(); }
        }

        private void CkB_DB_ProdType_Active_CheckedChanged(object sender, EventArgs e)
        {
            if ((m_TT != null && CkB_DB_ProdType_Active.Focused)|| (CoB_Tables.Items.Count <1 && DB_ProdType_Active))
            {
                bool dbModus = CkB_DB_ProdType_Active.Checked;
                TT_ProdTypeMode(dbModus);
                Init_CoB_Tables();
                UC_Betrieb.Check_ODBC_Init();
            }
        }

        private void TT_ProdTypeMode(bool dbModus)
        {
            try
            {
                if (!dbModus)
                { TT_ProdType.clTTProdType.TTprodTypes = ProdTypes_Config; }
                m_TT.DBvaluesActive = dbModus;
            }
            catch { }
            Table_Modus(dbModus);
        }
        private void Table_Modus(bool dbModus)
        {
            TB_ProdType_Table.Visible = !dbModus;
            CoB_Tables.Visible = dbModus;
            TB_DoCheckPass.Enabled = !dbModus;
            TB_ProcNr.Enabled = !dbModus;
        }

        private DataTable dt_ODBC_Tables;
        private int dt_ODBC_Tables_Count;
        private void Init_CoB_Tables()
        {
            if (DB_ProdType_Active || dt_ODBC_Tables_Count <1)
            {
                string table = ProdType_Table;
                if (ODBC_Exists(ODBC_Init))
                {
                    dt_ODBC_Tables = ODBC_TT.ODBC.DB_Get_TableNames(ODBC_Init, out dt_ODBC_Tables_Count);
                    CoB_Tables.SelectedIndexChanged -= CoB_Tables_SelectedIndexChanged;
                    CoB_Tables.DisplayMember = "TABLE_NAME";
                    CoB_Tables.ValueMember = "TABLE_NAME";
                    CoB_Tables.DataSource = dt_ODBC_Tables;
                    CoB_Tables.SelectedIndexChanged += CoB_Tables_SelectedIndexChanged;
                    
                    if (string.IsNullOrEmpty(table)) { CoB_Tables.SelectedIndex = 0; }
                    if (dt_ODBC_Tables.Select($"TABLE_NAME = '{table}'").Length > 0)
                    {
                        if (CoB_Tables.SelectedValue != table)
                        {
                            CoB_Tables.SelectedValue = table;
                            ProdType_Table = CoB_Tables.Text;
                            TT_ProdTypeMode(DB_ProdType_Active);
                        }
                    }
                    
                }
            }
        }

        /*******************************************************************************************************
        * ProcNr:
        '*******************************************************************************************************/
        private string procNr { get { return TB_ProcNr.Text; } set { TB_ProcNr.Text = value; } }
        public int ProcNr
        {
            get { return m_TT.ParseStringToInt(procNr); }
            set { procNr = value.ToString(); }
        }

        private void TB_ProcNr_Leave(object sender, EventArgs e)
        {

        }


        /*******************************************************************************************************
        * DoCheckPass:
        '*******************************************************************************************************/
        public string DoCheckPassTXT { get { return TB_DoCheckPass.Text; } set { TB_DoCheckPass.Text = value; } }
        private void TB_DoCheckPass_MouseLeave(object sender, EventArgs e)
        {
            if (m_TT != null)
            {
                m_TT.Do_check_TT = TB_DoCheckPass.Text;
            }
        }

        private void CoB_Tables_SelectedIndexChanged(object sender, EventArgs e)
        {
            ProdType_Table = CoB_Tables.Text;
        }
    }
}
