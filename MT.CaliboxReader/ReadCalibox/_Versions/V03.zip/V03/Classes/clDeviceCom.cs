﻿using OneWire_DataConverter;
using static OneWire_DataConverter.OneWire_TDLdatatype;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static ReadCalibox.clDataBase;
using static ReadCalibox.clHandler;
using static STDhelper.clSTD;
using System.Data;

namespace ReadCalibox
{
    public class clDeviceCom
    {

        /****************************************************************************************************
         * SerialPort:  Write
         ***************************************************************************************************/
        public void SendCMD(SerialPort port, opcode cmd, string parameter = null)
        {
            if (!port.IsOpen) { port.Open(); }
            string stringCMD = "";
            if (parameter == null)
            { stringCMD = cmd.ToString(); }
            else
            {
                stringCMD = parameter;
            }
            port.Write(stringCMD);
        }


        /****************************************************************************************************
         * Command:  Write
         ***************************************************************************************************/

        public bool SendCMD(UC_Channel ucCH, opcode cmd, bool waitAnswer = true, string sendCMD = null)
        {
            //Task<bool> t = SendCMD_Task(ucCH, cmd, waitAnswer, sendCMD);

            return SendCMD_Task(ucCH, cmd, waitAnswer, sendCMD).Result;
        }
        private void SendCMD_Thread(UC_Channel ucCH, opcode cmd, bool waitAnswer = true, string sendCMD = null)
        {
            Thread thread = new Thread(_ => Send_cmd(ucCH, cmd, waitAnswer, sendCMD));
            thread.Start();
            thread.Join();
        }
        private async Task<bool> SendCMD_Task(UC_Channel ucCH, opcode cmd, bool waitAnswer = true, string sendCMD = null)
        {
            if (waitAnswer)
            {
                return Send_cmd(ucCH, cmd, waitAnswer, sendCMD);
            }
            else
            {
                Task<bool> t = Task<bool>.Factory.StartNew(() =>
                {
                    return Send_cmd(ucCH, cmd, waitAnswer, sendCMD);
                });
            }
            //if (waitAnswer)
            //{
            //    CancellationTokenSource ts = new CancellationTokenSource();
            //    Thread thread = new Thread(CancelToken);
            //    thread.Start();
            //    t.Wait(ts.Token);
            //    ts.Dispose();
            //    return t.Result;
            //}
            return true;
        }

        private static void CancelToken(Object obj)
        {
            Thread.Sleep(300);
            CancellationTokenSource source = obj as CancellationTokenSource;
            if (source != null) source.Cancel();
        }


        private bool Send_cmd(UC_Channel ucCH, opcode cmd, bool waitAnswer = true, string sendCMD = null)
        {

            SerialPort port = ucCH.ucCOM.Serialport;
            int readRepeat = 100;
            int readDelay = ucCH.ucCOM.ReadDelay_int;
            //bool stopbyNewLine = ucCH.ucCOM.ReadLine;
            bool stopbyNewLine = true;
            int wait = 20;
            bool CMDread = true;
            bool CMDsend = true;
            bool BoxIdentification = false;
            bool DiscardBuffer = false;
            switch (cmd)
            {
                case opcode.G015:
                    DiscardBuffer = true;
                    stopbyNewLine = true;
                    break;
                case opcode.G200:
                    break;
                case opcode.S100:
                    CMDread = false;
                    break;
                case opcode.S500:
                    CMDread = false;
                    break;
                case opcode.S674:
                    CMDread = false;
                    break;
                case opcode.G901:
                    stopbyNewLine = true;
                    CMDsend = false;
                    break;
                case opcode.S901:
                    cmd = opcode.G901;
                    break;
                case opcode.S999:
                    try
                    {
                        DiscardBuffer = true;
                        //readRepeat = 100;
                        stopbyNewLine = false;
                        BoxIdentification = ucCH.DeviceLimits == null;
                    }
                    catch
                    {
                        return false;
                    }
                    break;
                case opcode.cmdread:
                    CMDsend = false;
                    stopbyNewLine = true;
                    break;
                default:
                    break;
            }
            if (CMDsend)
            {
                if (DiscardBuffer)
                {
                    try
                    {
                        port.DiscardInBuffer();
                        port.DiscardOutBuffer();
                    }
                    catch { }
                }
                SendCMD(port, cmd, sendCMD);
                m_Log.Save(ucCH, $"{cmd} {sendCMD}", opcode.cmdsend);
            }
            if (CMDread)
            {
                if (CMDsend) { Thread.Sleep(wait); }
                return Read(ucCH, cmd, readRepeat, readDelay, stopbyNewLine, BoxIdentification);
            }
            else { return true; }
        }
        /****************************************************************************************************
         * Command:  Read
         ***************************************************************************************************/
        private bool Read(UC_Channel ucCH, opcode cmd, int readRepeat = 5, int readDelay = 25, bool stopbyNewLine = true, bool boxidentification = false)
        {
            if (Read_SerialPort(ucCH.ucCOM, out string responseTXT, readRepeat, readDelay, stopbyNewLine))
            {
                bool opcodeChanged = false;
                try
                {
                    if (cmd == opcode.S999) { responseTXT = responseTXT.Replace("*", ""); }
                    if (boxidentification)
                    { ucCH.SampleResponse.BoxIdentification = true; }
                    else
                    { ucCH.SampleResponse.DeviceLimits = ucCH.DeviceLimits; }
                    ucCH.SampleResponse.OpCode_Request = cmd;
                    ucCH.SampleResponse.Response = responseTXT;
                    if (boxidentification)
                    {
                        ucCH.DeviceLimits = ucCH.SampleResponse.DeviceLimits;
                    }
                }
                catch (Exception e)
                {
                    try { ucCH.SampleResponse.Response = responseTXT; } catch { }
                    STDhelper.clLogging.ErrorHandler("READ", exception: e, message: responseTXT);
                }
                m_Log.Save(ucCH, ucCH.SampleResponse);
                if (opcodeChanged) { return false; }
                if (ucCH.SampleResponse.Response_Empty) { return false; }
                if (ucCH.SampleResponse.OpCode_Changed) { return false; }
                return true;
            }
            return false; 
        }

        public void ReadValueDetails(UC_Channel ucCH, opcode cmd)
        {
            switch (cmd)
            {
                case opcode.G015:
                    if (Get_Sample_FWversion(ucCH.ODBC_EK, ucCH.SampleResponse.BoxMeasValue, out string fwversion))
                    {
                        m_FWversion = fwversion;
                    }
                    break;
                default:
                    break;
            }
        }

        /****************************************************************************************************
         * SerialPort:  Read
         ***************************************************************************************************/
        System.Diagnostics.Stopwatch timeWatch = new System.Diagnostics.Stopwatch();
        private bool Read_SerialPort(UC_COM ucCOM, out string response, int readRepeat = 5, int readDelay = 25, bool stopbyNewLine = true)
        {
            StringBuilder sb = new StringBuilder();
            SerialPort port = ucCOM.Serialport;
            bool closed = false;
            bool NoError = true;
            int count = 0;
            timeWatch.Reset();
            timeWatch.Start();
            var timetowait = readDelay * readRepeat;
            while (!closed && count < readRepeat && timeWatch.ElapsedMilliseconds < 1200)
            //while (!closed && count < readRepeat)
            {
                if (port.IsOpen)
                {
                    try
                    {
                        if (port.BytesToRead > 0)
                        {
                            string resp = port.ReadExisting();
                            resp = resp.Replace("\0", "");
                            sb.Append(resp);
                            if (resp.Contains("\r\n") && stopbyNewLine)
                            {
                                closed = true;
                                break;
                            }
                        }
                        Thread.Sleep(readDelay);
                    }
                    catch (Exception e)
                    {
                        if (!ucCOM.UCChannel.Limits.ErrorDetected)
                        {
                            string eMessage = "ERROR: " + e.Message;
                            ucCOM.ErrorMessageChannel = eMessage;
                            ucCOM.UCChannel.Limits.ErrorMessage = eMessage;
                            m_Log.Save(ucCOM.UCChannel, eMessage);
                            NoError = false;
                        }
                        closed = true;
                    }
                }
                else
                {
                    if (!ucCOM.UCChannel.Limits.ErrorDetected)
                    {
                        string eMessage = "ERROR: Comport is closed";
                        ucCOM.ErrorMessageChannel = eMessage;
                        ucCOM.UCChannel.Limits.ErrorMessage = eMessage;
                        m_Log.Save(ucCOM.UCChannel, eMessage);
                        NoError = false;
                    }
                    closed = true;
                }
                count++;
            }
            if (sb.Length>0)
            {
                response = sb.ToString();
                return NoError;
            }
            else
            {
                response = "";
                return false;
            }
        }

        /****************************************************************************************************
         * Command:  Read Page15 FW version And Parse
         ***************************************************************************************************/
        private static clTDLproperty Page15_FWversion;
        private static clTDLproperty Page15_MaximSN;
        private static clTDLproperty Page15_MaximCRC;
        private static List<clTDLproperty> Page15_Properties;

        public static bool Get_Sample_FWversion(string odbc, string page15HEX, out string fwversion)
        {
            fwversion = "";
            bool error = false;
            if(Page15_FWversion == null) { error = !Get_TDL_FWversion(odbc, out Page15_FWversion); }
            if(Page15_FWversion.data_type == null && !error) { error = !Get_TDL_FWversion(odbc, out Page15_FWversion); }
            if (Page15_FWversion.data_type != null && !error)
            {
                try
                {
                    fwversion = page15HEX.GetValuesFromTEDS_HEX(Page15_FWversion.data_type, Page15_FWversion.start, Page15_FWversion.tol, Page15_FWversion.bit, Page15_FWversion.bit_start);
                }
                catch { }
                return !string.IsNullOrEmpty(fwversion);
            }
            return false;
        }

        public static string Get_PropertyValue(clTDLproperty property, string hex)
        {
            return hex.GetValuesFromTEDS_HEX(property.data_type, property.start, property.tol, property.bit, property.bit_start);
        }

        public static bool Get_Sampel_FWversionPropertie(string odbc, out clTDLproperty fwversion)
        {
            return Get_TDL_FWversion(odbc, out fwversion);
        }

        public bool Get_Sample_FWversion(UC_Channel ucCH, out string fwversion)
        {
            fwversion = "";
            if(SendCMD(ucCH, opcode.G015))
            {
                return Get_Sample_FWversion(ucCH.ODBC_EK, ucCH.SampleResponse.BoxMeasValue, out fwversion);
            }
            return false;
        }


        /****************************************************************************************************
         * Command:  Read Page
         ***************************************************************************************************/

        public bool ReadPage(UC_Channel ucCH, int pageNo)
        {
            string cmd = $"#RDPG {pageNo}";
            if (SendCMD(ucCH, opcode.RDPG))
            {
                return true;
            }
            return false;
        }

        /****************************************************************************************************
         * Command:  Write Page
         ***************************************************************************************************/

        public bool WritePage(UC_Channel ucCH, int pageNo, string hex)
        {
            string cmd = $"#WDPG {pageNo}";
            if (SendCMD(ucCH, opcode.RDPG))
            {
                return true;
            }
            return false;
        }

    }

    public class DeviceResponse
    {
        public DeviceResponse(string opcodeRequest, UC_Channel ucCH, string response = null, bool isDebug = false)
        {
            IsDebug = isDebug;
            OpCode_Request = opcodeRequest.ParseOpcode();
            Channel = ucCH;
            if (response != null)
            {
                Response = response;
            }
        }
        public DeviceResponse(opcode opcodeRequest, UC_Channel ucCH, string response = null, bool boxidentification = false, bool isDebug = false)
        {
            IsDebug = isDebug;
            OpCode_Request = opcodeRequest;
            BoxIdentification = boxidentification;
            Channel = ucCH;
            if (response != null)
            {
                Response = response;
            }
        }

        public bool IsDebug = false;
        public UC_Channel Channel { get; set; }
        public bool BoxIdentification { get; set; }
        public clDeviceLimits DeviceLimits { get; set; }
        public DateTime meas_time_start { get; private set; }
        public double TimeDiff { get { if (meas_time_start.Year > 1) { return (DateTime.Now - meas_time_start).TotalMilliseconds; } return 0; } }
        private opcode _OpCode_Request;
        public opcode OpCode_Request
        {
            get { return _OpCode_Request; }
            set { _OpCode_Request = value; }
        }
        public bool OpCode_Changed
        {
            get
            {
                if(OpCode_Request == opcode.cmdread) { return false; }
                return OpCode_Request.ToString().ToLower() != OpCode_Response.ToString().ToLower();
            }
        }
        public opcode OpCode_Response { get; set; }
        public bool g901_receved { get; set; }

        private string _Response;
        public string Response
        {
            get { return _Response; }
            set
            {
                _Response = value;
                if (!string.IsNullOrEmpty(value))
                { ResponseParser(IsDebug); }
            }
        }
        public string ResponseParsed { get; set; }
        public string ResponseParsedLog { get; set; }
        public bool Response_Empty { get { return string.IsNullOrEmpty(Response); } }
        
        private string _BoxMode_hex;
        public string BoxMode_hex
        {
            get
            {
                if (!string.IsNullOrEmpty(_BoxMode_hex)) { int i = ResponseListCount; }
                return _BoxMode_hex;
            }
            set { _BoxMode_hex = value; }
        }
        public bool BoxMode_Empty { get { return string.IsNullOrEmpty(BoxMode_hex); } }
        public string BoxMode_desc { get { return Get_BoxMode_Desc(BoxMode_hex); } }
        public string BoxErrorCode_hex { get; set; } = "0";
        public bool BoxErrorCode_Empty { get { return string.IsNullOrEmpty(BoxErrorCode_hex); } }
        public string BoxErrorCode_desc { get { return Get_BoxErrorCode_Desc(BoxErrorCode_hex); } }
        public string BoxCalStatus_hex { get; set; }
        public bool BoxCalStatus_Empty { get { return string.IsNullOrEmpty(BoxCalStatus_hex); } }
        public string BoxCalStatus_desc { get { return Get_BoxCalStatus_Desc(BoxCalStatus_hex); } }
        public string BoxMeasValue { get; set; }
        public bool TestError { get; set; }
        public bool TestFinalise { get; set; }


        public int ResponseListCount { get { return (ResponseList != null) ? ResponseList.Count : 0; } }
        public List<DeviceResponseValues> _ResponseList;
        public List<DeviceResponseValues> ResponseList
        {
            get
            {
                if(_ResponseList == null && Response != null)
                {
                    ResponseParser(IsDebug);
                }
                return _ResponseList;
            }
            set { _ResponseList = value; }
        }

        /****************************************************************************************************
         * Response:    
         ***************************************************************************************************/
        public string[] Lines { get; private set; }
        public int LinesCount { get { return (Lines != null) ? Lines.Length : 0; } }

        public void ResponseParser(bool isDebug = false)
        {
            if (!Response_Empty)
            {
                Split_Line(isDebug); 
            }
        }

        private string _lastprogress = "";
        private bool Split_Line(bool isDebug = false)
        {
            Lines = Response.Split(new[] { System.Environment.NewLine }, StringSplitOptions.None);
            if (LinesCount > 0)
            {
                _ResponseList = new List<DeviceResponseValues>();
                foreach (string line in Lines)
                {
                    string l = line.Trim();
                    if (!string.IsNullOrEmpty(l) && l != "\0")
                    {
                        DeviceResponseValues resp = new DeviceResponseValues(OpCode_Request, Channel, l);
                        _ResponseList.Add(resp);
                        if (!isDebug)
                        {
                            try { Insert_DT_Measurement(resp); } catch { }
                            if (_lastprogress != resp.BoxMode_desc)
                            {
                                _lastprogress = resp.BoxMode_desc;
                                if (Set_Progress(resp))
                                {
                                    Channel.Update_DGV();
                                }
                            }
                            ToMain(resp);
                        }
                    }
                }
            }
            return true;
        }
        private void ToMain(DeviceResponseValues resp)
        {
            OpCode_Response = resp.OpCode;
            bool g200 = OpCode_Response == opcode.g200;
            //if (resp.Error) { return; }
            if (OpCode_Response == opcode.S999 || OpCode_Response == opcode.s999)
            {
                //if (BoxIdentification)
                {
                    Get_BoxIdentification(resp);
                }
                return;
            }
            if (!resp.BoxMode_Empty)
            {
                if (!TestError)
                {
                    BoxMode_hex = resp.BoxMode_hex;
                    TestError = resp.TestError;
                    TestFinalise = resp.TestFinalise;
                }
            }
            else
            {
                resp.BoxMode_hex = BoxMode_hex;
            }
            if (!resp.BoxCalStatus_Empty)
            { BoxCalStatus_hex = resp.BoxCalStatus_hex; }
            else
            { resp.BoxCalStatus_hex = BoxCalStatus_hex; }

            if (!string.IsNullOrEmpty(resp.BoxMeasValue))
            { BoxMeasValue = resp.BoxMeasValue; }
            else
            { resp.BoxMeasValue = BoxMeasValue; }
            if (!resp.BoxErrorCode_Empty)
            {
                BoxErrorCode_hex = resp.BoxErrorCode_hex;
            }
            else { resp.BoxErrorCode_hex = BoxErrorCode_hex; }
            if (BoxErrorCode_Empty) { BoxErrorCode_hex = "0"; }
        }

        /****************************************************************************************************
         * Box Values:    
         ***************************************************************************************************/
        private int Dev_Limits_Count = 0;
        private int Dev_limits_Total = 9;
        private void Get_BoxIdentification(DeviceResponseValues resp)
        {
            if (resp.BoxMeasValue == "BoxReset") { return; }
            if (resp.BoxMeasValue.Contains("Messbereich\t")) { return; }
            if (DeviceLimits == null) { DeviceLimits = new clDeviceLimits(); Dev_Limits_Count = 0; }
            if (resp.Response.Contains("DipSwitch"))
            {
                DeviceLimits.DipSwitch = resp.Response.Trim();
                Dev_Limits_Count++;
                return;
            }
            string[] split = resp.Response.Split('\t');
            if (resp.Response.Contains("Betriebsmittel"))
            {
                if (split.Length > 3)
                {
                    string bem = split[0];
                    string hwid = split[2];
                    string hwversion = split[3];
                    DeviceLimits.BeM = bem.Substring(bem.IndexOf(':') + 1).Trim();
                    DeviceLimits.HW_ID = hwid.Substring(hwid.IndexOf(':') + 1).Trim();
                    DeviceLimits.HW_Version = hwversion.Substring(hwversion.IndexOf(':') + 1).Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("CalibrationBox"))
            {
                DeviceLimits.BoxDesc = resp.Response.Trim();
                Dev_Limits_Count++;
                return;
            }
            if (resp.Response.Contains("FW:"))
            {
                if (split.Length > 2)
                {
                    string fw = split[0];
                    string cp = split[2];
                    DeviceLimits.FW_Version = fw.Substring(fw.IndexOf(':') + 1).Trim();
                    DeviceLimits.Compiled = cp.Substring(cp.IndexOf(':') + 1).Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("RawVal"))
            {
                if (split.Length > 6)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    string temp = split[6];
                    DeviceLimits.RawVal = new clDeviceLimitsModes();
                    double.TryParse(low1, out DeviceLimits.RawVal.Low1);
                    double.TryParse(low2, out DeviceLimits.RawVal.Low2);
                    double.TryParse(high1, out DeviceLimits.RawVal.High1);
                    double.TryParse(high2, out DeviceLimits.RawVal.High2);
                    DeviceLimits.RawVal.Unit = unit.Trim();
                    double.TryParse(temp, out DeviceLimits.TempRefVolt);
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("Current"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    DeviceLimits.Current = new clDeviceLimitsModes();
                    double.TryParse(low1, out DeviceLimits.Current.Low1);
                    double.TryParse(low2, out DeviceLimits.Current.Low2);
                    double.TryParse(high1, out DeviceLimits.Current.High1);
                    double.TryParse(high2, out DeviceLimits.Current.High2);
                    DeviceLimits.Current.Unit = unit.Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("ErrorRaw"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    DeviceLimits.RawError = new clDeviceLimitsModes();
                    double.TryParse(low1, out DeviceLimits.RawError.Low1);
                    double.TryParse(low2, out DeviceLimits.RawError.Low2);
                    double.TryParse(high1, out DeviceLimits.RawError.High1);
                    double.TryParse(high2, out DeviceLimits.RawError.High2);
                    DeviceLimits.RawError.Unit = unit.Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("CalError"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    DeviceLimits.CalError = new clDeviceLimitsModes();
                    double.TryParse(low1, out DeviceLimits.CalError.Low1);
                    double.TryParse(low2, out DeviceLimits.CalError.Low2);
                    double.TryParse(high1, out DeviceLimits.CalError.High1);
                    double.TryParse(high2, out DeviceLimits.CalError.High2);
                    DeviceLimits.CalError.Unit = unit.Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            if (resp.Response.Contains("WepError"))
            {
                if (split.Length > 5)
                {
                    string low1 = split[1];
                    string low2 = split[2];
                    string high1 = split[3];
                    string high2 = split[4];
                    string unit = split[5];
                    DeviceLimits.WepError = new clDeviceLimitsModes();
                    double.TryParse(low1, out DeviceLimits.WepError.Low1);
                    double.TryParse(low2, out DeviceLimits.WepError.Low2);
                    double.TryParse(high1, out DeviceLimits.WepError.High1);
                    double.TryParse(high2, out DeviceLimits.WepError.High2);
                    DeviceLimits.WepError.Unit = unit.Trim();
                    Dev_Limits_Count++;
                }
                return;
            }
            BoxIdentification = Dev_Limits_Count != Dev_limits_Total;
        }

        /****************************************************************************************************
         * Measurement:
         ***************************************************************************************************/
        private DataTable _DT_Measurements;
        public DataTable DT_Measurements
        {
            get
            {
                if(_DT_Measurements == null)
                {
                    _DT_Measurements = Init_DT_Measurement();
                }
                return _DT_Measurements;
            }
            private set { _DT_Measurements = value; }
        }

        private void Insert_DT_Measurement(DeviceResponseValues drv)
        {
            if (drv.OpCode == opcode.g901)
            {
                if (!g901_receved) { g901_receved = drv.OpCode == opcode.g901; }
                if (drv.BoxMode_desc.ToLower().Contains("mode"))
                {
                    
                    drv.Limits = DeviceLimits.CheckLimits(drv.BoxMode_hex, drv.BoxMeasValue, drv.MeanValue, drv.StdDeviation, drv.MeasErrorValue);
                    bool limitsFound = drv.Limits != null;
                    if (!limitsFound) { BoxIdentification = false; }
                    try
                    {
                        DataRow row = DT_Measurements.NewRow();
                        row["meas_time_start"] = drv.meas_time_start.ToString("yyyy.MM.dd HH:mm:ss.fff");
                        
                        row["boxmode_hex"] = drv.BoxMode_hex;
                        row["boxmode_desc"] = drv.BoxMode_desc;

                        row["refvalue"] = drv.BoxMeasValue;
                        row["meanvalue"] = drv.MeanValue;
                        row["stddeviation"] = drv.StdDeviation;

                        row["errorvalue"] = drv.MeasErrorValue;
                        if (limitsFound)
                        {
                            row["test_ok"] = drv.Limits.Test_ok;
                            row["refvalue_set"] = drv.Limits.LimitsMode.RawValue;
                            row["refvalue_ok"] = drv.Limits.Value_ok;

                            row["stddeviation_set"] = drv.Limits.LimitsMode.CalError;
                            row["stddeviation_ok"] = drv.Limits.StdDev_ok;


                            row["errorvalue_set"] = drv.Limits.LimitsMode.Current;
                            row["errorvalue_ok"] = drv.Limits.ErrorABS_ok;
                        }
                        DT_Measurements.Rows.Add(row);
                    }
                    catch (Exception e)
                    {
                        STDhelper.clLogging.ErrorHandler("Insert_DT_Measurement", exception: e);

                    }
                }
            }
        }

        /****************************************************************************************************
         * Processes:
         ***************************************************************************************************/
        private DataTable _DT_Progress;
        public DataTable DT_Progress
        {
            get
            {
                if(_DT_Progress == null) {_DT_Progress = _DT_Progress.Init_DT_Progress(); }
                return _DT_Progress;
            }
            set { _DT_Progress = value; }
        }

        private static string ProgHeaderSearcher = ProgHeader.boxmode_hex.ToString();
        private DataRow Set_Values(DataRow row, DeviceResponseValues drv)
        {
            row[ProgHeader.boxmode_hex.ToString()] = drv.BoxMode_hex;
            row[ProgHeader.boxmode_desc.ToString()] = BoxMode[drv.BoxMode_hex];
            row[ProgHeader.meas_time_start.ToString()] = DateNow;
            if (!string.IsNullOrEmpty(drv.BoxMeasValue))
            {
                row[ProgHeader.values.ToString()] = drv.BoxMeasValue;
            }
            if (!string.IsNullOrEmpty(drv.BoxErrorCode_hex))
            {
                row[ProgHeader.boxerror_hex.ToString()] = drv.BoxErrorCode_hex;
                row[ProgHeader.boxerror_desc.ToString()] = BoxErrorCode[drv.BoxErrorCode_hex];
            }
            return row;
        }
        private bool Set_Progress(DeviceResponseValues drv)
        {
            try
            {
                if (!string.IsNullOrEmpty(drv.BoxMode_hex))
                {
                    if (drv.BoxMode_hex == "32") { return false; }
                    int index = -1;
                    DataRow row = DT_Progress.NewRow();
                    DataRow[] rows = DT_Progress.Select($"{ProgHeaderSearcher} = '{drv.BoxMode_hex}'");
                    if (rows.Count() == 0)
                    {
                        DT_Progress.Rows.Add(Set_Values(row, drv));
                        index = DT_Progress.Rows.IndexOf(row);
                        if (index > 0)
                        {
                            try
                            {
                                row = DT_Progress.Rows[index - 1];
                                row[ProgHeader.meas_time_end.ToString()] = DateNow;
                                DateTime t = STDhelper.clTime.ConverDateTime(row[ProgHeader.meas_time_start.ToString()].ToString(), DateFormat);
                                if (t.Year == 1) { t = DateTime.Now.AddSeconds(-2); }
                                double d = (DateTime.Now - t).TotalSeconds;
                                string dur = d.ToString("00.00");
                                row[ProgHeader.duration.ToString()] = dur;
                            }
                            catch(Exception ex) { STDhelper.clLogging.ErrorHandler("Set_Progress", exception:ex); }
                        }
                    }
                    if (!string.IsNullOrEmpty(drv.BoxMeasValue))
                    {
                        row[ProgHeader.values.ToString()] = drv.BoxMeasValue;
                    }
                    if (!string.IsNullOrEmpty(drv.BoxErrorCode_hex))
                    {
                        row[ProgHeader.boxerror_hex.ToString()] = drv.BoxErrorCode_hex;
                        row[ProgHeader.boxerror_desc.ToString()] = BoxErrorCode[drv.BoxErrorCode_hex];
                    }
                    return true;
                }
            }
            catch (Exception e)
            {
                STDhelper.clLogging.ErrorHandler("Set_Progress", exception: e);
            }
            return false;
        }
        public void Set_Progress(string boxmode_hex, string boxmode_desc, string value = null, string errorcode = null)
        {
            string searchValue = boxmode_hex;
            if (!string.IsNullOrEmpty(searchValue))
            {
                int index = -1;
                DataRow row = DT_Progress.NewRow();
                DataRow[] rows = DT_Progress.Select($"{ProgHeaderSearcher} = '{searchValue}'");
                bool newRow = (rows.Count() > 0) ? false : true;
                if (newRow)
                {
                    row[ProgHeader.boxmode_hex.ToString()] = boxmode_hex;
                    row[ProgHeader.boxmode_desc.ToString()] = BoxMode[boxmode_hex];
                    row[ProgHeader.meas_time_start.ToString()] = DateNow;
                    if (!string.IsNullOrEmpty(value))
                    { row[ProgHeader.values.ToString()] = value; }
                    if (!string.IsNullOrEmpty(errorcode))
                    {
                        row[ProgHeader.boxerror_hex.ToString()] = errorcode;
                        row[ProgHeader.boxerror_desc.ToString()] = BoxErrorCode[errorcode];
                    }
                    DT_Progress.Rows.Add(row);
                }
                else if(value != null)
                {
                    index = DT_Progress.Rows.IndexOf(rows[0]);
                    row = DT_Progress.Rows[index];
                    row[ProgHeader.meas_time_end.ToString()] = DateNow;
                    DateTime t = STDhelper.clTime.ConverDateTime(row[ProgHeader.meas_time_start.ToString()].ToString(), DateFormat);
                    if (t.Year == 1) { t = DateTime.Now.AddSeconds(-2); }
                    double d = (DateTime.Now - t).TotalSeconds;
                    string dur = d.ToString("00.00");
                    row[ProgHeader.duration.ToString()] = dur;
                    if (!string.IsNullOrEmpty(value))
                    { row[ProgHeader.values.ToString()] = value; }
                    if (!string.IsNullOrEmpty(errorcode))
                    {
                        row[ProgHeader.boxerror_hex.ToString()] = errorcode;
                        row[ProgHeader.boxerror_desc.ToString()] = BoxErrorCode[errorcode];
                    }
                }
            }
        }
    }

    public class DeviceResponseValues
    {
        public DeviceResponseValues(opcode opcodeRequest, UC_Channel ucCH, string line = null)
        {
            OpCode = opcodeRequest;
            Channel = ucCH;
            if (!string.IsNullOrEmpty(line))
            {
                if (line != "\0")
                { Response = line.Trim(); }
            }
            else { Response = null; }
        }

        public UC_Channel Channel { get; set; }
        public DateTime meas_time_start { get; private set; }
        public string StartDate { get { return $"{meas_time_start}.{meas_time_start.Millisecond}"; } }
        public clDeviceLimitsValues Limits { get; set; }
        public bool Error { get; private set; } = false;
        private string _Response;
        public string Response
        {
            get { return _Response; }
            set
            {
                _Response = value;
                meas_time_start = DateTime.Now;
                if (!string.IsNullOrEmpty(value))
                { ResponseParser(); }
            }
        }
        public string ResponseParsed { get; set; }
        public string ResponseParsedLog { get; set; }
        public bool Response_Empty { get { return Response == null ? true : false; } }
        private string _strOpCode;
        private opcode _OpCode;
        public opcode OpCode
        {
            get
            {
                if(_strOpCode == null)
                {
                    _OpCode = Check_OpCode();
                    _strOpCode = _OpCode.ToString();
                }
                return _OpCode;
            }
            set
            {
                _OpCode = Check_OpCode_ToAnswer(value);
                _strOpCode = _OpCode.ToString();
            }
        }
        public string BoxMode_hex { get; set; }
        public bool BoxMode_Empty { get { return string.IsNullOrEmpty(BoxMode_hex); } }
        public string BoxMode_desc { get { return Get_BoxMode_Desc(); } }
        public string BoxErrorCode_hex { get; set; } = "00";
        public bool BoxErrorCode_Empty { get { return string.IsNullOrEmpty(BoxErrorCode_hex); } }
        public string BoxErrorCode_desc { get { return Get_BoxErrorCode_Desc(); } }
        public string BoxCalStatus_hex { get; set; }
        public bool BoxCalStatus_Empty { get { return string.IsNullOrEmpty(BoxCalStatus_hex); } }
        public bool BoxCalStatus_Error
        {
            get
            {
                if (!BoxErrorCode_Empty)
                {
                    if (BoxErrorCode_hex == "00") { return false; }
                    if (BoxErrorCode_hex == "0") { return false; }
                    if (BoxErrorCode_hex == "2") { return false; }
                    return true;
                }
                return false;
            }
        }
        public string BoxCalStatus_desc { get { return Get_BoxCalStatus_Desc(); } }
        public string BoxMeasValue { get; set; }
        public string MeanValue { get; set; }
        public string StdDeviation { get; set; }
        public string MeasErrorValue { get; set; }
        private bool _TestError = false;
        public bool TestError
        {
            get
            {
                if (!string.IsNullOrEmpty(BoxMode_hex))
                {
                    _TestError = (BoxMode_hex == "17" || BoxMode_hex == "1B") ? true : false;
                    if(!_TestError && !BoxErrorCode_Empty)
                    {
                        _TestError = BoxCalStatus_Error;
                    }
                }
                return _TestError;
            }
            set { _TestError = value; }
        }
        private bool _TestFinalise = false;
        public bool TestFinalise
        {
            get
            {
                if (!string.IsNullOrEmpty(BoxMode_hex))
                { _TestFinalise = (BoxMode_hex == "1C" || BoxMode_hex == "37" || TestError) ? true : false; }
                return _TestFinalise;
            }
            private set { _TestFinalise = value; }
        }

        private string[] _ResponseArray;
        
        public string[] ResponseArray
        {
            get
            {
                if(_ResponseArray == null && !Response_Empty)
                {
                    try
                    { _ResponseArray = Response.Split(';'); }
                    catch
                    { }
                }
                return _ResponseArray;
            }
            private set { _ResponseArray = value; }
        }
        public int ResponseArrayCount { get { return ResponseArray != null ? ResponseArray.Length : 0; } }

        private void ResponseParser()
        {
            string[] Header = new string[0];
            int i = 0;
        again:
            i++;
            if (i > 2)
            { _OpCode = opcode.parser_error; }
            switch (OpCode)
            {
                case opcode.g906:
                    switch (ResponseArrayCount)
                    {
                        case 2:
                            Header = OpcodeHeader_G015;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g015:
                    switch (ResponseArrayCount)
                    {
                        case 2:
                            Header = OpcodeHeader_G015;
                            BoxMeasValue = ResponseArray[1];
                            if (Channel != null)
                            {
                                m_FWversion = clDeviceCom.Get_PropertyValue(Channel.Page15_FWversion, BoxMeasValue);
                                var famCode = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMFamilyCode"], BoxMeasValue);
                                var sn = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMSerialNumber"], BoxMeasValue);
                                var crc = clDeviceCom.Get_PropertyValue(Channel.TDLproperties[15]["MAXIMCRC"], BoxMeasValue);
                                //if (clDeviceCom.Get_Sample_FWversion(Channel.ODBC_EK, BoxMeasValue, out string fwversion))
                                //{
                                //    m_FWversion = fwversion;
                                //}
                            }
                            ResponseParsed = $"opcode:\t{OpCode}\t{BoxMeasValue}";
                            return;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    return;
                case opcode.g100:
                    switch (ResponseArrayCount)
                    {
                        case 3:
                            Header = OpcodeHeader_G100;
                            
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g901:
                    switch (ResponseArrayCount)
                    {
                        case 7:
                            Header = OpcodeHeader_G901;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.g200:
                    switch (ResponseArrayCount)
                    {
                        case 7:
                            Header = OpcodeHeader_G200;
                            break;
                        default:
                            _OpCode = Check_OpCode();
                            goto again;
                    }
                    break;
                case opcode.parser_error:
                    BoxMeasValue = Response;
                    if (Response.Contains("DelP")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    if (Response.Contains("WrtP")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    if (Response.Contains("PDwn")) { ResponseParsed = $"INIT:\t{Response}"; return; }
                    ResponseParsed = $"PARSER_ERROR:\t{Response}";
                    Error = true;
                    return;
                case opcode.s999:
                    BoxMeasValue = Response;
                    ResponseParsed = $"opcode:\t{OpCode}\t{Response}";
                    return;
                case opcode.cmdsend:
                case opcode.state:
                    BoxMeasValue = Response;
                    ResponseParsed = $"{OpCode}:\t{Response}";
                    return;
                case opcode.error:
                    BoxMeasValue = Response;
                    ResponseParsed = Response;
                    return;
                default:
                    if (ResponseArrayCount > 0 && OpCode == opcode.cmdread)
                    {
                        _OpCode = Check_OpCode();
                        goto again;
                    }
                    BoxMeasValue = Response;
                    ResponseParsed = $"opcode:\t{OpCode}\t{Response}";
                    return;
            }
            ResponseParsed = Parse(Header);
        }

        private string Parse(string[] header)
        {
            int i = 0;
            StringBuilder sb = new StringBuilder();
            foreach (string value in ResponseArray)
            {
                try { sb.Append(Parse_Values(header[i], i)); }
                catch { break; }
                i++;
            }
            return sb.ToString().Trim();
        }
        private string Parse_Values(string header, int answerIndex)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{header}:\t");
            switch (header)
            {
                case "opcode":
                    sb.Append($"{OpCode}\t");
                    break;
                case "value":
                    try
                    {
                        BoxMeasValue = ResponseArray[answerIndex];
                        sb.Append($"{BoxMeasValue}\t");
                    } catch { }
                    break;
                case "Mean":
                    try
                    {
                        MeanValue = ResponseArray[answerIndex];
                        sb.Append($"{MeanValue}\t");
                    } catch { }
                    break;
                case "StdDev":
                    try { StdDeviation = ResponseArray[answerIndex]; sb.Append($"{StdDeviation}\t"); } catch { }
                    break;
                case "ErrorABS":
                    try { MeasErrorValue = ResponseArray[answerIndex]; sb.Append($"{MeasErrorValue}\t"); } catch { }
                    break;
                case "BoxMode":
                    try
                    {
                        BoxMode_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxMode_hex}\t{header}_desc:\t{BoxMode_desc}\t");
                    } catch { }
                    break;
                case "BoxErrorCode":
                    try
                    {
                        BoxErrorCode_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxErrorCode_hex}\t{header}_desc:\t{BoxErrorCode_desc}\t");
                    } catch { }
                    break;
                case "CalStatus":
                    try
                    {
                        BoxCalStatus_hex = ResponseArray[answerIndex];
                        sb.Append($"{BoxCalStatus_hex}\t{header}_desc:\t{BoxCalStatus_desc}\t");
                    } catch { }
                    break;
                default:
                    break;
            }
            string response = sb.ToString();
            if (string.IsNullOrEmpty(response)) { return ""; }
            else { return response; }
        }

        private opcode Check_OpCode()
        {
            if (ResponseArrayCount > 0)
            {
                string r = ResponseArray[0].Trim();
                return Check_OpCode_ToAnswer(r);
            }
            return opcode.parser_error;
        }
        private opcode Check_OpCode(string opcode)
        {
            return opcode.ParseOpcode(defaultOpcode: clHandler.opcode.parser_error);
        }
        private opcode Check_OpCode_ToAnswer(string opcode)
        {
            return opcode.ParseOpcode(toLower: true, defaultOpcode: clHandler.opcode.parser_error);
        }
        private opcode Check_OpCode_ToAnswer(opcode opcode)
        {
            return opcode.ToString().ParseOpcode(toLower: true, defaultOpcode: clHandler.opcode.parser_error);
        }

        public string Get_BoxMode_Desc()
        {
            if (!BoxMode_Empty)
            { try { return BoxMode[BoxMode_hex]; } catch { } }
            return "";
        }
        public string Get_BoxErrorCode_Desc()
        {
            if (!BoxErrorCode_Empty)
            { try { return BoxErrorCode[BoxErrorCode_hex]; } catch { } }
            return "";
        }
        public string Get_BoxCalStatus_Desc()
        {
            if (!BoxCalStatus_Empty)
            { try { return CalibrationStatus[BoxCalStatus_hex]; } catch { } }
            return "";
        }

    }
}
