﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using STDhelper;
using static STDhelper.clLogging;
//using static STDhelper.clLogWriter;
using System.IO;
using static ReadCalibox.clHandler;

namespace ReadCalibox
{
    public class clLogging
    {
        public clLogging()
        {
            clLogWriter.FlushAtAge_sec = 1;
            clLogWriter.FlushAtQty = 20;
        }


        public clLogging(UC_Channel ucCH, DeviceResponse response)
        {
            Save(ucCH, response);
        }

        public clLogging(UC_Channel ucCH, string response)
        {
            Save(ucCH, response);
        }

        public void Save(UC_Channel ucCH, DeviceResponse response)
        {
            if (ucCH.LogPathActive && !response.Response_Empty)
            {
                Task.Factory.StartNew(() => 
                {
                    DoWork(new LogValues() { Response = response, Channel = ucCH });
                });
            }
        }

        public void Save(UC_Channel ucCH, string response, opcode opcodeRequest)
        {
            DeviceResponse resp = new DeviceResponse(opcodeRequest, ucCH, response);
            Save(ucCH, resp);
        }
        public void Save(UC_Channel ucCH, gProcMain state, opcode opcodeRequest, string response = null)
        {
            string message = $"{state}";
            if (response != null) { message += $"\t{response}"; }
            DeviceResponse resp = new DeviceResponse(opcodeRequest, ucCH, message);
            Save(ucCH, resp);
        }
        public void Save(UC_Channel ucCH, string response)
        {
            DeviceResponse resp = ucCH.SampleResponse;
            resp.Response = response;
            Save(ucCH, resp);
        }
        /***************************************************************************************
        * BackGroundWorker Write Messages
        ****************************************************************************************/
        public BackgroundWorker BGW_MessageWriter = new BackgroundWorker();
        private void BGW_MessageWriter_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                if (e.Argument != null)
                {
                    DoWork((LogValues)e.Argument);
                }
            }
            catch (Exception a)
            {
                ErrorHandler("BGW_MessageWriter_DoWork Starter", exception: a);
            }
        }
        private void DoWork(LogValues log)
        {
            try
            {
                foreach (DeviceResponseValues drv in log.Response.ResponseList)
                {
                    if (ParseMessage(log, drv, out string message))
                    {
                        SaveLogMeas(log, message, drv);
                    }
                }
            }
            catch(Exception e)
            {
                ErrorHandler("BGW_MessageWriter_DoWork Executible", e);
            }
        }

        /***************************************************************************************
        * Log Message:
        ****************************************************************************************/
        private bool ParseMessage(LogValues log, DeviceResponseValues message, out string messageValues)
        {
            if (string.IsNullOrEmpty(message.ResponseParsed))
            {
                messageValues = message.Response;
            }
            else
            { messageValues = message.ResponseParsed; }
            if (!log.Response.Response_Empty)
            {
                switch (log.Channel.BeM_Selected)
                {
                    case "30259861": //Ozon NG sensor
                        if (messageValues == ".")
                        { return false; }
                        break;
                    case "30014462": //Ozon old sensor
                        if (messageValues == ".")
                        { return false; }
                        else if (messageValues.Length == 3)
                        {
                            if (messageValues.ToLower().Contains("?"))
                            { return false; }
                        }
                        break;
                    default:
                        break;
                }
                messageValues = $"{log.Channel.Channel_No}\t{log.Channel.BeM_Selected}\t{messageValues}";
                log.Response.ResponseParsedLog = messageValues;
                return true;
            }
            return false;
        }

        private void SaveLogMeas(LogValues log, string message, DeviceResponseValues drv)
        {
            SaveLogMeasFile(log, message);
            if (log.Channel.calibrationRunning)
            { SaveLogMeasDB(log, drv); }
        }

        private void SaveLogMeasFile(LogValues log, string message)
        {
            clLogWriter.WriteToLog(message, log.Channel.LogPathMeas);
        }
        private void SaveLogMeasDB(LogValues log, DeviceResponseValues drv)
        {
            try
            {
               bool saveDB = true;
                if (saveDB)
                {
                    clDataBase.Set_Log(log.Channel.ODBC_EK, drv, log.Channel.Limits);
                }
                    
            }
            catch
            {
                ErrorHandler("SaveLogMeas", message: $"ERROR: Directory {log.Channel.LogPathMeas} don't found");
            }
        }

    }
    public class LogValues
    {
        public DeviceResponse Response { get; set; }
        public UC_Channel Channel { get; set; }
    }
}
