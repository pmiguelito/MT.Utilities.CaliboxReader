﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadCalibox
{

    class SerialReaderThread
    {
        //public Thread Thread_Sreader;
        public SerialPort Port;
        private int ReadDelay { get; }
        private bool ReadLine;
        public bool Running = false;
        public bool PortIsOpen { get { return Port.IsOpen; } }
        public void ClosePort()
        {
            Port.Close();
        }

        public SerialReaderThread(SerialPort port, int readDelay, bool readLinie)
        {
            Port = port;

            //if (Thread_Sreader != null) { Thread_Sreader.Abort(); }
            //Thread_Sreader = new Thread(RunMethod);
            //Thread_Sreader.Name = $"Thread_Sreader {Port.PortName}_{Thread_Sreader.ManagedThreadId}";
            //Thread_Sreader.IsBackground = true;
            ReadLine = readLinie;
            ReadDelay = readDelay;
            closed = false;
        }
        //[Obsolete("SerialReaderThread", true)]
        //public void Start()
        //{
        //    closed = false;
        //    //if (Thread_Sreader != null) { Thread_Sreader.Abort(); }
        //    //Thread_Sreader = new Thread(RunMethod);
        //    //Thread_Sreader.Name = $"Thread_Sreader {Port.PortName}_{Thread_Sreader.ManagedThreadId}";
        //    //Thread_Sreader.IsBackground = true;
        //    Port.DataReceived += new SerialDataReceivedEventHandler(Port_DataReceived);
        //    Port.ReadTimeout = 1000;
        //    //Thread_Sreader.Start();
        //}
        public void Start(int timeout)
        {
            closed = false;
            //Init_Timer();
            TimeOut = timeout;
            TimeElapsed = false;
            //Timer_TimeOut.Start();
            Port.DataReceived += new SerialDataReceivedEventHandler(Port_DataReceived);
            Port.ReadTimeout = 1000;
        }
        public void Stop()
        {
            if (Port.IsOpen) { Port.Close(); }
            //try { Thread_Sreader.Abort(); } catch { }
        }

        // note: this event is fired in the background thread
        public event EventHandler<DataEventArgs> DataReceived;

        private bool closed = false;
        private void Close()
        {
            closed = true;
            Stop();
        }

        private void Port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            
            try
            {
                string txt = Port.ReadLine();
                if (!string.IsNullOrEmpty(txt))
                {
                    txt = txt.Replace("\0", "");
                    if (!string.IsNullOrEmpty(txt))
                    {
                        DataReceived(this, new DataEventArgs(Port, txt));
                    }
                }
            }
            catch { }
        }

        //[Obsolete("SerialReaderThread", true)]
        //public void Send(string cmd)
        //{
        //    if (Thread_Sreader.IsAlive) { return; }
        //    if (!Port.IsOpen) { Port.Open(); }
        //    Port.Write(cmd.ToString());
        //    if (!Thread_Sreader.IsAlive) { Start(); }
        //}
        public void Send(string cmd)
        {
            //if (Thread_Sreader.IsAlive) { return; }
            if (!Port.IsOpen) { Port.Open(); }
            Port.Write(cmd.ToString());
            Start(timeout: TimeOut);
            //if (!Thread_Sreader.IsAlive) { Start(); }
        }
        private byte _terminator = 0x4;
        [Obsolete("SerialReaderThread", true)]
        private void RunMethod()
        {
            //TimeOut_Watcher.Start();
            //Port.ReadTimeout = 400;
            //int errorCount = 0;
            //while (!closed && errorCount<3)
            //{
            //    string tString = "";
            //    if (Port.IsOpen)
            //    {
            //        Running = true;
            //        try
            //        {
            //            Thread.Sleep(ReadDelay);
            //            //if (ReadLine)
            //            { tString = Port.ReadLine(); }
            //            //else
            //            //{ tString = Port.ReadExisting(); }
            //            if (tString != "")
            //            {
            //                TimeOut_Watcher.Start();
            //                DataReceived(this, new DataEventArgs(Port, tString));
            //            }
            //        }
            //        catch (Exception e)
            //        {
            //            errorCount++;
            //        }
            //    }
            //    else
            //    { closed = true; }
            //}
            //Running = false;
            //Timer_TimeOut.Stop();
        }

        /****************************************************************************************************
         * TimeOut:     
         ***************************************************************************************************/
        int TimeOut = 2000;
        private System.Windows.Forms.Timer Timer_TimeOut = new System.Windows.Forms.Timer();
        bool TimeElapsed = false;
        void Init_Timer()
        {
            Timer_TimeOut.Interval = 100;
            Timer_TimeOut.Tick += new EventHandler(Timer_Tick);
        }
        System.Diagnostics.Stopwatch TimeOut_Watcher = new System.Diagnostics.Stopwatch();
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (TimeOut_Watcher.ElapsedMilliseconds > TimeOut)
            {
                //Port.Close();
                //TimeElapsed = true;
                //Timer_TimeOut.Stop();
            }
        }
    }

    public class DataEventArgs : EventArgs
    {
        public string Data { get; private set; }
        public SerialPort SerialPort { get; private set ; }
        public DataEventArgs(SerialPort serialPort, string data)
        {
            SerialPort = serialPort;
            Data = data;
        }
        public DataEventArgs(UC_COM port, string data = null)
        {
            SerialPort = port.Serialport;
            Data = data;
        }
    }

}

