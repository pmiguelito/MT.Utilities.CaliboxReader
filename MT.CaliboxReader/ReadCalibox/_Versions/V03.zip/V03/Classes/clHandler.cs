﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TT_Item_Infos;

namespace ReadCalibox
{
    public static class clHandler
    {
        /*******************************************************************************************************************
        * AdminModus:
        '*******************************************************************************************************************/
        public static bool AdminModus = false;

        public static int ProgShowRows = 3;
        public static void Progress_AdminModus(this DataGridView dgv)
        {
            bool colVisible = false;
            if (AdminModus)
            {
                dgv.ScrollBars = ScrollBars.Both;
                dgv.Enabled = true;
                colVisible = true;
                ProgShowRows = 2;
            }
            else
            {
                dgv.ScrollBars = ScrollBars.Vertical;
                dgv.Enabled = true;
                ProgShowRows = 3;
            }
            foreach(DataGridViewColumn dgvc in dgv.Columns)
            {
                dgvc.Visible = colVisible;
            }
            if (!AdminModus)
            {
                dgv.Columns[ProgHeader.boxmode_desc.ToString()].Visible = true;
                dgv.Columns[ProgHeader.boxmode_desc.ToString()].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
        }


        public static string DateFormat = "MM.dd.yyyy HH:mm:ss.fff";
        public static string ToSQLstring(this DateTime dt, bool withMilliSeconds = true)
        {
            if (withMilliSeconds)
            { return dt.ToString("MM.dd.yyyy HH:mm:ss.fff"); }
            else
            { return dt.ToString("MM.dd.yyyy HH:mm:ss"); }
        }
        public static string DateNow { get { return DateTime.Now.ToSQLstring(); } }

        public static string EK_SW_Version;

        public static clLogging m_Log = new clLogging();
        public static UC_TT_Item_Infos m_TT { get; set; }
        public static UC_Betrieb m_UC_Betrieb { get; set; }
        public static UC_Config m_UC_Config { get; set; }
        public static UC_DataRead m_UC_DataRead { get; set; }
        public static UC_DataReader_DGV m_UC_DataRead_DGV { get; set; }
        public static UC_Debug m_UC_Debug { get; set; }

        public static string m_FWversion { get; set; }

        /*******************************************************************************************************************
        * DataTables:
        '*******************************************************************************************************************/
        public enum ProgHeader
        {
            boxmode_hex, boxmode_desc, meas_time_start, meas_time_end,
            duration, values, boxerror_hex, boxerror_desc
        };
        private static string[] _ProgHeaderArray;
        public static string[] ProgHeaderArray
        {
            get
            {
                if(_ProgHeaderArray == null)
                {
                    _ProgHeaderArray = Enum.GetNames(typeof(ProgHeader));
                }
                return _ProgHeaderArray;
            }
        }
        public static DataTable Init_DT_Progress(this DataTable dt, string tablename = "Progress")
        {
            if (dt == null)
            {
                dt = new DataTable() { TableName = tablename };
                foreach (string header in ProgHeaderArray)
                {
                    dt.Columns.Add(header);
                }
            }
            else { dt.Rows.Clear(); }
            return dt;
        }

        public enum MeasHeader
        {
            ID, meas_time_start, test_ok, boxmode_hex, boxmode_desc,
            refvalue, refvalue_set, refvalue_ok,
            meanvalue, meanvalue_set, meanvalue_ok,
            stddeviation, stddeviation_set, stddeviation_ok,
            errorvalue, errorvalue_set, errorvalue_ok
        };
        private static string[] _MeasHeaderArray;
        public static string[] MeasHeaderArray
        {
            get
            {
                if (_MeasHeaderArray == null)
                {
                    _MeasHeaderArray = Enum.GetNames(typeof(MeasHeader));
                }
                return _MeasHeaderArray;
            }
        }
        public static DataTable Init_DT_Measurement()
        {
            DataTable dt = new DataTable("Measurement");
            foreach(string cl in MeasHeaderArray)
            {
                var ch = dt.Columns.Add(cl);
                switch (cl)
                {
                    case "ID":
                        ch.DataType = typeof(long);
                        ch.AutoIncrement = true;
                        ch.AutoIncrementSeed = 0;
                        ch.AutoIncrementStep = 1;
                        break;
                    case "refvalue_set":
                    case "meanvalue_set":
                    case "meanvalue_ok":
                        ch.ColumnMapping = MappingType.Hidden;
                        break;
                    default:
                        break;
                }
            }
            return dt;
        }

        /*******************************************************************************************************************
        * Attents:
        '*******************************************************************************************************************/
        public static string Attents(int count, int total)
        { return $"attents: {count.ToString().PadLeft(2, '0')}/{total.ToString().PadLeft(2, '0')}"; }

        public static string TimeDiff(double timeDiff)
        {
            TimeSpan ts = DateTime.Now.AddSeconds(timeDiff) - DateTime.Now;
            return TimeDiff(ts);
        }
        public static string TimeDiff(TimeSpan timeDiff)
        {
            return $"wait... {timeDiff.ToStringMin()}";
        }
        public static string ToStringMin(this TimeSpan ts)
        {
            return $"{ts.TotalMinutes.ToString("N0").PadLeft(2, '0')}:{Math.Abs(ts.Seconds).ToString("N0").PadLeft(2, '0')} min"; 
        }

        /*******************************************************************************************************************
        * Fonts:
        '*******************************************************************************************************************/
        private static STDhelper.clFonts fonts = new STDhelper.clFonts();

        public static void AllocFont(Control c, float size = 8, FontStyle fontStyle = FontStyle.Regular)
        {
            fonts.AllocFont(c, size, fontStyle);
        }

        /*******************************************************************************************************************
        * Processes:
        *               timStateEngine is placed on "UC_Channel"
        '*******************************************************************************************************************/
        public enum gProcMain
        {
            getReadyForTest,
            BoxStatus,
            BoxReset,
            FWcheck,
            SensorCheck,
            TestFinished,
            StartProcess,
            Calibration,
            Bewertung,
            DBinit,
            wait,
            stop_stateEngine,
            error,
            idle
        };

        public static Dictionary<int, gProcMain> gProgress = new Dictionary<int, gProcMain>()
        {
            {0, gProcMain.StartProcess },
            {1, gProcMain.BoxReset },
            {2, gProcMain.BoxStatus },
            {3, gProcMain.DBinit },
            {4, gProcMain.FWcheck },
            {5, gProcMain.Calibration },
            {6, gProcMain.Bewertung },
        };

        public static int Get_Process(gProcMain proc)
        {
            if (gProgress.ContainsValue(proc))
            {
                foreach(var item in gProgress)
                {
                    if(item.Value == proc)
                    {
                        return item.Key;
                    }
                }
            }
            return -1;
        }
        public static gProcMain Get_Process(int i)
        {
            return gProgress[i];
        }
        public enum CH_State { nothing, inWork, QualityGood, QualityBad, active, notActive, error }

        /*******************************************************************************************************************
        * Box States:
        '*******************************************************************************************************************/
        public static readonly string[] OpcodeHeader_G015 = new string[] { "opcode", "value" };
        public static readonly string[] OpcodeHeader_G100 = new string[] { "opcode", "BoxMode", "CalStatus" };
        public static readonly string[] OpcodeHeader_G901 = new string[] { "opcode", "BoxMode", "CalStatus", "value", "Mean", "StdDev", "ErrorABS" };
        public static readonly string[] OpcodeHeader_G200 = new string[] { "opcode", "BoxMode", "BoxErrorCode", "value", "Mean", "StdDev", "ErrorABS" };



        public static Dictionary<string, string> BoxMode = new Dictionary<string, string>
        {
            {"00","CalibMode_674mV_Low_1"},
            {"01","CalibMode_674mV_Low_2"},
            {"02","CalibMode_674mV_High_1"},
            {"03","CalibMode_674mV_High_2"},
            {"04","CalibMode_500mV_Low_1"},
            {"05","CalibMode_500mV_Low_2"},
            {"06","CalibMode_500mV_High_1"},
            {"07","CalibMode_500mV_High_2"},
            {"08","VerifyMode_674mV_Low_1"},
            {"09","VerifyMode_674mV_Low_2"},
            {"0A","VerifyMode_674mV_High_1"},
            {"0B","VerifyMode_674mV_High_2"},
            {"0C","VerifyMode_500mV_Low_1"},
            {"0D","VerifyMode_500mV_Low_2"},
            {"0E","VerifyMode_500mV_High_1"},
            {"0F","VerifyMode_500mV_High_2"},
            {"10","VerifyTemp"},
            {"33","CalibMode_674CalculationLow"},
            {"34","CalibMode_674CalculationHigh"},
            {"35","CalibMode_500CalculationLow"},
            {"36","CalibMode_500CalculationHigh"},
            {"37","SuccessfullSensorCalibration"},
            {"38","Box_SensorCheckUpol_500"},
            {"39","ShowErrorValues"},
            {"32","Box_Idle"},
            {"11","Box_WritePage_00"},
            {"12","Box_WritePage_01"},
            {"13","Box_WritePage_12"},
            {"14","Box_WritePage_15"},
            {"15","Box_SensorCheckUpol_674"},
            {"16","Box_SensorVerification"},
            {"17","Box_SensorError"},
            {"18","Box_SensorWriteCalData674"},
            {"19","Box_SensorWriteCalData500"},
            {"1A","Box_StartSensorCalibration"},
            {"1B","SensorFail"},
            {"1C","SensorCalibFinalise"},
            {"1D","Box_Calibration"},
            {"1E","WEP_Test"},
            {"1F","WEP_674mV_Low_1"},
            {"20","WEP_674mV_Low_2"},
            {"21","WEP_500mV_Low_1"},
            {"22","WEP_500mV_Low_2"},
            {"23","WEP_674mV_High_1"},
            {"24","WEP_674mV_High_2"},
            {"25","WEP_500mV_High_1"},
            {"26","WEP_500mV_High_2"},
            {"27","WEP_SensorError"},
            {"28","WEPSensorFail"},
            {"29","SensorWepFinalise"},
            {"2A","WEP_SensorCheckUpol"},
            {"2B","WEP_TempCheck"},

            {"S100","CalMode 674/500mV"},
            {"S500","CalMode 500mV"},
            {"S674","CalMode 674mV"},
            {"FWversion","FWversion"}
        };

        public static Dictionary<string, string> BoxErrorCode = new Dictionary<string, string>
        {
            {"0","NotChecked" },
            {"1","ERROR" },
            {"2","PASS" },
            {"00","NoError" },
            {"01","Standard Deviation was out of range (Noisy Signal)" },
            {"02","Calculated Mean was out of range (Offset Error)" },
            {"03","Standard Deviation & Calculated Mean were out of range" },
        };
        public static Dictionary<string, string> CalibrationStatus = new Dictionary<string, string>
        {
            {"00","674mV and 500mV" },
            {"01","647mV" },
            {"02","500mV" }
        };
        public enum opcode
        {
            state, Error, error, 
            G015, G100, G200, G901, G902, G903, G904, G905, G906,
            g015, g100, g200, g901, g902, g903, g904, g905, g906,
            S100, S200, S500, S674, S999,
            s100, s200, s500, s674, s999,
            S901,
            s901,
            cmdread, cmdsend, parser_error,
            RDPG, WRPG,
            rdpg, wrpg
        }

        public static opcode ParseOpcode(this string opcode, bool toLower = false, bool toUpper = false, opcode defaultOpcode = opcode.parser_error)
        {
            if (toLower) { opcode = opcode.ToLower(); }
            if (toUpper) { opcode = opcode.ToUpper(); }
            if (Enum.TryParse(opcode, out opcode result))
            { return result; }
            else
            { return defaultOpcode; }
        }

        public static string Get_BoxMode_Desc(string boxmode_hex)
        {
            if (!string.IsNullOrEmpty(boxmode_hex))
            {
                try { return BoxMode[boxmode_hex]; }
                catch { }
            }
            return "";
        }

        public static string Get_BoxErrorCode_Desc(string BoxErrorCode_hex)
        {
            if (!string.IsNullOrEmpty(BoxErrorCode_hex))
            {
                try { return BoxErrorCode[BoxErrorCode_hex]; }
                catch { }
            }
            return "";
        }
        public static string Get_BoxCalStatus_Desc(string BoxCalStatus_hex)
        {
            if (!string.IsNullOrEmpty(BoxCalStatus_hex))
            {
                try { return CalibrationStatus[BoxCalStatus_hex]; }
                catch { }
            }
            return "";
        }

        /*******************************************************************************************************************
        * Converter:
        '*******************************************************************************************************************/
        public static int ToInt(this string value)
        {
            if(int.TryParse(value, out int result))
            {
                return result;
            }
            return 0;
        }

        public static double ToDouble(this string value)
        {
            if(double.TryParse(value, out double result))
            {
                return result;
            }
            return 0;
        }
    }
}
