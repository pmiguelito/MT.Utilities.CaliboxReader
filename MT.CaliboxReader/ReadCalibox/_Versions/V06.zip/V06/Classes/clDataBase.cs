﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ReadCalibox.clHandler;
using STDhelper;
using static STDhelper.clSTD;
using static STDhelper.clLogging;
using System.Windows.Forms;

namespace ReadCalibox
{
    public static class clDataBase
    {
        /****************************************************************************************************
         * tables:
         ***************************************************************************************************/
        public const string tLimitValEval = "tLimitValEval";
        public const string tTechnology = "tTechnology";
        public const string tCalMeasVal = "tCalMeasVal";
        public const string tCalMeasValTemp = "tCalMeasValTemp";
        public const string tCalLog = "tCalLog";
        public const string tTDL = "tTDL";
        public const string tCalMode = "tCalMode";

        /****************************************************************************************************
         * SQL:     Truncate Tables
         *          use this only for tests
         ***************************************************************************************************/

        public static void Truncate_DB(string odbc)
        {
            /*
            if ((DialogResult)MessageBox.Show($"Truncate ODBC: {odbc}", "DELETE", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                ODBC_TT.ODBC.DB_Truncate(odbc, tCalLog, false);
                ODBC_TT.ODBC.DB_Truncate(odbc, tCalMeasValTemp, false);
                ODBC_TT.ODBC.DB_Truncate(odbc, tCalMeasVal);
            }
            */
        }
        

        /****************************************************************************************************
         * SQL:     Query
         ***************************************************************************************************/

        private static string JoinLimitTechnology = $"SELECT [{tLimitValEval}].[{MN_item}], [{tLimitValEval}].[active] AS item_active, [{tLimitValEval}].[Technology_ID], " +
            $"{tTechnology}.*,{tTechnology}.[desc] AS technology_desc, {tCalMode}.* " +
            $" FROM {tLimitValEval} " +
            $"INNER JOIN {tTechnology} ON {tLimitValEval}.Technology_ID = {tTechnology}.Technology_ID " +
            $"INNER JOIN {tCalMode} ON {tTechnology}.CalMode_ID = {tCalMode}.CalMode_ID ";

        private static string Select_tCalMeasVal = $"SELECT * FROM {tCalMeasVal} ";

        private static string Select_tTDL = $"SELECT * FROM {tTDL} ";

        /****************************************************************************************************
         * SQL:     Checks
         ***************************************************************************************************/

        static bool ODBC_Initial_Found { get { return UC_Betrieb.ODBC_Initial_Found; } }

        public static bool Check_ODBC(string odbc, out string errormessage)
        {
            errormessage = "";
            if (!ODBC_TT.ODBC.GetODBC_status(odbc))
            {
                errormessage = $"ERROR: ODBC {odbc} communication fail";
                return false;
            }
            return true;
        }


        /****************************************************************************************************
         * SQL:     GET Limits
         ***************************************************************************************************/
        public static bool Get_Limits(string odbc, string item, int sensorID, out clItemLimits limits, out string errormessage)
        {
            limits = new clItemLimits();
            errormessage = "";
            if (ODBC_Initial_Found)
            {
                int count = 0;
                if (Check_ODBC(odbc, out errormessage))
                {
                    string where = $" WHERE {tLimitValEval}.{MN_item} = '{item}' AND {tLimitValEval}.active = 1 AND {tTechnology}.active = 1";
                    string sqlQuery = JoinLimitTechnology + where;
                    DataTable dt = new DataTable(DTname_Limits);
                    ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref dt, out count);
                    if (count > 0)
                    {
                        try
                        {
                            limits = dt.Rows[0].ToObjectNewClass<clItemLimits>();
                            limits.DT_Limits = dt;
                            limits.DT_tCalMeasVal = new DataTable(tCalMeasVal);
                            where = $"WHERE {MN_sensorid} = {sensorID} ";
                            sqlQuery = Select_tCalMeasVal + where + $"ORDER BY {MN_pass_no} DESC";
                            ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref limits.DT_tCalMeasVal, out int countPassNo);
                            if (countPassNo > 0)
                            {
                                limits.pass_no = (limits.DT_tCalMeasVal.Rows[0].Field<int>(MN_pass_no) + 1 );
                            }
                            else { limits.pass_no = 1; }
                            if(Get_Duration(odbc, item, out double avg, out errormessage))
                            {
                                if (avg > 0)
                                {
                                    limits.Cal_Duration = avg;
                                }
                            }
                        }
                        catch
                        {
                            errormessage = "ERROR: DB Limits Technology Variable fail";
                            return false;
                        }
                    }
                    else { errormessage = "ERROR: DB Limits Art-Nr nicht gefunden"; }
                }
                return count > 0;
            }
            else { return true; }
        }


        /****************************************************************************************************
         * SQL:     GET Limits
         ***************************************************************************************************/
        private static bool Get_Duration(string odbc, string item, out double AVGduration, out string errormessage)
        {
            AVGduration = 0;
            errormessage = "";
            if (ODBC_Initial_Found)
            {
                int count = 0;
                if (Check_ODBC(odbc, out errormessage))
                {
                    string where = $" WHERE {MN_item} = '{item}' AND {MN_Test_ok} = 1 AND {MN_Duration} > 0";
                    string sqlQuery = $"SELECT AVG({MN_Duration}) FROM {tCalMeasVal} " + where;
                    DataTable dt = new DataTable("Duration");
                    try { ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref dt, out count); }
                    catch { }
                    if (count > 0)
                    {
                        try
                        {
                            AVGduration = dt.Rows[0][0].ToString().ToDouble();

                        }
                        catch
                        {
                            errormessage = "ERROR: DB duration fail";
                            return false;
                        }
                    }
                }
                return count > 0;
            }
            else { return true; }
        }

        /****************************************************************************************************
         * SQL:     GET TDL
         ***************************************************************************************************/
        //public static Dictionary<int, Dictionary<string, clTDLproperty>> TDLproperties = new Dictionary<int, Dictionary<string, clTDLproperty>>();

        public static bool Get_TDL_Page(this int pageNo, string odbc, out List<clTDLproperty> pageProperties)
        {
            string where = $" WHERE page_no = '{pageNo}' ORDER BY page_no, bit_start";
            string sqlQuery = Select_tTDL + where;
            DataTable dt = new DataTable("tTDL");

            ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref dt, out int count);
            pageProperties = new List<clTDLproperty>();
            foreach(DataRow row in dt.Rows)
            {
                pageProperties.Add(row.ToObjectNewClass<clTDLproperty>());
            }
            return count>0;
        }

        public static bool Get_TDLpropertiesFromDB(string odbc, ref Dictionary<int, Dictionary<string, clTDLproperty>> _TDLproperties)
        {
            string where = $"ORDER BY page_no, bit_start";
            string sqlQuery = Select_tTDL + where;
            DataTable dt = new DataTable("tTDL");
            _TDLproperties = new Dictionary<int, Dictionary<string, clTDLproperty>>();
            ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref dt, out int count);
            foreach (DataRow row in dt.Rows)
            {
                clTDLproperty property = row.ToObjectNewClass<clTDLproperty>();
                ADD_TDLpage_Properties(ref _TDLproperties, property);
            }
            return count > 0;
        }


        private static void ADD_TDLpage_Properties(ref Dictionary<int, Dictionary<string, clTDLproperty>> _TDLproperties, clTDLproperty property)
        {
            if (_TDLproperties.ContainsKey(property.page_no))
            {
                if (!_TDLproperties[property.page_no].ContainsKey(property.property_tag))
                {
                    _TDLproperties[property.page_no].Add(property.property_tag, property);
                }
            }
            else
            {
                _TDLproperties.Add(property.page_no, new Dictionary<string, clTDLproperty>());
                _TDLproperties[property.page_no].Add(property.property_tag, property);
            }
            
            
        }

        public static bool Get_TDL_Page(this int pageNo, string odbc, ref Dictionary<int, Dictionary<string, clTDLproperty>> _TDLproperties)
        {
            string where = $" WHERE page_no = '{pageNo}' ORDER BY bit_start";
            string sqlQuery = Select_tTDL + where;
            DataTable dt = new DataTable("tTDL");
            _TDLproperties = new Dictionary<int, Dictionary<string, clTDLproperty>>();
            ODBC_TT.ODBC.DB_Get_Data(odbc, sqlQuery, ref dt, out int count);
            foreach (DataRow row in dt.Rows)
            {
                clTDLproperty prop = row.ToObjectNewClass<clTDLproperty>();
                if (_TDLproperties[prop.page_no][prop.property_tag] == null)
                {
                    _TDLproperties.Add(prop.page_no, new Dictionary<string, clTDLproperty>());
                    _TDLproperties[prop.page_no].Add(prop.property_tag, prop);
                }
            }
            return count > 0;
        }

        public static clTDLproperty GetTDLproperty(int pageNo, string propertyTag, ref Dictionary<int, Dictionary<string, clTDLproperty>> _TDLproperties)
        {
            return _TDLproperties[pageNo][propertyTag];
        }


        private static string SQL_TDL_Page15 = $"{Select_tTDL} WHERE page_no = 15";
        private static string SQL_TDL_FWversion = $"{SQL_TDL_Page15} AND bit_start = 104";
        public static bool Get_TDL_FWversion(string odbc, out clTDLproperty property)
        {
            DataTable dt = new DataTable("tTDL");
            ODBC_TT.ODBC.DB_Get_Data(odbc, SQL_TDL_FWversion, ref dt, out int count);
            if (count > 0)
            { property = dt.Rows[0].ToObjectNewClass<clTDLproperty>(); return true; }
            else { property = new clTDLproperty(); }
            return false;
        }
        public static bool Get_TDL_Page15(string odbc, out List<clTDLproperty> properties)
        {
            DataTable dt = new DataTable("tTDL");
            ODBC_TT.ODBC.DB_Get_Data(odbc, $"{SQL_TDL_Page15} Order by page_no, bit_start", ref dt, out int count);
            properties = new List<clTDLproperty>();
            if (count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    clTDLproperty prop = row.ToObjectNewClass<clTDLproperty>();
                    properties.Add(prop);
                }
            }
            return count > 0;
        }



        /****************************************************************************************************
         * SQL:     DataBase Insert procedure
         ***************************************************************************************************/
        private static bool Set_DB(string odbc, string sqlQuery, bool closeDBconnection=true)
        {
            try
            {
                string connection = ODBC_TT.ODBC.ODBC_Conn_String(odbc, out bool e);
                using (OdbcConnection con = new OdbcConnection(connection))
                {
                    using (OdbcCommand cmd = new OdbcCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = sqlQuery;
                        try
                        {
                            if (con.State == ConnectionState.Closed) { con.Open(); }
                            int count = cmd.ExecuteNonQuery();
                        }
                        catch (Exception aa)
                        {
                            ErrorHandler("Set_DB", exception: aa, message: $"ODBC: {odbc}\r\n{sqlQuery}");
                            return false;
                        }
                        finally
                        { if (con.State == ConnectionState.Open) { con.Close(); } }
                        cmd.Dispose();
                    }
                    con.Dispose();
                }
            }
            catch
            { return false; }
            return true;
        }

        /****************************************************************************************************
         * SQL:     Insert MeasVal
         ***************************************************************************************************/

        public static void MeasValTemp_Insert(clItemLimits limits, DataTable dt)
        {
            DataTable dts = new DataTable();
            int procOrder = 1;
            DateTime meas_time_start = DateTime.Now;
            DateTime meas_time_end = DateTime.Now;
            StringBuilder sbHeader;
            StringBuilder sbValues;
            int RowsCount = dt.Rows.Count;
            int i = 0;
            foreach (DataRow row in dt.Rows)
            {
                sbHeader = new StringBuilder();
                sbValues = new StringBuilder();
                sbHeader.Append($"[{MN_sensorid}], [{MN_pass_no}], [{MN_ProcOrder}], [{MN_Channelno}]");
                sbValues.Append($"{limits.sensor_id}, {limits.pass_no}, '{procOrder}', {limits.channel_no}");
                foreach(DataColumn item in dt.Columns)
                {
                    DB_InserValue(ref sbHeader, ref sbValues,item.ColumnName, row, true);
                }
                //DB_InserValue(ref sbHeader, ref sbValues, MN_BoxMode_HEX, row, true);
                //DB_InserValue(ref sbHeader, ref sbValues, MN_BoxMode_Desc, row, true);
                //DB_InserValue(ref sbHeader, ref sbValues, MN_meas_time_start, row, true);
                //DB_InserValue(ref sbHeader, ref sbValues, MN_meas_time_end, row, true);
                //DB_InserValue(ref sbHeader, ref sbValues, MN_Duration, row, false);
                //DB_InserValue(ref sbHeader, ref sbValues, MN_Values, row, true);
                //string boxerror_hex = DB_InserValue(ref sbHeader, ref sbValues, MN_BoxErrorCode_HEX, row, true);
                bool test_ok = false;
                switch (row[MN_BoxErrorCode_HEX])
                {
                    case "0":
                    case "00":
                    case "2":
                        test_ok = true;
                        break;
                    default:
                        break;
                }
                //DB_InserValue(ref sbHeader, ref sbValues, MN_BoxErrorCode_Desc, row, true);
                sbHeader.Append($", [{MN_Test_ok}]"); sbValues.Append($", '{test_ok}'");
                string sqlQuery = $"INSERT INTO {tCalMeasValTemp} ({sbHeader}) VALUES ({sbValues}); ";
                i++;
                if(!Set_DB(limits.ODBC_EK, sqlQuery, i==RowsCount))
                {
                    //break;
                }
                procOrder++;
            }
        }
        
        private static string DB_InserValue(ref StringBuilder sbHEADER, ref StringBuilder sbValue, string header, DataRow row, bool dbIsString = true)
        {
            string value = "";
            try
            {
                value = row[header].ToString();
                return DB_InserValue(ref sbHEADER, ref sbValue, header, value, dbIsString);
            }
            catch
            {

            }
            return value;
        }

        private static string DB_InserValue(ref StringBuilder sbHEADER, ref StringBuilder sbValue, string header, string value, bool dbIsString = true)
        {
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    sbHEADER.Append($", [{header}]");
                    switch (header)
                    {
                        case MN_Values:
                             int i = value.IndexOf(MN_I_set);
                            if (i > 0) 
                            {
                                value = value.Substring(i);
                            }
                            break;
                        default:
                            break;
                    }
                    if (dbIsString)
                    {
                        sbValue.Append($", '{value}'");
                    }
                    else
                    {
                        sbValue.Append($", {value}");
                    }
                }
            }
            catch
            {

            }
            return value;
        }


        private static string SQL_tMeasVal_Header_Insert_Init = $"INSERT INTO {tCalMeasVal} " +
            $"([{MN_sensorid}], [{MN_pass_no}], [Technology_ID], [ProductionType_ID], [{MN_item}], [{MN_pdno}], [{MN_Test_ok}], [{MN_meas_time_start}], " +
            $"[User_ID], [{MN_EK_SWversion}], [CalMode_ID], [{MN_Channelno}]," +
            $"[{MN_Sample_FWversion}], [{MN_Device_FWversion}])" ;
        public static bool MeasVal_Insert_Init(clItemLimits limits)
        {
            string InsertValues = $"{limits.sensor_id}, '{limits.pass_no}', {limits.Technology_ID}, {limits.ProductionType_ID}, " +
                $"'{limits.item}','{limits.pdno}', '{limits.test_ok}'," +
                $"'{limits.meas_time_start.ToSQLstring()}', {limits.User_ID}, '{limits.EK_SW_Version}', {limits.CalMode_ID}, { limits.channel_no}, '0' ";
            if(limits.DeviceLimits == null)
            {
                InsertValues += $", '','' ";
            }
            else { InsertValues += $", '{limits.DeviceLimits.FW_Version}' "; }
            string sqlQuery = $"{SQL_tMeasVal_Header_Insert_Init} Values({InsertValues});";
            return Set_DB(limits.ODBC_EK, sqlQuery);
        }

        public static bool MeasVal_Update(clItemLimits limits)
        {
            limits.meas_time_end = DateTime.Now;
            string where = $"WHERE sensor_id = {limits.sensor_id} AND {MN_pass_no} = {limits.pass_no}";
            StringBuilder sb = new StringBuilder();
            sb.Append($"UPDATE {tCalMeasVal} SET ");
            sb.Append($"{MN_Test_ok} = '{limits.test_ok}'");
            sb.Append($", {MN_meas_time_end} = '{limits.meas_time_end.ToSQLstring()}'");
            if (!string.IsNullOrEmpty(limits.sample_FW_Version_value)) { sb.Append($", {MN_Sample_FWversion} = '{limits.sample_FW_Version_value}'"); }
            sb.Append($", {MN_Sample_FWversion_state} = '{limits.sample_FW_Version_state}'");
            sb.Append($", {MN_Duration} = {limits.meas_time_duration.TotalSeconds}");
            sb.Append($", error_no = '{limits.error_no}'");
            string sqlQuery = $"{sb} {where}; ";
            if(!Set_DB(limits.ODBC_EK, sqlQuery))
            {
                ErrorHandler("MeasVal_Update", message: sqlQuery);
                return false;
            }
            else { return true; }
        }

        /****************************************************************************************************
         * SQL:     Insert Log Values
         ***************************************************************************************************/
        public static void Set_Log(string odbc, DeviceResponseValues drv, clItemLimits limits)
        {
            if (drv.OpCode == clHandler.opcode.g901) 
            {
                StringBuilder sbHeader = new StringBuilder();
                StringBuilder sbValues = new StringBuilder();
                sbHeader.Append($"{MN_sensorid}, {MN_pass_no}, {MN_ProcOrder}, {MN_Channelno}");
                sbValues.Append($"{limits.sensor_id}, {limits.pass_no}, '{limits.procCounter}', {limits.channel_no}");
                DB_InserValue(ref sbHeader, ref sbValues, MN_BoxMode_HEX, drv.BoxMode_hex, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_BoxMode_Desc, drv.BoxMode_desc, true);
                if (drv.meas_time_start != null)
                {
                    if (drv.meas_time_start.Year > 1)
                    { 
                        DB_InserValue(ref sbHeader, ref sbValues, MN_meas_time_start, drv.meas_time_start.ToSQLstring(), true);
                    }
                }
                DB_InserValue(ref sbHeader, ref sbValues, MN_meas_time_end, DateTime.Now.ToSQLstring(), true);
                
                if (limits.Cal_Stopwatch.Elapsed.TotalMilliseconds > 0) { sbHeader.Append(", "+ MN_Duration); sbValues.Append($", '{limits.Cal_Stopwatch.Elapsed.TotalMilliseconds}'"); }
                DB_InserValue(ref sbHeader, ref sbValues, MN_I_set, drv.I_Set, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_I_AVG, drv.I_AVG, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_I_StdDev, drv.I_StdDev, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_I_Error, drv.I_Error, true);

                DB_InserValue(ref sbHeader, ref sbValues, MN_Temp_set, drv.Temp_Set, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_Temp_AVG, drv.Temp_AVG, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_Temp_StdDev, drv.Temp_StdDev, true);
                DB_InserValue(ref sbHeader, ref sbValues, MN_Temp_Error, drv.Temp_Error, true);

                //if (drv.BoxErrorCode_hex != null) { InsertHeader.Append(", boxerrorcode_hex"); InsertValues.Append($", '{drv.BoxErrorCode_hex}'"); }
                string boxerror_hex = DB_InserValue(ref sbHeader, ref sbValues, MN_BoxErrorCode_HEX, drv.BoxErrorCode_hex, true);
                bool test_ok = false;
                switch (boxerror_hex)
                {
                    case "0":
                    case "00":
                    case "2":
                        test_ok = true;
                        break;
                    default:
                        break;
                }
                DB_InserValue(ref sbHeader, ref sbValues, MN_BoxErrorCode_Desc, drv.BoxErrorCode_desc, true);
                sbHeader.Append(", "+ MN_Test_ok); sbValues.Append($", '{test_ok}'");
                string sqlQuery = $"INSERT INTO {tCalLog} ({sbHeader}) VALUES ({sbValues}); ";
                Set_DB(odbc, sqlQuery, false);
            }
        }
    }
}
