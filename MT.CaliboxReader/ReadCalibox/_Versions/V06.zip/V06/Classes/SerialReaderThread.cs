﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ReadCalibox.clHandler;

namespace ReadCalibox
{

    class SerialReaderThread
    {
        public UC_Channel Channel;
        public SerialPort Port;
        public bool Running = false;
        public bool PortIsOpen { get { return Port.IsOpen; } }

        public SerialReaderThread(UC_Channel channel)
        {
            Channel = channel;
            Port = channel.ucCOM.Serialport;
            Port.DataReceived += new SerialDataReceivedEventHandler(Port_DataReceived);
        }

        public SerialReaderThread(SerialPort port)
        {
            Port = port;
            Port.DataReceived += new SerialDataReceivedEventHandler(Port_DataReceived);
        }


        /****************************************************************************************************
        ** Events:
        ****************************************************************************************************/
        public event EventHandler<DataEventArgs> DataReceived;
        private void OnDataReceived(DataEventArgs e)
        {
            var handler = DataReceived;
            handler?.Invoke(this, e);
        }
        private void Port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string txt = Port.ReadLine();
                if (!string.IsNullOrEmpty(txt))
                {
                    txt = txt.Replace("\0", "");
                    if (!string.IsNullOrEmpty(txt))
                    {
                        if (Channel != null)
                        {
                            OnDataReceived(new DataEventArgs(Channel, CMD_send, txt));
                            //DataReceived(this, new DataEventArgs(Channel, CMD_send, txt));
                        }
                        else
                        {
                            OnDataReceived(new DataEventArgs(Port, CMD_send, txt));
                            //DataReceived(this, new DataEventArgs(Port, CMD_send, txt));
                        }
                    }
                }
            }
            catch(Exception ex) 
            {

            }
        }

        /****************************************************************************************************
        ** Send:
        ****************************************************************************************************/
        public string CMD_send { get; set; }
        public void Send(string cmd)
        {
            if (!Port.IsOpen) { Port.Open(); }
            CMD_send = cmd;
            Port.Write(cmd);
        }

        public void Send(opcode cmd)
        {
            if (!Port.IsOpen) { Port.Open(); }
            Send(cmd.ToString());
        }



        /****************************************************************************************************
        ** Stop:
        ****************************************************************************************************/
        public void Stop()
        {
            if (Port.IsOpen) { Port.Close(); }
        }
        
    }

    public class DataEventArgs : EventArgs
    {
        public string CMD_send { get; private set; }
        public string Data { get; private set; }
        public SerialPort SerialPort { get; private set ; }
        public UC_Channel Channel { get; private set; }
        public DataEventArgs(SerialPort serialPort, string cmd, string data)
        {
            SerialPort = serialPort;
            Data = data;
            CMD_send = cmd;
        }
        public DataEventArgs(UC_Channel channel, string cmd, string data)
        {
            Channel = channel;
            SerialPort = channel.ucCOM.Serialport;
            Data = data;
            CMD_send = cmd;
        }
    }

}

