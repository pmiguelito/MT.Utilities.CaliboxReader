﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadCalibox
{
    public class clDeviceLimits
    {
        public struct StrucBoxIdendificationState
        {
            public bool DipSwitch;
            public bool Betriebsmittel;
            public bool CalibrationBox;
            public bool FW;
            public bool RawVal;
            public bool Current;
            public bool RawError;
            public bool CalError;
            public bool WepError;
            public bool StdDev;

            public bool State()
            {
                if (!DipSwitch) { return false; }
                if (!Betriebsmittel) { return false; }
                if (!CalibrationBox) { return false; }
                if (!FW) { return false; }
                if (!RawVal) { return false; }
                if (!Current) { return false; }
                if (!RawError) { return false; }
                if (!CalError) { return false; }
                //if (!WepError) { return false; }
                return true;
            }
        }

        public StrucBoxIdendificationState BoxIdentification_State = new StrucBoxIdendificationState();

        /**************************************************************************************
       ' Limits:   CaliBox HEADER
       '**************************************************************************************/
        public string BeM { get; set; }
        public string BeM_BoxNr { get; set; }
        public string HW_ID { get; set; }
        public string HW_Version { get; set; }
        public string FW_Version { get; set; }
        public string Compiled { get; set; }

        public string DipSwitch { get; set; }
        public string BoxDesc { get; set; }

        /**************************************************************************************
       ' Limits:    CaliBox checksum
       '            
       '**************************************************************************************/
       public string CS10calc { get; set; }
        public string CS10EEprom { get; set; }

        public string CS31calc { get; set; }
        public string CS31EEprom { get; set; }

        public bool CS_ok 
        {
            get
            {
                return CS10calc == CS10EEprom && CS31calc == CS31EEprom;
            }
        }

        public string BoxConsistent { get; set; }

        /**************************************************************************************
       ' Limits:    CaliBox
       '            Temperature
       '**************************************************************************************/
        public double TempRefVoltTemp;
        public double TempRefVolt;
        public double TempRefVolt2Temp;
        public double TempRefVolt2;
        public double TempRefVolt3Temp;
        public double TempRefVolt3;
        public double TempErr;
        public double TempErrTemp;

        /**************************************************************************************
       ' Limits:    CaliBox
       '            Polarization
       '**************************************************************************************/
        public double UpolError;
        public double UpolErrorValue;

        /**************************************************************************************
       ' Limits:    Messbereiche
       '            
       '**************************************************************************************/
        public clDeviceLimitsModes RawVal { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes Current { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes RawErrorCalibration { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes RawErrorVerification { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes CalError { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes WepError { get; set; } = new clDeviceLimitsModes();
        public clDeviceLimitsModes StdDev { get; set; } = new clDeviceLimitsModes();

        private clDeviceLimtsModesStates _LOW1calib;
        public clDeviceLimtsModesStates LOW1calib
        {
            get
            {
                if (_LOW1calib == null)
                {
                    _LOW1calib = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low1,
                        Current = Current.Low1,
                        RawError = RawErrorCalibration.Low1,
                        CalError = CalError.Low1,
                        WepError = WepError.Low1,
                        StdDev = StdDev.Low1
                    };
                }
                return _LOW1calib;
            }
        }

        private clDeviceLimtsModesStates _LOW1verif;
        public clDeviceLimtsModesStates LOW1verif
        {
            get
            {
                if (_LOW1verif == null)
                {
                    _LOW1verif = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low1,
                        Current = Current.Low1,
                        RawError = RawErrorVerification.Low1,
                        CalError = CalError.Low1,
                        WepError = WepError.Low1,
                        StdDev = StdDev.Low1
                    };
                }
                return _LOW1verif;
            }
        }
        private clDeviceLimtsModesStates _LOW2calib;
        public clDeviceLimtsModesStates LOW2calib
        {
            get
            {
                if (_LOW2calib == null)
                {
                    _LOW2calib = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low2,
                        Current = Current.Low2,
                        RawError = RawErrorCalibration.Low2,
                        CalError = CalError.Low2,
                        WepError = WepError.Low2,
                        StdDev = StdDev.Low2
                    };
                }
                return _LOW2calib;
            }
        }
        private clDeviceLimtsModesStates _LOW2verif;
        public clDeviceLimtsModesStates LOW2verif
        {
            get
            {
                if (_LOW2verif == null)
                {
                    _LOW2verif = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.Low2,
                        Current = Current.Low2,
                        RawError = RawErrorVerification.Low2,
                        CalError = CalError.Low2,
                        WepError = WepError.Low2,
                        StdDev = StdDev.Low2
                    };
                }
                return _LOW2verif;
            }
        }
        private clDeviceLimtsModesStates _HIGH1calib;
        public clDeviceLimtsModesStates HIGH1calib
        {
            get
            {
                if (_HIGH1calib == null)
                {
                    _HIGH1calib = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High1,
                        Current = Current.High1,
                        RawError = RawErrorCalibration.High1,
                        CalError = CalError.High1,
                        WepError = WepError.High1,
                        StdDev = StdDev.High1
                    };
                }
                return _HIGH1calib;
            }
        }
        private clDeviceLimtsModesStates _HIGH1verif;
        public clDeviceLimtsModesStates HIGH1verif
        {
            get
            {
                if (_HIGH1verif == null)
                {
                    _HIGH1verif = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High1,
                        Current = Current.High1,
                        RawError = RawErrorVerification.High1,
                        CalError = CalError.High1,
                        WepError = WepError.High1,
                        StdDev = StdDev.High1
                    };
                }
                return _HIGH1verif;
            }
        }
        private clDeviceLimtsModesStates _HIGH2calib;
        public clDeviceLimtsModesStates HIGH2calib
        {
            get
            {
                if (_HIGH2calib == null)
                {
                    _HIGH2calib = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High2,
                        Current = Current.High2,
                        RawError = RawErrorCalibration.High2,
                        CalError = CalError.High2,
                        WepError = WepError.High2,
                        StdDev = StdDev.High2
                    };
                }
                return _HIGH2calib;
            }
        }
        private clDeviceLimtsModesStates _HIGH2verif;
        public clDeviceLimtsModesStates HIGH2verif
        {
            get
            {
                if (_HIGH2verif == null)
                {
                    _HIGH2verif = new clDeviceLimtsModesStates()
                    {
                        RawValue = RawVal.High2,
                        Current = Current.High2,
                        RawError = RawErrorVerification.High2,
                        CalError = CalError.High2,
                        WepError = WepError.High2,
                        StdDev = StdDev.High2
                    };
                }
                return _HIGH2verif;
            }
        }
        public clDeviceLimitsResults CheckLimits(string boxmode, string value, string mean, string stdDev, string errorABS)
        {
            clDeviceLimitsResults results = new clDeviceLimitsResults();
            results.Values = new clDeviceLimitsValues()
            {
                BoxMode = boxmode,
                RefValue = value.ToDouble(),
                MeanValue = mean.ToDouble(),
                StdDev = stdDev.ToDouble(),
                ErrorABS = errorABS.ToDouble()
            };
            results.LimitsMode = Get_LimitsMode(boxmode);
            results.Rating = new clDeviceLimitsValuesRating() { LimitsModes = results.LimitsMode, Results = results.Values };
            return results;
        }
        public clDeviceLimtsModesStates Get_LimitsMode(string boxmode)
        {
            try
            {
                switch (boxmode)
                {
                    case "00":
                    case "04":
                        /*Calibration*/
                        return LOW1calib;
                    case "08":
                    case "0C":
                        /*Verification*/
                        return LOW1verif;
                    case "01":
                    case "05":
                        return LOW2calib;
                    case "09":
                    case "0D":
                        return LOW2verif;
                    case "02":
                    case "06":
                        return HIGH1calib;
                    case "0A":
                    case "0E":
                        return HIGH1verif;
                    case "03":
                    case "07":
                        return HIGH2calib;
                    case "0B":
                    case "0F":
                        return HIGH2verif;
                    default:
                        break;
                }
            }
            catch { }
            return new clDeviceLimtsModesStates();
        }
    }
    public class clDeviceLimitsModes
    {
        public double Low1;
        public double Low2;
        public double High1;
        public double High2;
        public string Unit;
    }
    public class clDeviceLimtsModesStates
    {
        public double RawValue;
        public double Current;
        public double RawError;
        public double CalError;
        public double WepError;
        public double StdDev;
    }


    public class clDeviceLimitsResults
    {
        public clDeviceLimitsValues Values;
        public clDeviceLimitsValuesRating Rating;
        public clDeviceLimtsModesStates LimitsMode;
    }
    public class clDeviceLimitsValues
    {
        //public clDeviceLimtsModesStates LimitsMode;// = new clDeviceLimtsModesStates();
        public double Count;
        public string BoxMode;
        public string BoxModeDesc
        {
            get
            {
                if (BoxMode == null) { return null; }
                return clHandler.BoxMode[BoxMode];
            }
        }
        public double RefValue;
        public double MeanValue;
        public double StdDev;
        public double ErrorABS;

        //public bool Test_ok { get { return Value_ok && StdDev_ok && ErrorABS_ok; } }
        //public bool Value_ok
        //{
        //    get
        //    {
        //        if(LimitsMode != null)
        //        {
        //            return MeanValue <= LimitsMode.RawValue;
        //        }
        //        return false;
        //    }
        //}
        //public bool StdDev_ok
        //{
        //    get
        //    {
        //        if (LimitsMode != null)
        //        {
        //            return StdDev <= LimitsMode.CalError;
        //        }
        //        return false;
        //    }
        //}
        //public bool ErrorABS_ok
        //{
        //    get
        //    {
        //        if (LimitsMode != null)
        //        {
        //            return ErrorABS <= LimitsMode.Current;
        //        }
        //        return false;
        //    }
        //}
    }
    public class clDeviceLimitsValuesRating
    {
        public clDeviceLimitsValues Results;
        public clDeviceLimtsModesStates LimitsModes;
        public bool Test_ok { get { return Value_ok && StdDev_ok && ErrorABS_ok; } }
        public bool Value_ok
        {
            get
            {
                if (LimitsModes != null)
                {
                    return Results.RefValue <= LimitsModes.RawValue;
                }
                return false;
            }
        }
        public bool StdDev_ok
        {
            get
            {
                if (LimitsModes != null)
                {
                    return Results.StdDev <= LimitsModes.StdDev;
                }
                return false;
            }
        }
        public bool ErrorABS_ok
        {
            get
            {
                if (LimitsModes != null)
                {
                    return Results.ErrorABS <= LimitsModes.RawError;
                }
                return false;
            }
        }
    }
}
