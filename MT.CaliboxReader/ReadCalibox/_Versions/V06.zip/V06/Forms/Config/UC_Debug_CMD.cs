﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using static ReadCalibox.clConfig;
using static ReadCalibox.clLogging;
using static ReadCalibox.clDeviceCom;
using static ReadCalibox.clHandler;
using System.Diagnostics;
using System.Net.Http.Headers;

namespace ReadCalibox
{
    public partial class UC_Debug_CMD : UserControl
    {
        /***************************************************************************************
        * Constructor:  Instance to load from other elements
        ****************************************************************************************/
        private static UC_Debug_CMD _Instance;
        public static UC_Debug_CMD Instance
        {
            get
            {
                if (_Instance == null)
                { _Instance = new UC_Debug_CMD(); }
                return _Instance;
            }
        }

        /***************************************************************************************
        * Constructor:
        ****************************************************************************************/
        public UC_Debug_CMD()
        {
            InitializeComponent();
        }

        private void UC_Debug_Load(object sender, EventArgs e)
        {
            Init();
            _Instance = this;
        }

        /***************************************************************************************
        * Initialization:
        ****************************************************************************************/
        private void Init()
        {
            PanelLimits.Height = 0;
            CoB_BaudRate.SelectedIndexChanged -= CoB_BaudRate_SelectedIndexChanged;
            CoB_COM.SelectedIndexChanged -= CoB_COM_SelectedIndexChanged;
            Init_CoB_Port();
            Init_CoB_BaudRate();
            Init_CoB_CMD();
            Init_Port();
            Init_CoB_CMDp();
            CoB_BaudRate.SelectedIndexChanged += CoB_BaudRate_SelectedIndexChanged;
            CoB_COM.SelectedIndexChanged += CoB_COM_SelectedIndexChanged;
        }
        private void Init_CoB_Port()
        {
            var list = SerialPortList.ToList();
            list.Add("...Load");
            CoB_COM.DataSource = list;
            CoB_COM.SelectedIndex = 0;
        }

        int BaudDefault = 19200;
        private void Init_CoB_BaudRate()
        {
            CoB_BaudRate.DataSource = BaudRateList;
            CoB_BaudRate.Text = BaudDefault.ToString();
        }
        private void Init_CoB_CMD()
        {
            var ar = System.Enum.GetNames(typeof(opcode));
            List<string> list = new List<string>();
            list.Add("#RDPG");
            list.Add("#RDBX");
            foreach (var item in ar)
            {
                if (item.StartsWith("S") || item.StartsWith("G"))
                {
                    list.Add(item);
                }
            }
            
            list = list.OrderBy(x => x).ToList();
            CoB_CMD.DataSource = list;
        }

        private void Init_CoB_CMDp()
        {
            Init_Timer();
            var ar = System.Enum.GetNames(typeof(CMDs));
            CobCMDp.DataSource = ar;
        }

        private void Init_Port()
        {
            Close_COMport();
            if (string.IsNullOrEmpty(CoB_BaudRate.Text))
            {
                CoB_BaudRate.Text = BaudDefault.ToString();
            }
            int baud = BaudDefault;
            try { baud = Convert.ToInt32(CoB_BaudRate.Text); } catch { CoB_BaudRate.Text = baud.ToString(); }
            port = SerialPort_Init(CoB_COM.Text, baud);
            //port.ReadTimeout = 200;
            //port.WriteTimeout = 200;
            Init_DatReader();
            //ThreadDR.Port = port;
        }

        /***************************************************************************************
        * SerialPort:
        ****************************************************************************************/
        public SerialPort port = new SerialPort();

        public void Close_COMport()
        {
            if (port.IsOpen) 
            { port.Close(); }
        }

        /***************************************************************************************
        * PortReader:    SerialPort Read
        ****************************************************************************************/
        SerialReaderThread _ThreadDR;
        SerialReaderThread ThreadDR
        {
            get
            {
                if(_ThreadDR == null)
                { _ThreadDR = Init_DatReader(); }
                return _ThreadDR;
            }
        }
        SerialReaderThread Init_DatReader()
        {
            SerialReaderThread SRT = new SerialReaderThread(port);
            SRT.DataReceived += ThreadDataReceived;
            return SRT;
        }

        char[] LineSpliter = new char[] { '\n', '\r' };
        void ThreadDataReceived(object s, EventArgs e)
        {
            var a = (DataEventArgs)e;
            string response = a.Data;
            if (response.Length < 1) { return; }
            if (CkB_Parse.Checked)
            {
                Message(response);
                return;
            }
            ParseMessage(response);
        }

        DeviceResponse DR = new DeviceResponse(null, isDebug: true);
        private void ParseMessage(string message)
        {
            message = message.Replace("*", "");
            if (message.Length < 1) { return; }
            StringBuilder sb = new StringBuilder();
            int splitter = -1;
            if (message.Contains("\n"))
            {
                splitter = 0;
            }
            else if (message.Contains("\r"))
            {
                splitter = 1;
            }

            if (splitter > -1 && message.Length > 0)
            {
                string[] resp = message.Split(LineSpliter[splitter]);
                foreach (var item in resp)
                {
                    if (item.Length > 0)
                    {
                        CMD = "";
                        var response = DR.Read(CMD, null, item, isDebug: true);
                        foreach (var drv in response)
                        {
                            sb.Append(drv.ResponseParsed.Replace(":\t", ": ").Replace("\t", "; "));
                        }
                    }
                }
                Message(sb.ToString());
            }
        }

        private void Message(string message)
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)delegate { Message(message); });
                return;
            }
            try
            {
                Tb_Info.Text += $"{watch.Elapsed.TotalSeconds.ToString("0.000")}\t{message}{Environment.NewLine}";
                Tb_Info.SelectionStart = Tb_Info.Text.Length;
                Tb_Info.ScrollToCaret();
                Tb_Info.Refresh();
            }
            catch { }
        }
        System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();
        private void CMD_Send(string cmd)
        {
            try
            {
                watch.Reset();
                watch.Start();
                CMD = cmd;
                if (cmd.Contains("S999")){ G001sended = false; }
                Message($"cmd send: {CMD}");
                _ThreadDR = Init_DatReader();
                ThreadDR.Send(CMD);
            }
            catch (Exception e)
            { 
                Tb_Info.Text += Environment.NewLine + e.Message + Environment.NewLine;
            }
        }


        /***************************************************************************************
        * Events:   Ports
        ****************************************************************************************/
        clDeviceCom DeviceCom = new clDeviceCom();
        string CMD;

        private void CoB_BaudRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            Init_Port();
        }

        private void CoB_COM_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CoB_COM.Text.Contains("Load"))
            {
                Init_CoB_Port();
            }
            else
            {
                Init_Port();
            }
        }

        /***************************************************************************************
        * Events:   Messages
        ****************************************************************************************/
        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            Tb_Info.Clear();
        }

        private void Btn_StopRead_Click(object sender, EventArgs e)
        {
            Close_COMport();
            ThreadDR.Stop();
        }


        /***************************************************************************************
        * Events:   Send
        ****************************************************************************************/
        private void Btn_Send_Click(object sender, EventArgs e)
        {
            CMD_Send(CoB_CMD.Text);
            //string HEX = "D805020A327E722A050000009ED364B35573C15CB0962C0700000000000000E0";
            //clDeviceCom dc = new clDeviceCom();
            //dc.Get_Sample_FWversion(m_TT.ODBC_EK_Selected, HEX, out string fwversion);
        }

        enum CMDs
        {
            InitBox_S999,
            Set0nA_G907,
            Set175nA_G908,
            Set4700nA_G909,
            Calib_S100_6850i,
            Calib_S674,
            Calib_S500,
            GetBoxLimits,
            ShowBoxLimits,
            TempCheckNTC25_G911,
            TempCheckPT20_G915,
            TempCheckPT30_G916,
            CheckUpol_G910,
            SetUpol500_G913,
            SetUpol674_G914
        }


        private void BtnSendp_Click(object sender, EventArgs e)
        {
            Enum.TryParse(CobCMDp.Text, out commands);
            A();
            
        }



        /***************************************************************************************
        * StateMachine:
        ****************************************************************************************/
        private CMDs commands;
        List<Routine> InitBoxList = new List<Routine>();
        private bool G001sended = false;
        private void A()
        {
            StateSend = new List<Routine>();
            bool startCMDs = true;
            switch (commands)
            {
                case CMDs.InitBox_S999:
                    if (InitBoxList.Count == 0)
                    {
                        InitBoxList.Add(new Routine("S999", wait: 5000));
                        InitBoxList.Add(new Routine("G015", wait: 2000, retry: 2));
                    }
                    StateSend = InitBoxList;
                    if (commands != CMDs.InitBox_S999){ A(); return; }
                    break;
                case CMDs.Set0nA_G907:
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.Add(new Routine("G907", wait: 2000 ));
                    StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 8 });
                    break;
                case CMDs.Set175nA_G908:
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.Add(new Routine() { CMD = "G908", Wait = 2000 });
                    StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 8 });
                    break;
                case CMDs.Set4700nA_G909:
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.Add(new Routine() { CMD = "G909", Wait = 2000 });
                    StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 8 });
                    break;
                case CMDs.Calib_S100_6850i:
                    Tb_Info.Clear();
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.AddRange(InitBoxList);
                    StateSend.Add(new Routine() { CMD = "S100", Wait = 20000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.Calib_S500:
                    Tb_Info.Clear();
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.AddRange(InitBoxList);
                    StateSend.Add(new Routine() { CMD = "S674", Wait = 20000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.Calib_S674:
                    Tb_Info.Clear();
                    if(InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.AddRange(InitBoxList);
                    StateSend.Add(new Routine() { CMD = "S500", Wait = 20000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.GetBoxLimits:
                    Tb_Info.Clear();
                    if (InitBoxList.Count == 0) { goto case CMDs.InitBox_S999; }
                    StateSend.AddRange(InitBoxList);
                    StateSend.Add(new Routine() { CMD = "#RDBX 10", Wait = 2000 });
                    StateSend.Add(new Routine() { CMD = "#RDBX 31", Wait = 2000 });
                    break;
                case CMDs.ShowBoxLimits:
                    startCMDs = false;
                    ShowBoxLimits();
                    PanelLimits.Height = 130;
                    break;
                case CMDs.TempCheckNTC25_G911:
                    Tb_Info.Clear();
                    StateSend.Add(new Routine() { CMD = "G911", Wait = 3000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.TempCheckPT20_G915:
                    Tb_Info.Clear();
                    StateSend.Add(new Routine() { CMD = "G915", Wait = 3000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.TempCheckPT30_G916:
                    Tb_Info.Clear();
                    StateSend.Add(new Routine() { CMD = "G916", Wait = 3000 });
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1000, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.CheckUpol_G910:
                    Tb_Info.Clear();
                    Message("16sec Warten");
                    StateSend.Add(new Routine() { CMD = "G910", Wait = 16000 });
                    
                    if (!G001sended)
                    {
                        StateSend.Add(new Routine() { CMD = "G906", Wait = 1500, RetriesMax = 0 });
                        StateSend.Add(new Routine() { CMD = "G901", Wait = 1000 });
                        G001sended = true;
                    }
                    break;
                case CMDs.SetUpol500_G913:
                    Tb_Info.Clear();
                    Message("16sec Warten");
                    StateSend.Add(new Routine() { CMD = "G913", Wait = 16000 });
                    
                    StateSend.Add(new Routine() { CMD = "G906", Wait = 1500, RetriesMax = 8 });
                    break;
                case CMDs.SetUpol674_G914:
                    Tb_Info.Clear();
                    Message("16sec Warten");
                    StateSend.Add(new Routine() { CMD = "G914", Wait = 16000 });
                    StateSend.Add(new Routine() { CMD = "G906", Wait = 1500, RetriesMax = 8 });
                    break;
            }
            if (startCMDs)
            {
                PanelLimits.Height = 0;
                NowRunningIndex = 0;
                NowRunning = StateSend[NowRunningIndex];
                CMDsw.Restart();
                tmSendp.Interval = 1;
                tmSendp.Start();
            }
        }
        private struct Routine
        {
            public Routine(string cmd)
            {
                CMD = cmd;
                Wait = 0;
                RetriesCount = 0;
                RetriesMax = 1;
                Running = false;
            }

            public Routine(string cmd, int wait) : this(cmd)
            {
                Wait = wait;
            }
            public Routine(string cmd, int wait, int retry): this(cmd, wait)
            {
                RetriesMax = retry;
            }

            public string CMD;
            public int Wait;
            public int RetriesMax;
            public int RetriesCount;
            public bool Running;
            public int Send(int nowrunningIndex)
            {
                if (!Running)
                {
                    Running = true;
                    CMDsw = Stopwatch.StartNew();
                    RetriesCount++;
                    Instance.CMD_Send(CMD);
                    return nowrunningIndex;
                }
                if(TimeElapsed && Retry)
                {
                    Instance.CMD_Send(CMD);
                    CMDsw.Restart();
                    RetriesCount++;
                    return nowrunningIndex;
                }
                else if(TimeElapsed && !Retry)
                {
                    nowrunningIndex++;
                }
                return nowrunningIndex;
            }
            public bool TimeElapsed
            {
                get
                {
                    if(Wait < 1) { return true; }
                    return CMDsw.ElapsedMilliseconds > Wait;
                }
            }
            public bool Retry
            {
                get
                {
                    if(RetriesMax < 2) { return false; }
                    if (RetriesCount >= RetriesMax) { return false; }
                    return true;
                }
            }
        }
        List<Routine> StateSend = new List<Routine>();
        public static Stopwatch CMDsw = new Stopwatch();
        Timer tmSendp = new Timer();
        private int tmInterval = 500;
        private void Init_Timer()
        {
            tmSendp = new Timer();
            tmSendp.Interval = tmInterval;
            tmSendp.Tick += TmSendp_Tick;
        }
        Routine NowRunning;
        int NowRunningIndex;
        private void TmSendp_Tick(object sender, EventArgs e)
        {
            if (NowRunningIndex >= StateSend.Count)
            {
                tmSendp.Stop();
                return;
            }
            var i = NowRunning.Send(NowRunningIndex);
            if (i!=NowRunningIndex)
            {
                NowRunningIndex = i;
                if (NowRunningIndex < StateSend.Count)
                { 
                    NowRunning = StateSend[NowRunningIndex]; 
                }
                else
                {
                    tmSendp.Stop();
                }
            }
        }

        /***************************************************************************************
        * Calibration:  Load
        ****************************************************************************************/
        private void ShowBoxLimits()
        {
            var dl = DR.BoxID.DeviceLimits;
            textBoxCAL_High_1.Text = dl.RawErrorCalibration.High1.ToString();
            textBoxCAL_High_2.Text = dl.RawErrorCalibration.High2.ToString();
            textBoxCAL_Low_1.Text = dl.RawErrorCalibration.Low1.ToString();
            textBoxCAL_Low_2.Text = dl.RawErrorCalibration.Low2.ToString();

            textBoxVER_High_1.Text = dl.Current.High1.ToString("0.0##");
            textBoxVER_High_2.Text = dl.Current.High2.ToString("0.0##");
            textBoxVER_Low_1.Text = dl.Current.Low1.ToString("0.0##");
            textBoxVER_Low_2.Text = dl.Current.Low2.ToString("0.0##");

            textBoxMB1Zero.Text = dl.RawVal.Low1.ToString();
            textBoxMB1_175nA.Text = dl.RawVal.Low2.ToString();
            textBoxMB2_175nA.Text = dl.RawVal.High1.ToString();
            textBoxMB2_4700nA.Text = dl.RawVal.High2.ToString();

            lblCurr0.Text = dl.Current.Low2.ToString("0.0##");
            lblCurr1.Text = dl.Current.High1.ToString("0.0##");
            lblCurr2.Text = dl.Current.High2.ToString("0.0##");

            textBoxT5Deg.Text = dl.TempRefVolt.ToString();
            label20.Text = dl.TempRefVoltTemp.ToString("0.0##");
            textBoxT25Deg.Text = dl.TempRefVolt2.ToString();
            label21.Text = dl.TempRefVolt2Temp.ToString("0.0##");
            textBoxT50Deg.Text = dl.TempRefVolt3.ToString();
            label22.Text = dl.TempRefVolt3Temp.ToString("0.0##");
            textBoxTerror.Text = dl.TempErr.ToString();
            label35.Text = dl.TempErrTemp.ToString();

            textBoxStdDevMB1L1.Text = dl.StdDev.Low1.ToString();
            textBoxStdDevMB1L2.Text = dl.StdDev.Low2.ToString();
            textBoxStdDevMB2L1.Text = dl.StdDev.High1.ToString();
            textBoxStdDevMB2L2.Text = dl.StdDev.High2.ToString();

            textBoxUpolErr.Text = dl.UpolError.ToString();
            label33.Text = dl.UpolErrorValue.ToString();

            textBoxNr.Text = dl.BeM_BoxNr;
            label17.Text = dl.BeM;
        }

        private void CkbWrapLine_CheckedChanged(object sender, EventArgs e)
        {
            Tb_Info.WordWrap = CkbWrapLine.Checked;
        }
    }
}
