﻿namespace CaliboxLibrary
{
    public class DeviceLimitsModes
    {
        public double Low1;
        public double Low2;
        public double High1;
        public double High2;
        public string Unit;
    }
}
